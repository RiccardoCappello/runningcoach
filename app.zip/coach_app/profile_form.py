"""Onboarding form <-> profile dict <-> TOML.

TOML stays the stored format (the engine reads it, and Setup > advanced edits it directly);
the guided onboarding just writes it for you.
"""
from __future__ import annotations

import tomllib
from datetime import date

from coach_engine.fitness import COOPER_S, fmt_time, parse_time_text
from coach_engine.models import DAYS

DIST_CHOICES = [("cooper", "12-minute test (metres run)"), ("1500", "1500 m"), ("mile", "Mile"), ("3k", "3 km"), ("5k", "5 km"), ("8k", "8 km"),
                ("10k", "10 km"), ("15k", "15 km"), ("10mi", "10 miles"), ("half", "Half marathon"),
                ("marathon", "Marathon")]
GOAL_DISTANCES = [("5k", "5 km"), ("10k", "10 km"), ("half", "Half marathon"), ("marathon", "Marathon")]
INTENSITIES = [("pyramidal", "Mixed (threshold-led)"), ("polarized", "Polarised (fast and easy)")]
KINDS = [("race", "Race"), ("time_trial", "Time trial (solo, all-out)"), ("hard_effort", "Hard training run")]
AREAS = ["knee", "ankle", "achilles", "shin", "calf", "hamstring", "hip", "foot", "back", "other"]
XT = ["bike", "swim", "elliptical", "rowing", "aqua jogging"]
N_PERF, N_INJ = 4, 3
STATUSES = [("regular", "I run regularly"), ("returning", "Coming back after a break"),
            ("beginner", "Starting from scratch")]
CONTINUOUS = [(0, "Not yet, or under 2 minutes"), (3, "2-4 minutes"), (7, "5-9 minutes"),
              (15, "10-19 minutes"), (25, "20 minutes or more")]


# ------------------------------------------------------------------ TOML out
def _val(v) -> str:
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return f"{v:g}" if isinstance(v, float) else str(v)
    if isinstance(v, date):
        return v.isoformat()                # a TOML local date
    if isinstance(v, str):
        return '"' + v.replace("\\", "\\\\").replace('"', '\\"') + '"'
    if isinstance(v, list):
        return "[" + ", ".join(_val(x) for x in v) + "]"
    if isinstance(v, dict):
        return "{ " + ", ".join(f"{k} = {_val(x)}" for k, x in v.items()) + " }"
    raise TypeError(type(v))


def to_toml(d: dict) -> str:
    out = ["# Written by the RunningCoach onboarding. You can edit it in Setup > Advanced."]
    for table, body in d.items():
        rows = body if isinstance(body, list) else [body]
        for row in rows:
            out.append("")
            out.append(f"[[{table}]]" if isinstance(body, list) else f"[{table}]")
            out += [f"{k} = {_val(v)}" for k, v in row.items() if v is not None and v != [] and v != {}]
    return "\n".join(out) + "\n"


# ----------------------------------------------------------------- form in
def _f(form, key, cast=float):
    v = (form.get(key) or "").strip()
    if v == "":
        return None
    return cast(v)


def form_to_profile(form) -> dict:
    """form: a mapping with .get and .getlist (Starlette FormData). Raises ValueError with a
    readable message on missing / bad answers."""
    err = []

    def need(key, label, cast=float):
        try:
            v = _f(form, key, cast)
        except ValueError:
            err.append(f"{label}: not a number")
            return None
        if v is None:
            err.append(f"{label} is needed")
        return v

    birth = (form.get("birth_date") or "").strip()
    if not birth:
        err.append("Birth date is needed")
    injuries = []
    for i in range(N_INJ):
        area, year = form.get(f"inj_area_{i}"), (form.get(f"inj_year_{i}") or "").strip()
        if area and year:
            injuries.append({"area": area, "year": int(year)})
    recent_inj = any(date.today().year - x["year"] <= 2 for x in injuries)
    athlete = {"birth_date": birth, "sex": form.get("sex") or "M",
               "years_running": need("years_running", "Years running"),
               "injury_prone": bool(form.get("injury_prone")) or recent_inj,
               "injuries": injuries, "body_mass_kg": _f(form, "body_mass_kg")}

    max_minutes = {}
    for d in DAYS:
        m = _f(form, f"max_{d}", int)
        if m:
            max_minutes[d] = m
    avail = {"run_days": int(form.get("run_days") or 5), "long_run_day": form.get("long_run_day") or "Sun",
             "unavailable": [d for d in DAYS if form.get(f"off_{d}")], "max_minutes": max_minutes,
             "cross_training": [x for x in XT if form.get(f"xt_{x}")],
             "xt_sessions": int(form.get("xt_sessions") or 0), "strength": bool(form.get("strength")),
             "max_weekly_km": _f(form, "max_weekly_km")}
    if avail["long_run_day"] in avail["unavailable"]:
        err.append("The long-run day is marked as unavailable")
    if 7 - len(avail["unavailable"]) < 3:
        err.append("At least 3 days a week must be free to run")

    phys = {"hr_max": _f(form, "hr_max", int), "hr_rest": _f(form, "hr_rest", int), "lthr": _f(form, "lthr", int)}
    status = form.get("status") or "regular"
    if status == "returning":
        before = need("ret_weekly_km", "Weekly km before the break")
        recent = {"status": status, "weeks_off": need("ret_weeks_off", "Weeks off"),
                  "cross_trained": bool(form.get("ret_xt")), "weekly_km": before, "max_sustained_km": before,
                  "long_run_km": _f(form, "ret_long_km")}
    elif status == "beginner":
        recent = {"status": status, "weekly_km": 0, "continuous_min": _f(form, "continuous_min") or 0}
    else:
        recent = {"weekly_km": need("weekly_km", "Recent weekly km"), "max_sustained_km": _f(form, "max_sustained_km"),
                  "long_run_km": _f(form, "long_run_km"), "consistent_weeks": int(form.get("consistent_weeks") or 0)}
    pace = (form.get("easy_pace") or "").strip()
    if pace and status != "beginner":
        try:
            recent["easy_pace"] = fmt_time(parse_time_text(pace))
        except ValueError:
            err.append("Easy pace: write it as min:sec per km, e.g. 6:00")

    perfs = []
    for i in range(N_PERF):
        dist, t, d = form.get(f"p_dist_{i}"), (form.get(f"p_time_{i}") or "").strip(), (form.get(f"p_date_{i}") or "").strip()
        if not t or status == "beginner":
            continue
        if not d:
            err.append(f"Result {i + 1}: when was it?")
            continue
        if dist == "cooper":
            try:
                m = float(t.replace(",", "").replace(" ", ""))
                m = m * 1000 if m < 10 else m          # "2.6" = 2.6 km
                if not 800 <= m <= 5500:
                    raise ValueError
            except ValueError:
                err.append(f"Result {i + 1}: for the 12-minute test write the metres you ran, e.g. 2600")
                continue
            perfs.append({"distance": round(m), "time": fmt_time(COOPER_S), "date": d, "kind": "time_trial"})
            continue
        try:
            secs = parse_time_text(t)
        except ValueError:
            err.append(f"Result {i + 1}: write the time as mm:ss or h:mm:ss")
            continue
        perfs.append({"distance": dist, "time": fmt_time(secs), "date": d, "kind": form.get(f"p_kind_{i}") or "race"})

    gtype = form.get("goal_type") or "general"
    goal = {"type": gtype, "distance": form.get("goal_distance") or "10k"}
    if form.get("intensity") == "polarized":
        goal["intensity"] = "polarized"
    if gtype == "race":
        if not (form.get("race_date") or "").strip():
            err.append("Race date is needed")
        goal["race_date"] = (form.get("race_date") or "").strip() or None
        if (form.get("target_time") or "").strip():
            try:
                goal["target_time"] = fmt_time(parse_time_text(form.get("target_time")))
            except ValueError:
                err.append("Target time: write it as mm:ss or h:mm:ss")
    else:
        goal["weeks"] = int(form.get("weeks") or 12)
    if err:
        raise ValueError("; ".join(err))
    return {"athlete": athlete, "availability": avail, "physiology": phys, "recent": recent,
            "performance": perfs, "goal": goal}


# ------------------------------------------------------------- prefill out
def toml_to_values(text: str | None) -> dict:
    """Flat dict of form values from a stored profile (best effort)."""
    v = {"run_days": 5, "long_run_day": "Sun", "xt_sessions": 1, "strength": True, "xt_bike": True,
         "sex": "M", "goal_type": "general", "goal_distance": "10k", "weeks": 12, "consistent_weeks": 4}
    if not text:
        return v
    try:
        d = tomllib.loads(text)
    except tomllib.TOMLDecodeError:
        return v
    a = d.get("athlete", {})
    v.update(sex=a.get("sex", "M"), years_running=a.get("years_running"), injury_prone=a.get("injury_prone"),
             body_mass_kg=a.get("body_mass_kg"))
    if "birth_date" in a:
        v["birth_date"] = str(a["birth_date"])
    elif "age" in a:
        v["birth_date"] = f"{date.today().year - int(a['age'])}-01-01"
    for i, inj in enumerate(a.get("injuries", [])[:N_INJ]):
        v[f"inj_area_{i}"], v[f"inj_year_{i}"] = inj.get("area"), inj.get("year")
    av = d.get("availability", {})
    v.update(run_days=av.get("run_days", 5), long_run_day=str(av.get("long_run_day", "Sun"))[:3].title(),
             xt_sessions=av.get("xt_sessions", 1), strength=av.get("strength", True),
             max_weekly_km=av.get("max_weekly_km"))
    for day in av.get("unavailable", []):
        v[f"off_{str(day)[:3].title()}"] = True
    for day, m in av.get("max_minutes", {}).items():
        v[f"max_{str(day)[:3].title()}"] = m
    v["xt_bike"] = False
    for x in av.get("cross_training", ["bike"]):
        v[f"xt_{x}"] = True
    v.update({k: d.get("physiology", {}).get(k) for k in ("hr_max", "hr_rest", "lthr")})
    r = d.get("recent", {})
    v["status"] = r.get("status", "regular")
    v["easy_pace"] = r.get("easy_pace")
    if v["status"] == "returning":
        v.update(ret_weekly_km=r.get("weekly_km"), ret_weeks_off=r.get("weeks_off"), ret_xt=r.get("cross_trained"),
                 ret_long_km=r.get("long_run_km"))
    elif v["status"] == "beginner":
        v["continuous_min"] = r.get("continuous_min", 0)
    else:
        v.update({k: r.get(k) for k in ("weekly_km", "max_sustained_km", "long_run_km", "consistent_weeks")})
    for i, p in enumerate(d.get("performance", [])[:N_PERF]):
        dd = str(p.get("date", ""))
        v[f"p_dist_{i}"], v[f"p_time_{i}"] = str(p.get("distance")), str(p.get("time"))
        if isinstance(p.get("distance"), (int, float)) and str(p.get("time")) == fmt_time(COOPER_S):
            v[f"p_dist_{i}"], v[f"p_time_{i}"] = "cooper", str(int(p["distance"]))
        v[f"p_date_{i}"] = dd + "-15" if len(dd) == 7 else dd
        v[f"p_kind_{i}"] = p.get("kind", "race")
    g = d.get("goal", {})
    v.update(goal_type=g.get("type", "general"), goal_distance=str(g.get("distance", "10k")),
             weeks=g.get("weeks", 12), race_date=str(g.get("race_date", "") or ""),
             target_time=str(g.get("target_time", "") or ""), intensity=g.get("intensity", "pyramidal"))
    return v
