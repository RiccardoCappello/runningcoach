"""Things to be proud of: personal bests and how close the next one is, the consistency streak,
the block recap, and the plan as a calendar file (spec §15). Read-only."""
from __future__ import annotations

from datetime import date, datetime, timedelta

from coach_engine import predict as PR
from coach_engine.fitness import dist_name, fmt_pace, fmt_time
from coach_engine.profile_io import profile_from_toml

from . import seasons, store

STREAK_SHARE = 0.9          # a week counts when at least this share of its sessions were done


# ------------------------------------------------------------------ results / PBs
def all_results(u, t: date) -> list:
    """Every result: the profile's and every time trial / race logged in any plan, oldest first."""
    out, seen = [], set()
    toml = u.get_profile()
    if toml:
        for p in profile_from_toml(toml, t).performances:
            out.append({"m": round(p.distance_m, 1), "time": p.time_s, "date": p.date.isoformat(), "kind": p.kind})
    for r in seasons.results(u):
        out.append({"m": r["distance_m"], "time": r["time_s"], "date": r["date"], "kind": r["kind"]})
    uniq = []
    for r in sorted(out, key=lambda r: (r["date"], r["time"])):
        key = (r["date"], round(r["m"] / 50))
        if key not in seen:
            seen.add(key)
            uniq.append(r)
    return uniq


def pb_wall(u, pid: int, data: dict, t: date) -> list:
    """One row per distance with an all-out result: the PB, how it got there, and the gap to the
    time predicted now (the next PB)."""
    res = [r for r in all_results(u, t) if r["kind"] != "hard_effort"]
    by_m = {}
    for r in res:
        k = min(by_m, key=lambda m: abs(m - r["m"]), default=None)
        if k is None or abs(k - r["m"]) > 0.02 * k:
            k = r["m"]
        by_m.setdefault(k, []).append(r)
    prof = profile_from_toml(u.plan_profile(pid), date.fromisoformat(data["created"]))
    _, basis_m, slope, _ = PR.runner_curve(prof, date.fromisoformat(data["created"]))
    cur, _ = store.week_for(data, t)
    vd = (cur.get("zones") or data["zones"])["vdot"] if cur else data["vdot"]
    weekly = prof.recent.weekly_km
    rows = []
    for m, rs in sorted(by_m.items()):
        steps, best = [], None
        for r in rs:                                 # oldest first: each improvement is a step
            if best is None or r["time"] < best["time"]:
                best = r
                steps.append(r)
        pred = PR.predict(m, vd, basis_m, slope, weekly).time_s if not data.get("provisional") else None
        gap = None if pred is None else best["time"] - pred           # > 0: the prediction beats the PB
        if gap is None:
            verdict = ""
        elif gap > 0:
            verdict = f"you could run about {fmt_time(pred)} now: {fmt_time(gap)} under your best"
        elif -gap < 0.02 * best["time"]:
            verdict = f"within reach: {fmt_time(-gap)} away ({-gap / (m / 1000):.0f} s/km)"
        else:
            verdict = f"{fmt_time(-gap)} away now ({-gap / (m / 1000):.0f} s/km)"
        rows.append({"m": m, "name": dist_name(m), "best": best, "pace": fmt_pace(best["time"] / (m / 1000)),
                     "when": date.fromisoformat(best["date"]).strftime("%d %b %Y"), "steps": steps,
                     "pred": pred, "gap": gap, "verdict": verdict, "fresh": (t - date.fromisoformat(best["date"])).days <= 30})
    return rows


# --------------------------------------------------------------------- streak
def streak(u, t: date) -> dict:
    """Weeks in a row (the last finished ones) with at least 90 % of the planned sessions done,
    across every plan; plus the longest such run."""
    weeks = {}
    for pid, _, data in sorted(u.plans(), key=lambda x: x[0]):          # newer plans override older weeks
        logs = u.logs(pid)
        for w in data["weeks"]:
            start = date.fromisoformat(w["start"])
            if start + timedelta(days=6) >= t:
                continue
            due = [s for s in w["sessions"] if s["kind"] not in ("rest", "strength")
                   and start + timedelta(days=s["day"]) >= date.fromisoformat(data["start"])]
            if not due:
                continue
            done = sum(1 for s in due if s["id"] in logs and logs[s["id"]]["completed"] != "no")
            weeks[start] = done / len(due)
    run = best = 0
    cur = None
    for start in sorted(weeks):
        if weeks[start] >= STREAK_SHARE and (cur is None or (start - cur).days == 7):
            run += 1
        elif weeks[start] >= STREAK_SHARE:
            run = 1
        else:
            run = 0
        best = max(best, run)
        cur = start
    # the current streak only counts if it reaches last week
    last = max(weeks) if weeks else None
    now = run if last and (t - last).days <= 13 else 0
    return {"now": now, "best": best}


# ---------------------------------------------------------------------- recap
def recap(u, pid: int, data: dict, t: date, tr: dict | None) -> dict:
    """The block so far (or finished): volume, consistency, fitness, PBs, best progress."""
    logs, extras = u.logs(pid), u.extras()
    start, end = date.fromisoformat(data["start"]), store.plan_end(data)
    upto = min(t, end)
    km = minutes = 0.0
    due = done = key_done = 0
    longest = 0.0
    for w in data["weeks"]:
        ws = date.fromisoformat(w["start"])
        for s in w["sessions"]:
            d = ws + timedelta(days=s["day"])
            if d > upto or d < start or s["kind"] in ("rest", "strength"):
                continue
            lg = logs.get(s["id"])
            due += 1
            if lg and lg["completed"] != "no":
                done += 1
                k = store.done_km(s, lg)
                km += k
                minutes += lg["minutes"] or store.session_minutes(s)
                key_done += s["kind"] in ("quality", "tt")
                if s["kind"] == "long":
                    longest = max(longest, k)
    for x in extras:
        if start.isoformat() <= x["date"] <= upto.isoformat():
            km += x["km"] or 0.0
            minutes += x["minutes"]
            if x["kind"] == "run":
                longest = max(longest, x["km"] or 0.0)
    v0 = data.get("base_vdot", data["vdot"])
    cur, _ = store.week_for(data, upto)
    v1 = (cur.get("zones") or data["zones"])["vdot"] if cur else data["vdot"]
    pbs = [r for r in all_results(u, t) if start.isoformat() <= r["date"] <= upto.isoformat()
           and r["kind"] != "hard_effort"]
    wall = {round(row["m"]): row for row in pb_wall(u, pid, data, t)}
    new_pbs = [r for r in pbs if any(st is r or (st["date"] == r["date"] and st["time"] == r["time"])
                                     for row in wall.values() for st in row["steps"])]
    highlights = []
    if tr and tr.get("eff") and tr["eff"].change is not None and tr["eff"].change < -1:
        highlights.append(f"Easy pace at {tr['ref']:.0f} bpm: {-tr['eff'].change:.0f} s/km faster")
    if tr:
        better = [r for r in tr["bench"]["repeats"] if r["trend"].get("better")]
        if better:
            b = max(better, key=lambda r: -r["trend"]["pace_change"])
            highlights.append(f"{b['key']}: {b['trend']['text']}")
        if tr["drift"] and tr["drift"][-1]["value"] < 5:
            highlights.append(f"Long-run drift down to {tr['drift'][-1]['value']:.1f} %")
    final = None
    last = data["weeks"][-1]
    for s in last["sessions"]:
        lg = logs.get(s["id"])
        if s["kind"] == "tt" and lg and lg["result_s"]:
            final = {"title": s["title"], "time": lg["result_s"], "predicted": data.get("target_time_s")}
    g = data["goal"]
    return {"name": u.con.execute("SELECT name FROM users WHERE id = ?", (u.uid,)).fetchone()["name"],
            "goal": "Base building" if g["type"] == "base" else dist_name(g["distance_m"]) + (" race" if g["type"] == "race" else " block"),
            "start": start, "end": end, "finished": t > end, "weeks": min(len(data["weeks"]), (upto - start).days // 7 + 1),
            "km": km, "hours": minutes / 60, "due": due, "done": done, "key_done": key_done, "longest": longest,
            "v0": v0, "v1": v1, "new_pbs": [dict(r, name=dist_name(r["m"])) for r in new_pbs], "highlights": highlights,
            "final": final, "streak": streak(u, t)}


# ------------------------------------------------------------------ calendar
def ics(data: dict, name: str = "RunningCoach") -> str:
    """The plan as an iCalendar file: one all-day event per training session."""
    def esc(x: str) -> str:
        return x.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")
    stamp = datetime.now().strftime("%Y%m%dT%H%M%SZ")
    out = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//RunningCoach//plan//EN", f"X-WR-CALNAME:{esc(name)}",
           "CALSCALE:GREGORIAN"]
    start = date.fromisoformat(data["start"])
    for w in data["weeks"]:
        ws = date.fromisoformat(w["start"])
        for s in w["sessions"]:
            d = ws + timedelta(days=s["day"])
            if s["kind"] == "rest" or d < start:
                continue
            mins = store.session_minutes(s)
            km = store.session_km(s)
            title = f"{s['title']} · {store.fmt_min(mins)}" + (f" · {km:.1f} km" if km >= 0.5 else "")
            desc = "\n".join(g["label"] for g in s["segments"] if g["label"])
            out += ["BEGIN:VEVENT", f"UID:{s['id']}-{data['created']}@runningcoach", f"DTSTAMP:{stamp}",
                    f"DTSTART;VALUE=DATE:{d:%Y%m%d}", f"DTEND;VALUE=DATE:{d + timedelta(days=1):%Y%m%d}",
                    f"SUMMARY:{esc(title)}", f"DESCRIPTION:{esc(desc)}", "TRANSP:TRANSPARENT", "END:VEVENT"]
    out.append("END:VCALENDAR")
    return "\r\n".join(out) + "\r\n"
