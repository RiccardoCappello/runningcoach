"""RunningCoach web app (M3): FastAPI + SQLite + server-rendered pages around coach_engine."""
