"""Routes. Run:  python -m uvicorn coach_app.main:app --reload   (from server/)."""
from __future__ import annotations

import base64
import json
import os
import re
import tomllib
import zlib
from datetime import date, datetime, timedelta
from pathlib import Path

from fastapi import FastAPI, Form, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from coach_engine.builder import build_plan
from coach_engine.fitness import fmt_pace, fmt_time, parse_distance, parse_time_text
from coach_engine.library import dist_name
from coach_engine.models import DAYS
from coach_engine.profile_io import profile_from_toml
from coach_engine.render import target
from coach_engine.zones import ZONE_NAMES

from . import auth
from . import profile_form as PF
from . import progress
from . import store
from .db import DB, UserData

HERE = Path(__file__).resolve().parent
# Phone mode: the app runs inside the phone's browser (phone/, Pyodide) for one person, with no
# accounts; sharing is a snapshot packed into the link instead of a link to a server.
PHONE = os.environ.get("COACH_PHONE") == "1"
EXAMPLE = HERE.parents[1] / "engine" / "examples" / "sample_10k.toml"
if not EXAMPLE.exists():                     # the phone bundle keeps it next to the app
    EXAMPLE = HERE / "sample_10k.toml"

app = FastAPI(title="RunningCoach")
if not PHONE:                     # on the phone the shell serves static/ itself
    app.mount("/static", StaticFiles(directory=HERE / "static"), name="static")
templates = Jinja2Templates(directory=HERE / "templates")
templates.env.globals.update(DAYS=DAYS, fmt_pace=fmt_pace, fmt_time=fmt_time, ZONE_NAMES=ZONE_NAMES,
                             STEP_TEXT=store.STEP_TEXT, fmt_min=store.fmt_min, PF=PF, dist_name=dist_name,
                             phone=PHONE)
templates.env.filters["fromjson"] = lambda s: json.loads(s) if s else []

db: DB | None = None
_keys: dict = {}          # database path -> cookie signing key


def get_db() -> DB:
    global db
    if db is None:
        db = DB()
    return db


def key() -> bytes:
    path = get_db().path
    if path not in _keys:
        _keys[path] = auth.load_secret(path)
    return _keys[path]


def clock() -> date:
    """The real date; tests replace it."""
    return date.today()


def today(d: str | None = None) -> date:
    """?d=YYYY-MM-DD overrides the date (handy to look ahead or test)."""
    return date.fromisoformat(d) if d else clock()


# ------------------------------------------------------------------ accounts
class LoginNeeded(Exception):
    pass


@app.exception_handler(LoginNeeded)
def _to_login(request: Request, exc: LoginNeeded):
    return RedirectResponse("/login" if get_db().n_users() else "/register", status_code=303)


def phone_user() -> int:
    """Phone mode: the one person on this device (created on first use)."""
    u = get_db().user_by_name("me")
    return u["id"] if u else get_db().add_user("me", "Runner", "", "", is_admin=True)


def me(request: Request) -> UserData:
    """The logged-in person's data, or a redirect to the login page."""
    uid = phone_user() if PHONE else auth.read_cookie(key(), request.cookies.get(auth.COOKIE))
    user = get_db().user(uid) if uid else None
    if user is None:
        raise LoginNeeded()
    request.state.user = user
    return get_db().for_user(user["id"])


def logged_in(response, request: Request, uid: int):
    response.set_cookie(auth.COOKIE, auth.make_cookie(key(), uid), max_age=auth.MAX_AGE, httponly=True,
                        samesite="lax", secure=request.url.scheme == "https")
    return response


def public_base(request: Request) -> str:
    """Address to put in invite / share links. Links made while browsing on 127.0.0.1 would
    only work on this PC, so the public address wins: COACH_PUBLIC_URL, else the first line of
    public_url.txt next to the database (e.g. the Tailscale Funnel address)."""
    url = os.environ.get("COACH_PUBLIC_URL", "").strip()
    f = get_db().path.with_name("public_url.txt")
    if not url and f.exists():
        lines = f.read_text(encoding="utf-8").split()
        url = lines[0] if lines else ""
    if PHONE:
        return url              # the app's own page (…/coach/): share links add #/view/…
    return (url or str(request.base_url)).rstrip("/")


def page(request: Request, name: str, **ctx):
    ctx.setdefault("user", getattr(request.state, "user", None))
    return templates.TemplateResponse(request, name, ctx)


def nice_days(text: str) -> str:
    return re.sub(r"day (\d)", lambda m: DAYS[int(m.group(1))], text)


def _num(x: str | None):
    return float(x) if x not in (None, "") else None


def replan(u: UserData, pid: int, data: dict, t: date):
    data["proposals"] = store.run_replan(u, pid, data, t)
    data["replanned_on"] = t.isoformat()
    u.save_plan_data(pid, data)


def active(u: UserData, t: date | None = None):
    """(pid, data) of the active plan; re-planned once a day so weekly reviews happen on time."""
    pid, data = u.active_plan()
    if data is not None and t is not None and data.get("replanned_on") != t.isoformat():
        replan(u, pid, data, t)
    return pid, data


def session_view(data: dict, w: dict, s: dict, logs: dict) -> dict:
    z = store.zones_of(data, w)
    return {
        "s": s, "date": date.fromisoformat(w["start"]) + timedelta(days=s["day"]),
        "lines": store.segment_lines(z, s), "km": store.session_km(s), "minutes": store.session_minutes(s),
        "explain": store.explain_total(s), "feel": store.target_rpe(s), "bar": store.zone_bar(s),
        "log": logs.get(s["id"]),
    }


def week_strip(w: dict, logs: dict, t: date, first_day: date) -> list:
    out = []
    start = date.fromisoformat(w["start"])
    for i in range(7):
        d = start + timedelta(days=i)
        runs = [s for s in w["sessions"] if s["day"] == i and s["kind"] not in ("rest", "strength")]
        main = max(runs, key=lambda s: (s["hard"], s["kind"] == "long", store.session_km(s)), default=None)
        logged = [logs[s["id"]] for s in runs if s["id"] in logs]
        out.append({"day": DAYS[i][0], "date": d, "kind": main["kind"] if main else "rest",
                    "hard": bool(main and main["hard"]), "today": d == t, "off": d < first_day,
                    "done": bool(logged) and all(l["completed"] != "no" for l in logged),
                    "missed": any(l["completed"] == "no" for l in logged)})
    return out


def week_done(w: dict, logs: dict) -> float:
    return sum(store.done_km(s, logs.get(s["id"])) for s in w["sessions"])


def chart_rows(data: dict, logs: dict) -> list:
    return [(w, store.week_stats(w), week_done(w, logs)) for w in data["weeks"]]


# ----------------------------------------------------------------- PWA bits
@app.get("/sw.js")
def service_worker():
    return FileResponse(HERE / "static" / "sw.js", media_type="text/javascript",
                        headers={"Service-Worker-Allowed": "/"})


@app.get("/manifest.webmanifest")
def manifest():
    return FileResponse(HERE / "static" / "manifest.webmanifest", media_type="application/manifest+json")


# ------------------------------------------------------ login / register
@app.get("/login", response_class=HTMLResponse)
def login_form(request: Request):
    if PHONE:
        return RedirectResponse("/today")
    if not get_db().n_users():
        return RedirectResponse("/register")
    return page(request, "login.html", error=None, username="")


@app.post("/login", response_class=HTMLResponse)
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    u = get_db().user_by_name(username)
    if u is None or not auth.check_pw(password, u["pw"], u["salt"]):
        return page(request, "login.html", error="Wrong username or password.", username=username)
    return logged_in(RedirectResponse("/today", status_code=303), request, u["id"])


@app.post("/logout")
def logout():
    r = RedirectResponse("/login", status_code=303)
    r.delete_cookie(auth.COOKIE)
    return r


@app.get("/register", response_class=HTMLResponse)
def register_form(request: Request, code: str = ""):
    if PHONE:
        return RedirectResponse("/today")
    first = get_db().n_users() == 0
    ok = first or get_db().invite(code) is not None
    return page(request, "register.html", first=first, code=code, ok=ok, error=None, v={})


@app.post("/register", response_class=HTMLResponse)
def register(request: Request, username: str = Form(...), name: str = Form(...), password: str = Form(...),
             code: str = Form("")):
    dbx = get_db()
    first = dbx.n_users() == 0
    v = {"username": username, "name": name}
    err = None
    if not first and dbx.invite(code) is None:
        err = "This invite link has been used or isn't valid. Ask for a new one."
    elif not re.fullmatch(r"[A-Za-z0-9_.-]{3,30}", username.strip()):
        err = "Username: 3-30 letters, digits, dots, dashes or underscores."
    elif dbx.user_by_name(username):
        err = "That username is taken."
    elif len(password) < 8:
        err = "Password: at least 8 characters."
    if err:
        return page(request, "register.html", first=first, code=code, ok=True, error=err, v=v)
    pw, salt = auth.hash_pw(password)
    uid = dbx.add_user(username, name or username, pw, salt, is_admin=first)
    if not first:
        dbx.use_invite(code, uid)
    return logged_in(RedirectResponse("/setup", status_code=303), request, uid)


# ------------------------------------------------------------------- Me
@app.get("/me", response_class=HTMLResponse)
def me_page(request: Request, new: str = ""):
    u = me(request)
    pid, data = u.active_plan()
    base = public_base(request)
    admin = bool(request.state.user["is_admin"])
    return page(request, "me.html", data=data, shares=u.shares(), base=base, new=new,
                invites=get_db().invites() if admin else [], people=get_db().users() if admin else [],
                admin=admin, msg=None)


@app.post("/me/share")
def new_share(request: Request):
    if PHONE:
        return RedirectResponse(f"/me?new={snapshot(me(request), request.state.user)}#share", status_code=303)
    tok = me(request).new_share()
    return RedirectResponse(f"/me?new={tok}#share", status_code=303)


@app.post("/me/name")
def set_name(request: Request, name: str = Form(...)):
    me(request)
    get_db().set_name(request.state.user["id"], name.strip()[:40] or "Runner")
    return RedirectResponse("/me", status_code=303)


@app.post("/me/share/{token}/delete")
def del_share(request: Request, token: str):
    me(request).delete_share(token)
    return RedirectResponse("/me#share", status_code=303)


@app.post("/me/invite")
def new_invite(request: Request, note: str = Form("")):
    me(request)
    if not request.state.user["is_admin"]:
        raise HTTPException(403)
    code = get_db().new_invite(request.state.user["id"], note)
    return RedirectResponse(f"/me?new={code}#people", status_code=303)


@app.post("/me/invite/{code}/delete")
def del_invite(request: Request, code: str):
    me(request)
    if not request.state.user["is_admin"]:
        raise HTTPException(403)
    get_db().delete_invite(code)
    return RedirectResponse("/me#people", status_code=303)


@app.post("/me/password", response_class=HTMLResponse)
def change_password(request: Request, old: str = Form(...), new: str = Form(...)):
    u = me(request)
    usr = request.state.user
    if not auth.check_pw(old, usr["pw"], usr["salt"]):
        msg = "Current password is wrong."
    elif len(new) < 8:
        msg = "New password: at least 8 characters."
    else:
        get_db().set_password(usr["id"], *auth.hash_pw(new))
        msg = "Password changed."
    pid, data = u.active_plan()
    admin = bool(usr["is_admin"])
    return page(request, "me.html", data=data, shares=u.shares(), base=public_base(request), new="",
                invites=get_db().invites() if admin else [], people=get_db().users() if admin else [],
                admin=admin, msg=msg)


# ------------------------------------------------------- read-only share
@app.get("/s/{token}", response_class=HTMLResponse)
def shared(request: Request, token: str):
    uid = get_db().share_owner(token)
    if uid is None:
        raise HTTPException(404, "This link has been switched off.")
    u = get_db().for_user(uid)
    pid, data = u.active_plan()
    owner = get_db().user(uid)
    if data is None:
        return page(request, "shared.html", owner=owner, data=None, user=None)
    return shared_page(request, owner, data, u.logs(pid), clock())


SNAP_PRIVATE = ("notes", "avg_hr")           # what a shared plan never shows


def snapshot(u: UserData, user) -> str:
    """Phone mode: the plan and its logs as it is now, packed into the share link (zlib + base64)."""
    pid, data = u.active_plan()
    if data is None:
        raise HTTPException(400, "Build a plan first.")
    logs = {k: {c: r[c] for c in r.keys() if c not in SNAP_PRIVATE} for k, r in u.logs(pid).items()}
    snap = {"v": 1, "name": user["name"], "at": clock().isoformat(), "data": data, "logs": logs}
    raw = json.dumps(snap, separators=(",", ":")).encode()
    return base64.urlsafe_b64encode(zlib.compress(raw, 9)).decode().rstrip("=")


@app.get("/view", response_class=HTMLResponse)
def view_snapshot(request: Request, p: str):
    """A shared snapshot (phone mode): read-only, nothing of it is stored."""
    try:
        snap = json.loads(zlib.decompress(base64.urlsafe_b64decode(p + "=" * (-len(p) % 4))))
    except (ValueError, zlib.error):
        raise HTTPException(400, "This link is incomplete: ask for it again.")
    t = max(clock(), date.fromisoformat(snap["at"]))
    return shared_page(request, {"name": snap["name"]}, snap["data"], snap["logs"], t, snap_at=snap["at"])


def shared_page(request: Request, owner, data: dict, logs: dict, t: date, snap_at: str | None = None):
    w, _ = store.week_for(data, t)
    w = w or data["weeks"][0 if t < date.fromisoformat(data["start"]) else -1]
    days = [(i, date.fromisoformat(w["start"]) + timedelta(days=i),
             [session_view(data, w, s, logs) for s in w["sessions"] if s["day"] == i]) for i in range(7)]
    rows = chart_rows(data, logs)
    return page(request, "shared.html", owner=owner, data=data, w=w, days=days, t=t, user=None,
                weeks=rows, top=max(max(st["km"], d) for _, st, d in rows) or 1, current=w["index"],
                stats=store.week_stats(w), done=week_done(w, logs), snap_at=snap_at)


# -------------------------------------------------------------------- Today
@app.get("/")
def root():
    return RedirectResponse("/today")


@app.get("/today", response_class=HTMLResponse)
def today_page(request: Request, d: str | None = None):
    u = me(request)
    t = today(d)
    pid, data = active(u, t)
    if data is None:
        return RedirectResponse("/setup")
    logs = u.logs(pid)
    w, day = store.week_for(data, t)
    start, end = date.fromisoformat(data["start"]), store.plan_end(data)
    sessions, strip, done = [], [], 0.0
    upcoming, upcoming_date = [], None
    if w is not None and t >= start:
        sessions = [session_view(data, w, s, logs) for s in w["sessions"] if s["day"] == day]
        strip = week_strip(w, logs, t, start)
        done = week_done(w, logs)
    if not any(v["s"]["kind"] not in ("rest", "strength") for v in sessions):
        # rest day (or before the start): the next training day, with everything planned on it
        for k in range(1, 8):
            nd = t + timedelta(days=k)
            nw, nday = store.week_for(data, nd)
            if nw is None or nd < start:
                continue
            todo = [s for s in nw["sessions"] if s["day"] == nday and s["kind"] != "rest"]
            if any(s["kind"] != "strength" for s in todo):
                upcoming = [session_view(data, nw, s, logs) for s in todo]
                upcoming_date = nd
                break
    hour = datetime.now().hour
    hello = "Good morning" if hour < 12 else "Good afternoon" if hour < 18 else "Good evening"
    return page(request, "today.html", t=t, data=data, week=w, sessions=sessions, before=t < start,
                after=t > end, start=start, upcoming=upcoming, upcoming_date=upcoming_date,
                readiness=u.get_readiness(t), d=d, strip=strip,
                done=done, stats=store.week_stats(w) if w else None, proposals=data.get("proposals", []),
                hello=hello, glance=None if t > end else progress.today_summary(u, pid, data, t))


# ----------------------------------------------------------------- Progress
@app.get("/progress", response_class=HTMLResponse)
def progress_page(request: Request):
    u = me(request)
    t = clock()
    pid, data = active(u, t)
    if data is None:
        return RedirectResponse("/setup")
    return page(request, "progress.html", data=data, t=t, **progress.context(u, pid, data, t))


@app.get("/api/goal")
def goal_api(request: Request, distance: str = "10k", target: str = "", when: str = ""):
    """The what-if goal check on the Progress page (JSON)."""
    u = me(request)
    t = clock()
    pid, data = u.active_plan()
    if data is None:
        raise HTTPException(404)
    try:
        return progress.what_if(u, pid, data, t, distance, target, when)
    except (ValueError, KeyError) as e:
        return {"error": str(e) if "past" in str(e) else "Write the time as mm:ss or h:mm:ss"}


# --------------------------------------------------------------------- Week
@app.get("/week", response_class=HTMLResponse)
def week_current(request: Request, d: str | None = None):
    u = me(request)
    pid, data = u.active_plan()
    if data is None:
        return RedirectResponse("/setup")
    w, _ = store.week_for(data, today(d))
    n = w["index"] if w else (1 if today(d) < date.fromisoformat(data["start"]) else len(data["weeks"]))
    return RedirectResponse(f"/week/{n}")


@app.get("/week/{n}", response_class=HTMLResponse)
def week_page(request: Request, n: int):
    u = me(request)
    t = clock()
    pid, data = active(u, t)
    if data is None:
        return RedirectResponse("/setup")
    if not 1 <= n <= len(data["weeks"]):
        raise HTTPException(404)
    w = data["weeks"][n - 1]
    logs = u.logs(pid)
    first_day = date.fromisoformat(data["start"])
    days = [(i, date.fromisoformat(w["start"]) + timedelta(days=i),
             [session_view(data, w, s, logs) for s in w["sessions"] if s["day"] == i]) for i in range(7)]
    return page(request, "week.html", w=w, n=n, total=len(data["weeks"]), days=days, first_day=first_day,
                stats=store.week_stats(w), t=t, done=week_done(w, logs), strip=week_strip(w, logs, t, first_day))


# --------------------------------------------------------------------- Plan
@app.get("/plan", response_class=HTMLResponse)
def plan_page(request: Request):
    u = me(request)
    t = clock()
    pid, data = active(u, t)
    if data is None:
        return RedirectResponse("/setup")
    cur, _ = store.week_for(data, t)
    z = store.zones_of(data, cur)
    zones = [(k, ZONE_NAMES[k], target(z, k, "pace")) for k in ("E", "M", "T", "RP", "I", "R")]
    rows = chart_rows(data, u.logs(pid))
    top = max(max(st["km"], d) for _, st, d in rows) or 1
    try:
        goal = progress.context(u, pid, data, t)["goal"]
    except (ValueError, KeyError, ZeroDivisionError):
        goal = None
    return page(request, "plan.html", data=data, z=z, zones=zones, weeks=rows, top=top, t=t, goal=goal,
                current=cur["index"] if cur else None, races=u.races(), time_off=u.time_off(),
                proposals=data.get("proposals", []))


def _replan_now(u: UserData):
    pid, data = u.active_plan()
    if data:
        replan(u, pid, data, clock())


@app.post("/plan/bump")
def accept_bump(request: Request):
    u = me(request)
    pid, data = u.active_plan()
    u.add_bump(pid, clock())
    replan(u, pid, data, clock())
    return RedirectResponse("/plan", status_code=303)


@app.post("/plan/race")
def add_race(request: Request, race_date: str = Form(...), distance: str = Form(...), name: str = Form("")):
    u = me(request)
    u.add_race(date.fromisoformat(race_date), parse_distance(distance), name.strip())
    _replan_now(u)
    return RedirectResponse("/plan#races", status_code=303)


@app.post("/plan/race/{rid}/delete")
def del_race(request: Request, rid: int):
    u = me(request)
    u.delete_race(rid)
    _replan_now(u)
    return RedirectResponse("/plan#races", status_code=303)


@app.post("/plan/off")
def add_off(request: Request, first: str = Form(...), last: str = Form(""), cross_trained: str = Form(""),
            reason: str = Form("")):
    u = me(request)
    u.add_time_off(date.fromisoformat(first), date.fromisoformat(last) if last else None,
                   cross_trained == "yes", reason)
    _replan_now(u)
    return RedirectResponse("/plan#off", status_code=303)


@app.post("/plan/off/{oid}/end")
def end_off(request: Request, oid: int, last: str = Form(...)):
    u = me(request)
    u.end_time_off(oid, date.fromisoformat(last))
    _replan_now(u)
    return RedirectResponse("/plan#off", status_code=303)


@app.post("/plan/off/{oid}/delete")
def del_off(request: Request, oid: int):
    u = me(request)
    u.delete_time_off(oid)
    _replan_now(u)
    return RedirectResponse("/plan#off", status_code=303)


# ---------------------------------------------------------------------- Log
@app.get("/log/{sid}", response_class=HTMLResponse)
def log_form(request: Request, sid: str):
    u = me(request)
    pid, data = u.active_plan()
    w, s, d = store.find_session(data or {"weeks": []}, sid)
    if s is None:
        raise HTTPException(404)
    return page(request, "log.html", v=session_view(data, w, s, u.logs(pid)), result=None, error=None)


@app.post("/log/{sid}", response_class=HTMLResponse)
def log_save(request: Request, sid: str, completed: str = Form(...), minutes: str = Form(""),
             rpe: str = Form(""), feel: str = Form(""), reserve: str = Form(""), avg_hr: str = Form(""),
             notes: str = Form(""), result: str = Form("")):
    u = me(request)
    pid, data = u.active_plan()
    w, s, d = store.find_session(data or {"weeks": []}, sid)
    if s is None:
        raise HTTPException(404)
    result_s = None
    if result.strip():
        try:
            result_s = parse_time_text(result)
        except ValueError:
            return page(request, "log.html", v=session_view(data, w, s, u.logs(pid)), result=None,
                        error="Write the finish time as mm:ss or h:mm:ss")
    z = store.zones_of(data, w)
    res = store.score_log(z, s, completed, _num(minutes), _num(rpe), feel or None, reserve == "yes", _num(avg_hr))
    u.save_log(pid, sid, d, completed=completed, minutes=_num(minutes), rpe=_num(rpe), feel=feel or None,
               reserve=1 if reserve == "yes" else 0, avg_hr=_num(avg_hr), notes=notes.strip() or None,
               score=res["score"], step=res["step"], flags=json.dumps(res["flags"]), result_s=result_s)
    n_events = len(u.events())
    replan(u, pid, data, max(clock(), d))
    events = u.events()
    res["changes"] = [e["text"] for e in events[:len(events) - n_events]]
    w, s, d = store.find_session(data, sid)
    return page(request, "log.html", v=session_view(data, w, s, u.logs(pid)), result=res, error=None)


# ------------------------------------------------------------ Morning check
@app.get("/check", response_class=HTMLResponse)
def check_form(request: Request, d: str | None = None):
    u = me(request)
    t = today(d)
    return page(request, "check.html", t=t, r=u.get_readiness(t), result=None, d=d)


@app.post("/check", response_class=HTMLResponse)
def check_save(request: Request, sleep: int = Form(...), soreness: int = Form(...), mood: int = Form(...),
               ill: str = Form(""), waking_hr: str = Form(""), d: str = Form("")):
    u = me(request)
    t = today(d or None)
    baseline = store.waking_hr_baseline(u.readiness_before(t, 7))
    hr = _num(waking_hr)
    level, flags = store.check_readiness(sleep, soreness, mood, ill == "yes", hr, baseline)
    prev = u.get_readiness(t)
    applied = prev["applied"] if prev else None
    changes = []
    pid, data = u.active_plan()
    # apply once per level: a later, worse check the same day can still downgrade further
    if data is not None and store.SEVERITY[level] > store.SEVERITY[applied]:
        changes = [nice_days(c) for c in store.apply_readiness(data, t, level)]
        if changes:
            u.save_plan_data(pid, data)
            for c in changes:
                u.add_event(pid, t, c.split(":")[0], c)
        applied = level
    u.save_readiness(t, sleep=sleep, soreness=soreness, mood=mood, ill=1 if ill == "yes" else 0, waking_hr=hr,
                     level=level, flags=json.dumps(flags), applied=applied)
    if data is not None:
        replan(u, pid, data, t)
    return page(request, "check.html", t=t, r=u.get_readiness(t), d=d or None,
                result={"level": level, "flags": flags, "changes": changes, "baseline": baseline})


# -------------------------------------------------------------------- Diary
@app.get("/diary", response_class=HTMLResponse)
def diary(request: Request):
    u = me(request)
    pid, data = u.active_plan()
    titles = {}
    if data:
        for w in data["weeks"]:
            for s in w["sessions"]:
                titles[s["id"]] = s["title"]
    return page(request, "diary.html", logs=u.all_logs(), readiness=u.all_readiness(),
                events=u.events(), titles=titles)


# ------------------------------------------------------- Setup / onboarding
def _preview(toml: str, start: str | None):
    t = clock()
    prof = profile_from_toml(toml, t)
    plan = build_plan(prof, t, date.fromisoformat(start) if start else None)
    new = store.plan_to_dict(plan)
    rows = [(w, store.week_stats(w), 0.0) for w in new["weeks"]]
    return new, rows


def _goal_preview(toml: str, new: dict):
    try:
        return progress.preview_check(toml, new, clock())
    except (ValueError, KeyError, ZeroDivisionError):
        return None


def _build(u: UserData, toml: str, new: dict):
    t = clock()
    u.save_profile(toml)
    pid = u.add_plan(new, toml)
    u.add_event(pid, t, "plan", f"New plan built: {len(new['weeks'])} weeks from {new['start']}, "
                                f"fitness (VDOT) {new['vdot']:.1f} from {new['fitness_basis']}")
    return RedirectResponse("/plan", status_code=303)


def _start_field(form) -> str | None:
    """The onboarding's start choice: today / tomorrow / next Monday / a date."""
    when = form.get("start_when") or "monday"
    t = clock()
    if when == "today":
        return t.isoformat()
    if when == "tomorrow":
        return (t + timedelta(days=1)).isoformat()
    if when == "date":
        return (form.get("start") or "").strip() or None
    return None


@app.get("/setup", response_class=HTMLResponse)
def setup_form(request: Request):
    u = me(request)
    pid, data = u.active_plan()
    v = PF.toml_to_values(u.get_profile())
    v.setdefault("start_when", "monday")
    return page(request, "onboarding.html", v=v, error=None, preview=None, has_plan=data is not None, step=0,
                t=clock())


@app.post("/setup", response_class=HTMLResponse)
async def setup_save(request: Request):
    u = me(request)
    form = await request.form()
    pid, data = u.active_plan()
    v = {k: form.get(k) for k in form.keys()}
    try:
        prof = PF.form_to_profile(form)
        toml = PF.to_toml(prof)
        new, rows = _preview(toml, _start_field(form))
    except (ValueError, KeyError, TypeError) as e:
        msg = str(e)
        where = [(0, ("Birth", "Years")), (1, ("long-run", "3 days")), (2, ("weekly km", "Weeks off", "Easy pace")),
                 (3, ("Result", "result")), (5, ("Race date", "Target time"))]
        step = next((i for i, keys in where if any(k in msg for k in keys)), int(form.get("step") or 0))
        return page(request, "onboarding.html", v=v, error=msg, preview=None, has_plan=data is not None,
                    step=step, t=clock())
    if form.get("action") == "build":
        return _build(u, toml, new)
    return page(request, "onboarding.html", v=v, error=None, has_plan=data is not None, step=6, t=clock(),
                preview={"data": new, "weeks": rows, "top": max(st["km"] for _, st, _ in rows),
                         "goal": _goal_preview(toml, new)})


@app.get("/setup/toml", response_class=HTMLResponse)
def toml_form(request: Request):
    u = me(request)
    toml = u.get_profile() or EXAMPLE.read_text(encoding="utf-8")
    pid, data = u.active_plan()
    return page(request, "setup.html", toml=toml, preview=None, error=None, has_plan=data is not None)


@app.post("/setup/toml", response_class=HTMLResponse)
def toml_save(request: Request, toml: str = Form(...), action: str = Form("preview"), start: str = Form("")):
    u = me(request)
    toml = toml.replace("\r\n", "\n")
    pid, data = u.active_plan()
    try:
        new, rows = _preview(toml, start or None)
    except (tomllib.TOMLDecodeError, KeyError, ValueError, TypeError) as e:
        return page(request, "setup.html", toml=toml, preview=None, has_plan=data is not None,
                    error=f"{type(e).__name__}: {e}")
    if action == "build":
        return _build(u, toml, new)
    u.save_profile(toml)
    return page(request, "setup.html", toml=toml, error=None, has_plan=data is not None,
                preview={"data": new, "weeks": rows, "top": max(st["km"] for _, st, _ in rows),
                         "goal": _goal_preview(toml, new)})
