"""Routes. Run:  python -m uvicorn coach_app.main:app --reload   (from server/)."""
from __future__ import annotations

import base64
import json
import os
import re
import tomllib
import zlib
from datetime import date, datetime, timedelta
from pathlib import Path

from fastapi import FastAPI, Form, HTTPException, Query, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from coach_engine import analysis
from coach_engine.builder import build_plan
from coach_engine.fitness import fmt_pace, fmt_time, parse_distance, parse_time_text
from coach_engine.library import dist_name
from coach_engine.models import DAYS
from coach_engine.profile_io import profile_from_toml
from coach_engine.zones import ZONE_NAMES

from . import auth
from . import profile_form as PF
from . import icu
from . import pride
from . import progress
from . import seasons
from . import store
from . import trends
from .db import DB, UserData

HERE = Path(__file__).resolve().parent
# Phone mode: the app runs inside the phone's browser (phone/, Pyodide) for one person, with no
# accounts; sharing is a snapshot packed into the link instead of a link to a server.
PHONE = os.environ.get("COACH_PHONE") == "1"
EXAMPLE = HERE.parents[1] / "engine" / "examples" / "sample_10k.toml"
if not EXAMPLE.exists():                     # the phone bundle keeps it next to the app
    EXAMPLE = HERE / "sample_10k.toml"

app = FastAPI(title="RunningCoach")
if not PHONE:                     # on the phone the shell serves static/ itself
    app.mount("/static", StaticFiles(directory=HERE / "static"), name="static")
templates = Jinja2Templates(directory=HERE / "templates")
templates.env.globals.update(DAYS=DAYS, fmt_pace=fmt_pace, fmt_time=fmt_time, ZONE_NAMES=ZONE_NAMES,
                             STEP_TEXT=store.STEP_TEXT, fmt_min=store.fmt_min, PF=PF, dist_name=dist_name,
                             phone=PHONE, EXTRA_KINDS=store.EXTRA_KINDS, PRIORITY_TEXT=seasons.PRIORITY_TEXT,
                             dist_key=seasons.dist_key)
templates.env.filters["fromjson"] = lambda s: json.loads(s) if s else []

db: DB | None = None
_keys: dict = {}          # database path -> cookie signing key


def get_db() -> DB:
    global db
    if db is None:
        db = DB()
    return db


def key() -> bytes:
    path = get_db().path
    if path not in _keys:
        _keys[path] = auth.load_secret(path)
    return _keys[path]


def clock() -> date:
    """The real date; tests replace it."""
    return date.today()


def today(d: str | None = None) -> date:
    """?d=YYYY-MM-DD overrides the date (handy to look ahead or test)."""
    return date.fromisoformat(d) if d else clock()


# ------------------------------------------------------------------ accounts
class LoginNeeded(Exception):
    pass


@app.exception_handler(LoginNeeded)
def _to_login(request: Request, exc: LoginNeeded):
    return RedirectResponse("/login" if get_db().n_users() else "/register", status_code=303)


def phone_user() -> int:
    """Phone mode: the one person on this device (created on first use)."""
    u = get_db().user_by_name("me")
    return u["id"] if u else get_db().add_user("me", "Runner", "", "", is_admin=True)


def me(request: Request) -> UserData:
    """The logged-in person's data, or a redirect to the login page."""
    uid = phone_user() if PHONE else auth.read_cookie(key(), request.cookies.get(auth.COOKIE))
    user = get_db().user(uid) if uid else None
    if user is None:
        raise LoginNeeded()
    request.state.user = user
    return get_db().for_user(user["id"])


def logged_in(response, request: Request, uid: int):
    response.set_cookie(auth.COOKIE, auth.make_cookie(key(), uid), max_age=auth.MAX_AGE, httponly=True,
                        samesite="lax", secure=request.url.scheme == "https")
    return response


def public_base(request: Request) -> str:
    """Address to put in invite / share links. Links made while browsing on 127.0.0.1 would
    only work on this PC, so the public address wins: COACH_PUBLIC_URL, else the first line of
    public_url.txt next to the database (e.g. the Tailscale Funnel address)."""
    url = os.environ.get("COACH_PUBLIC_URL", "").strip()
    f = get_db().path.with_name("public_url.txt")
    if not url and f.exists():
        lines = f.read_text(encoding="utf-8").split()
        url = lines[0] if lines else ""
    if PHONE:
        return url              # the app's own page (…/coach/): share links add #/view/…
    return (url or str(request.base_url)).rstrip("/")


def page(request: Request, name: str, **ctx):
    ctx.setdefault("user", getattr(request.state, "user", None))
    return templates.TemplateResponse(request, name, ctx)


def nice_days(text: str) -> str:
    return re.sub(r"day (\d)", lambda m: DAYS[int(m.group(1))], text)


def _num(x: str | None):
    return float(x) if x not in (None, "") else None


def replan(u: UserData, pid: int, data: dict, t: date):
    data["proposals"] = store.run_replan(u, pid, data, t)
    data["replanned_on"] = t.isoformat()
    u.save_plan_data(pid, data)


def active(u: UserData, t: date | None = None):
    """(pid, data) of the active plan; re-planned once a day so weekly reviews happen on time."""
    pid, data = u.active_plan()
    if data is not None and t is not None and data.get("replanned_on") != t.isoformat():
        replan(u, pid, data, t)
    return pid, data


def session_view(data: dict, w: dict, s: dict, logs: dict, heat: float = 0.0) -> dict:
    z = store.heat_zones(store.zones_of(data, w), heat)
    return {
        "s": s, "date": date.fromisoformat(w["start"]) + timedelta(days=s["day"]),
        "lines": store.segment_lines(z, s), "km": store.session_km(s), "minutes": store.session_minutes(s),
        "explain": store.explain_total(s), "feel": store.target_rpe(s), "bar": store.zone_bar(s),
        "log": logs.get(s["id"]),
    }


def loose_activities(u: UserData, pid: int, first: date, last: date) -> list:
    """Watch activities between two dates that show nowhere else: not a session of this plan and not
    an extra (runs before the plan starts, or matched to an older plan)."""
    return [a for a in u.activities(first) if a["date"] <= last.isoformat() and a["extra_id"] is None
            and not (a["plan_id"] == pid and a["session_id"])]


def week_strip(w: dict, logs: dict, t: date, first_day: date) -> list:
    out = []
    start = date.fromisoformat(w["start"])
    for i in range(7):
        d = start + timedelta(days=i)
        runs = [s for s in w["sessions"] if s["day"] == i and s["kind"] not in ("rest", "strength")]
        main = max(runs, key=lambda s: (s["hard"], s["kind"] == "long", store.session_km(s)), default=None)
        logged = [logs[s["id"]] for s in runs if s["id"] in logs]
        out.append({"day": DAYS[i][0], "date": d, "kind": main["kind"] if main else "rest",
                    "hard": bool(main and main["hard"]), "today": d == t, "off": d < first_day,
                    "done": bool(logged) and all(l["completed"] != "no" for l in logged),
                    "missed": any(l["completed"] == "no" for l in logged)})
    return out


def week_done(w: dict, logs: dict, extras=()) -> float:
    """km done in a week: logged sessions plus extra runs."""
    return sum(store.done_km(s, logs.get(s["id"])) for s in w["sessions"]) + \
        store.extra_km(extras, w["start"], store.week_end(w))


def chart_rows(data: dict, logs: dict, extras=()) -> list:
    return [(w, store.week_stats(w), week_done(w, logs, extras)) for w in data["weeks"]]


def long_rows(data: dict) -> list:
    """(week, long-run km, race / time-trial km) per week, for the long-run chart on Plan."""
    out = []
    for w in data["weeks"]:
        lr = max([store.session_km(s) for s in w["sessions"] if s["kind"] == "long"] or [0.0])
        tt = max([sum(g["km"] for g in s["segments"] if g["zone"] == "TT") for s in w["sessions"]
                  if s["kind"] == "tt"] or [0.0])
        out.append((w, lr, tt))
    return out


def backup_due(t: date) -> int | None:
    """Phone app: days since the last backup when it is time for one (-1 = never backed up)."""
    if not PHONE:
        return None
    u = get_db().user(phone_user())
    if u["backup_at"]:
        days = (t - date.fromisoformat(u["backup_at"][:10])).days
        return days if days >= store.BACKUP_EVERY else None
    first = get_db().con.execute("SELECT MIN(created) FROM plan").fetchone()[0]
    return -1 if first and (t - date.fromisoformat(first[:10])).days >= 3 else None


# ----------------------------------------------------------------- PWA bits
@app.get("/sw.js")
def service_worker():
    return FileResponse(HERE / "static" / "sw.js", media_type="text/javascript",
                        headers={"Service-Worker-Allowed": "/"})


@app.get("/manifest.webmanifest")
def manifest():
    return FileResponse(HERE / "static" / "manifest.webmanifest", media_type="application/manifest+json")


# ------------------------------------------------------ login / register
@app.get("/login", response_class=HTMLResponse)
def login_form(request: Request):
    if PHONE:
        return RedirectResponse("/today")
    if not get_db().n_users():
        return RedirectResponse("/register")
    return page(request, "login.html", error=None, username="")


@app.post("/login", response_class=HTMLResponse)
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    u = get_db().user_by_name(username)
    if u is None or not auth.check_pw(password, u["pw"], u["salt"]):
        return page(request, "login.html", error="Wrong username or password.", username=username)
    return logged_in(RedirectResponse("/today", status_code=303), request, u["id"])


@app.post("/logout")
def logout():
    r = RedirectResponse("/login", status_code=303)
    r.delete_cookie(auth.COOKIE)
    return r


@app.get("/register", response_class=HTMLResponse)
def register_form(request: Request, code: str = ""):
    if PHONE:
        return RedirectResponse("/today")
    first = get_db().n_users() == 0
    ok = first or get_db().invite(code) is not None
    return page(request, "register.html", first=first, code=code, ok=ok, error=None, v={})


@app.post("/register", response_class=HTMLResponse)
def register(request: Request, username: str = Form(...), name: str = Form(...), password: str = Form(...),
             code: str = Form("")):
    dbx = get_db()
    first = dbx.n_users() == 0
    v = {"username": username, "name": name}
    err = None
    if not first and dbx.invite(code) is None:
        err = "This invite link has been used or isn't valid. Ask for a new one."
    elif not re.fullmatch(r"[A-Za-z0-9_.-]{3,30}", username.strip()):
        err = "Username: 3-30 letters, digits, dots, dashes or underscores."
    elif dbx.user_by_name(username):
        err = "That username is taken."
    elif len(password) < 8:
        err = "Password: at least 8 characters."
    if err:
        return page(request, "register.html", first=first, code=code, ok=True, error=err, v=v)
    pw, salt = auth.hash_pw(password)
    uid = dbx.add_user(username, name or username, pw, salt, is_admin=first)
    if not first:
        dbx.use_invite(code, uid)
    return logged_in(RedirectResponse("/setup", status_code=303), request, uid)


# ------------------------------------------------------------------- Me
@app.get("/me", response_class=HTMLResponse)
def me_page(request: Request):
    """Your running: fitness, volume, results, zones. Settings has the rest."""
    u = me(request)
    t = clock()
    pid, data = active(u, t)
    if data is None:
        return page(request, "me.html", data=None)
    return page(request, "me.html", data=data, t=t, pbs=pride.pb_wall(u, pid, data, t), streak=pride.streak(u, t),
                **progress.me_stats(u, pid, data, t))


@app.get("/settings", response_class=HTMLResponse)
def settings_page(request: Request, new: str = "", icu_msg: str = Query("", alias="icu")):
    u = me(request)
    pid, data = u.active_plan()
    base = public_base(request)
    admin = bool(request.state.user["is_admin"])
    return page(request, "settings.html", data=data, shares=u.shares(), base=base, new=new,
                invites=get_db().invites() if admin else [], people=get_db().users() if admin else [],
                admin=admin, msg=None, icu=u.icu(), icu_msg=icu_msg[:300] or None)


@app.post("/settings/backed-up")
def backed_up(request: Request):
    """The phone shell calls this after a backup was saved (or shared)."""
    me(request)
    get_db().set_backup(request.state.user["id"])
    return JSONResponse({"ok": True})


@app.post("/me/share")
def new_share(request: Request):
    if PHONE:
        return RedirectResponse(f"/settings?new={snapshot(me(request), request.state.user)}#share", status_code=303)
    tok = me(request).new_share()
    return RedirectResponse(f"/settings?new={tok}#share", status_code=303)


@app.post("/me/name")
def set_name(request: Request, name: str = Form(...)):
    me(request)
    get_db().set_name(request.state.user["id"], name.strip()[:40] or "Runner")
    return RedirectResponse("/settings", status_code=303)


@app.post("/me/share/{token}/delete")
def del_share(request: Request, token: str):
    me(request).delete_share(token)
    return RedirectResponse("/settings#share", status_code=303)


@app.post("/me/invite")
def new_invite(request: Request, note: str = Form("")):
    me(request)
    if not request.state.user["is_admin"]:
        raise HTTPException(403)
    code = get_db().new_invite(request.state.user["id"], note)
    return RedirectResponse(f"/settings?new={code}#people", status_code=303)


@app.post("/me/invite/{code}/delete")
def del_invite(request: Request, code: str):
    me(request)
    if not request.state.user["is_admin"]:
        raise HTTPException(403)
    get_db().delete_invite(code)
    return RedirectResponse("/settings#people", status_code=303)


@app.post("/me/password", response_class=HTMLResponse)
def change_password(request: Request, old: str = Form(...), new: str = Form(...)):
    u = me(request)
    usr = request.state.user
    if not auth.check_pw(old, usr["pw"], usr["salt"]):
        msg = "Current password is wrong."
    elif len(new) < 8:
        msg = "New password: at least 8 characters."
    else:
        get_db().set_password(usr["id"], *auth.hash_pw(new))
        msg = "Password changed."
    pid, data = u.active_plan()
    admin = bool(usr["is_admin"])
    return page(request, "settings.html", data=data, shares=u.shares(), base=public_base(request), new="",
                invites=get_db().invites() if admin else [], people=get_db().users() if admin else [],
                admin=admin, msg=msg, icu=u.icu(), icu_msg=None)


# ------------------------------------------------- watch data (intervals.icu)
@app.post("/icu/connect")
async def icu_connect(request: Request, api_key: str = Form(...), athlete_id: str = Form("")):
    u = me(request)
    key, aid = api_key.strip(), athlete_id.strip()
    msg = None
    try:
        if not key:
            raise icu.IcuError("paste the API key from intervals.icu")
        aid = await icu.check_key(aid, key)
    except icu.IcuError as e:
        msg = str(e)[0].upper() + str(e)[1:] + "."
    if msg is None:
        u.set_icu(aid, key)
        res = await icu.sync(u, clock())
        if res["new"]:
            _replan_now(u)
        msg = sync_text(res, first=True)
    # back to Settings (a reload must not re-send the key); the message rides along in the address
    from urllib.parse import quote
    return RedirectResponse(f"/settings?icu={quote(msg)}#garmin", status_code=303)


@app.post("/icu/disconnect")
def icu_disconnect(request: Request):
    me(request).delete_icu()
    return RedirectResponse("/settings#garmin", status_code=303)


def sync_text(res: dict, first: bool = False) -> str:
    if res["error"]:
        return res["error"][0].upper() + res["error"][1:] + "."
    bits = []
    if res["logged"]:
        bits.append(f"{len(res['logged'])} planned session{'s' if len(res['logged']) != 1 else ''} logged")
    if res["extras"]:
        bits.append(f"{res['extras']} other activit{'ies' if res['extras'] != 1 else 'y'} added")
    txt = ("Connected. " if first else "") + (", ".join(bits) + "." if bits else "Nothing new from the watch.")
    if res["skipped_strava"]:
        n = res["skipped_strava"]
        txt += (f" {n} activit{'ies' if n != 1 else 'y'} came from Strava and can't be read: "
                f"link your watch to intervals.icu directly (Garmin) or through HealthFit (Apple Watch).")
    return txt


@app.post("/api/sync")
async def api_sync(request: Request, force: int = 0):
    """Fetch new activities from the watch (Today calls this on its own)."""
    u = me(request)
    if not force and not icu.due(u.icu()):
        return JSONResponse({"changed": False, "skipped": True})
    res = await icu.sync(u, clock())
    if res["new"]:
        _replan_now(u)
    return JSONResponse({"changed": res["changed"], "text": sync_text(res), "error": res["error"]})


# ------------------------------------------------------- read-only share
@app.get("/s/{token}", response_class=HTMLResponse)
def shared(request: Request, token: str):
    uid = get_db().share_owner(token)
    if uid is None:
        raise HTTPException(404, "This link has been switched off.")
    u = get_db().for_user(uid)
    pid, data = u.active_plan()
    owner = get_db().user(uid)
    if data is None:
        return page(request, "shared.html", owner=owner, data=None, user=None)
    return shared_page(request, owner, data, u.logs(pid), clock(), extras=u.extras())


SNAP_PRIVATE = ("notes", "avg_hr")           # what a shared plan never shows


def snapshot(u: UserData, user) -> str:
    """Phone mode: the plan and its logs as it is now, packed into the share link (zlib + base64)."""
    pid, data = u.active_plan()
    if data is None:
        raise HTTPException(400, "Build a plan first.")
    logs = {k: {c: r[c] for c in r.keys() if c not in SNAP_PRIVATE} for k, r in u.logs(pid).items()}
    extras = [{c: x[c] for c in ("date", "kind", "minutes", "km", "rpe")} for x in u.extras()]
    snap = {"v": 1, "name": user["name"], "at": clock().isoformat(), "data": data, "logs": logs, "extras": extras}
    raw = json.dumps(snap, separators=(",", ":")).encode()
    return base64.urlsafe_b64encode(zlib.compress(raw, 9)).decode().rstrip("=")


@app.get("/view", response_class=HTMLResponse)
def view_snapshot(request: Request, p: str):
    """A shared snapshot (phone mode): read-only, nothing of it is stored."""
    try:
        snap = json.loads(zlib.decompress(base64.urlsafe_b64decode(p + "=" * (-len(p) % 4))))
    except (ValueError, zlib.error):
        raise HTTPException(400, "This link is incomplete: ask for it again.")
    t = max(clock(), date.fromisoformat(snap["at"]))
    return shared_page(request, {"name": snap["name"]}, snap["data"], snap["logs"], t, snap_at=snap["at"],
                       extras=snap.get("extras", []))


def shared_page(request: Request, owner, data: dict, logs: dict, t: date, snap_at: str | None = None,
                extras=()):
    w, _ = store.week_for(data, t)
    w = w or data["weeks"][0 if t < date.fromisoformat(data["start"]) else -1]
    days = [(i, date.fromisoformat(w["start"]) + timedelta(days=i),
             [session_view(data, w, s, logs) for s in w["sessions"] if s["day"] == i]) for i in range(7)]
    rows = chart_rows(data, logs, extras)
    return page(request, "shared.html", owner=owner, data=data, w=w, days=days, t=t, user=None,
                weeks=rows, top=max(max(st["km"], d) for _, st, d in rows) or 1, current=w["index"],
                stats=store.week_stats(w), done=week_done(w, logs, extras), snap_at=snap_at)


# -------------------------------------------------------------------- Today
@app.get("/")
def root():
    return RedirectResponse("/today")


@app.get("/today", response_class=HTMLResponse)
def today_page(request: Request, d: str | None = None):
    u = me(request)
    t = today(d)
    pid, data = active(u, t)
    if data is None:
        return RedirectResponse("/setup")
    logs = u.logs(pid)
    extras = u.extras()
    w, day = store.week_for(data, t)
    start, end = date.fromisoformat(data["start"]), store.plan_end(data)
    sessions, strip, done = [], [], 0.0
    upcoming, upcoming_date = [], None
    readiness = u.get_readiness(t)
    heat, heat_txt = store.day_heat(readiness)
    if w is not None and t >= start:
        sessions = [session_view(data, w, s, logs, heat) for s in w["sessions"] if s["day"] == day]
        strip = week_strip(w, logs, t, start)
        done = week_done(w, logs, extras)
    if not any(v["s"]["kind"] not in ("rest", "strength") for v in sessions):
        # rest day (or before the start): the next training day, with everything planned on it
        for k in range(1, 8):
            nd = t + timedelta(days=k)
            nw, nday = store.week_for(data, nd)
            if nw is None or nd < start:
                continue
            todo = [s for s in nw["sessions"] if s["day"] == nday and s["kind"] != "rest"]
            if any(s["kind"] != "strength" for s in todo):
                upcoming = [session_view(data, nw, s, logs) for s in todo]
                upcoming_date = nd
                break
    hour = datetime.now().hour
    hello = "Good morning" if hour < 12 else "Good afternoon" if hour < 18 else "Good evening"
    real = clock()
    nav = {"prev": t - timedelta(days=1), "next": t + timedelta(days=1), "real": real, "is_real": t == real}
    return page(request, "today.html", t=t, data=data, week=w, sessions=sessions, before=t < start,
                after=t > end, start=start, upcoming=upcoming, upcoming_date=upcoming_date,
                readiness=readiness, heat_txt=heat_txt, d=d, strip=strip,
                done=done, stats=store.week_stats(w) if w else None, proposals=data.get("proposals", []),
                hello=hello, glance=None if t > end else progress.today_summary(u, pid, data, t),
                extras=[x for x in extras if x["date"] == t.isoformat()], backup=backup_due(t),
                icu_due=icu.due(u.icu()) and d is None, icu_cfg=u.icu(), streak=pride.streak(u, t), nav=nav,
                watch=loose_activities(u, pid, t, t),
                undo=t.isoformat() in (data.get("undo") or {}))


@app.post("/today/undo")
def today_undo(request: Request, d: str = Form(...)):
    """Put back the day's sessions as planned (before the morning check / pain changes)."""
    u = me(request)
    pid, data = u.active_plan()
    day = date.fromisoformat(d)
    if data is not None and store.undo_day(data, day):
        u.save_plan_data(pid, data)
        u.add_event(pid, day, "undo", f"{day:%a %d %b}: the morning-check / pain changes were undone")
    return RedirectResponse("/today" + ("" if day == clock() else f"?d={d}"), status_code=303)


# ----------------------------------------------------------------- Progress
@app.get("/progress", response_class=HTMLResponse)
def progress_page(request: Request):
    u = me(request)
    t = clock()
    pid, data = active(u, t)
    if data is None:
        return RedirectResponse("/setup")
    return page(request, "progress.html", data=data, t=t, tr=trends.watch_trends(u, pid, data, t), A=analysis,
                **progress.context(u, pid, data, t))


@app.get("/api/goal")
def goal_api(request: Request, distance: str = "10k", target: str = "", when: str = ""):
    """The what-if goal check on the Progress page (JSON)."""
    u = me(request)
    t = clock()
    pid, data = u.active_plan()
    if data is None:
        raise HTTPException(404)
    try:
        return progress.what_if(u, pid, data, t, distance, target, when)
    except (ValueError, KeyError) as e:
        return {"error": str(e) if "past" in str(e) else "Write the time as mm:ss or h:mm:ss"}


# --------------------------------------------------------------------- Week
@app.get("/week", response_class=HTMLResponse)
def week_current(request: Request, d: str | None = None):
    u = me(request)
    pid, data = u.active_plan()
    if data is None:
        return RedirectResponse("/setup")
    w, _ = store.week_for(data, today(d))
    n = w["index"] if w else (1 if today(d) < date.fromisoformat(data["start"]) else len(data["weeks"]))
    return RedirectResponse(f"/week/{n}")


@app.get("/week/{n}", response_class=HTMLResponse)
def week_page(request: Request, n: int):
    u = me(request)
    t = clock()
    pid, data = active(u, t)
    if data is None:
        return RedirectResponse("/setup")
    if not 1 <= n <= len(data["weeks"]):
        raise HTTPException(404)
    w = data["weeks"][n - 1]
    logs = u.logs(pid)
    extras = u.extras(date.fromisoformat(w["start"]), date.fromisoformat(store.week_end(w)))
    first_day = date.fromisoformat(data["start"])
    loose = loose_activities(u, pid, date.fromisoformat(w["start"]), date.fromisoformat(store.week_end(w)))
    days = []
    for i in range(7):
        d = date.fromisoformat(w["start"]) + timedelta(days=i)
        days.append((i, d, [session_view(data, w, s, logs) for s in w["sessions"] if s["day"] == i],
                     [x for x in extras if x["date"] == d.isoformat()],
                     [a for a in loose if a["date"] == d.isoformat()]))
    return page(request, "week.html", w=w, n=n, total=len(data["weeks"]), days=days, first_day=first_day,
                stats=store.week_stats(w), t=t, done=week_done(w, logs, extras))


# --------------------------------------------------------------------- Plan
@app.get("/plan", response_class=HTMLResponse)
def plan_page(request: Request):
    u = me(request)
    t = clock()
    pid, data = active(u, t)
    if data is None:
        return RedirectResponse("/setup")
    cur, _ = store.week_for(data, t)
    rows = chart_rows(data, u.logs(pid), u.extras())
    top = max(max(st["km"], d) for _, st, d in rows) or 1
    try:
        goal = progress.context(u, pid, data, t)["goal"]
    except (ValueError, KeyError, ZeroDivisionError):
        goal = None
    return page(request, "plan.html", data=data, weeks=rows, top=top, t=t, goal=goal, longs=long_rows(data),
                end=store.plan_end(data),
                current=cur["index"] if cur else None, races=u.races(), time_off=u.time_off(),
                proposals=data.get("proposals", []),
                season_races=[r for r in seasons.season_races(u) if r.date > t],
                race_sid=next((s["id"] for s in data["weeks"][-1]["sessions"] if s["kind"] == "tt"), None))


def _replan_now(u: UserData):
    pid, data = u.active_plan()
    if data:
        replan(u, pid, data, clock())


@app.post("/plan/bump")
def accept_bump(request: Request):
    u = me(request)
    pid, data = u.active_plan()
    u.add_bump(pid, clock())
    replan(u, pid, data, clock())
    return RedirectResponse("/plan", status_code=303)


@app.post("/plan/race")
def add_race(request: Request, race_date: str = Form(...), distance: str = Form(...), name: str = Form("")):
    u = me(request)
    u.add_race(date.fromisoformat(race_date), parse_distance(distance), name.strip())
    _replan_now(u)
    return RedirectResponse("/plan#races", status_code=303)


@app.post("/plan/race/{rid}/delete")
def del_race(request: Request, rid: int):
    u = me(request)
    u.delete_race(rid)
    _replan_now(u)
    return RedirectResponse("/plan#races", status_code=303)


@app.post("/plan/off")
def add_off(request: Request, first: str = Form(...), last: str = Form(""), cross_trained: str = Form(""),
            reason: str = Form("")):
    u = me(request)
    u.add_time_off(date.fromisoformat(first), date.fromisoformat(last) if last else None,
                   cross_trained == "yes", reason)
    _replan_now(u)
    return RedirectResponse("/plan#off", status_code=303)


@app.post("/plan/off/{oid}/end")
def end_off(request: Request, oid: int, last: str = Form(...)):
    u = me(request)
    u.end_time_off(oid, date.fromisoformat(last))
    _replan_now(u)
    return RedirectResponse("/plan#off", status_code=303)


@app.post("/plan/off/{oid}/delete")
def del_off(request: Request, oid: int):
    u = me(request)
    u.delete_time_off(oid)
    _replan_now(u)
    return RedirectResponse("/plan#off", status_code=303)


# ------------------------------------------------------------------- Season
def season_page(request: Request, u: UserData, error: str | None = None):
    t = clock()
    pid, data = u.active_plan()
    view = seasons.compute(u, t)
    season = view["season"]
    startable = None
    if season and season.blocks and view["active"] is None:
        startable = next((i for i, b in enumerate(season.blocks) if b.kind != "recovery"), None)
    return page(request, "season.html", t=t, season=season, races=view["races"], active=view["active"],
                startable=startable, tl=seasons.timeline(season, t), has_plan=data is not None,
                plan_end=store.plan_end(data) if data else None, has_profile=u.get_profile() is not None,
                beginner=view.get("beginner", False), error=error)


@app.get("/season", response_class=HTMLResponse)
def season_get(request: Request):
    return season_page(request, me(request))


@app.post("/season/race", response_class=HTMLResponse)
def season_add(request: Request, race_date: str = Form(...), distance: str = Form(...), priority: str = Form("A"),
               name: str = Form(""), target: str = Form("")):
    u = me(request)
    try:
        d = date.fromisoformat(race_date)
        if d <= clock():
            raise ValueError("pick a date in the future")
        if priority not in ("A", "B", "C"):
            raise ValueError("pick how important the race is")
        target_s = parse_time_text(target) if target.strip() else None
    except ValueError as e:
        msg = str(e) if "future" in str(e) or "important" in str(e) else "write the target time as mm:ss or h:mm:ss"
        return season_page(request, u, error=msg[0].upper() + msg[1:] + ".")
    rid = u.add_season_race(d, parse_distance(distance), priority, name.strip()[:60], target_s)
    if seasons.sync_b_race(u, rid, clock()):
        _replan_now(u)
    return RedirectResponse("/season", status_code=303)


@app.post("/season/race/{rid}", response_class=HTMLResponse)
def season_edit(request: Request, rid: int, race_date: str = Form(...), distance: str = Form(...),
                priority: str = Form("A"), name: str = Form(""), target: str = Form("")):
    """Change a race. A new target for the race of the active plan applies to that plan straight away;
    a new date or distance for it takes effect when the block is started again."""
    u = me(request)
    old = u.season_race(rid)
    if old is None:
        raise HTTPException(404)
    try:
        d = date.fromisoformat(race_date)
        if priority not in ("A", "B", "C"):
            raise ValueError("pick how important the race is")
        target_s = parse_time_text(target) if target.strip() else None
    except ValueError as e:
        msg = str(e) if "important" in str(e) else "write the target time as mm:ss or h:mm:ss"
        return season_page(request, u, error=msg[0].upper() + msg[1:] + ".")
    m = parse_distance(distance)
    pid, data = u.active_plan()
    g = data["goal"] if data else {}
    is_active = bool(data and g.get("race_date") == old["date"] and abs(g.get("distance_m", 0) - old["distance_m"]) < 1)
    u.update_season_race(rid, d, m, priority, name.strip()[:60], target_s)
    if is_active and d.isoformat() == old["date"] and abs(m - old["distance_m"]) < 1 and target_s != g.get("target_time_s"):
        # the plan's own goal time: profile and plan both, then re-plan
        import tomllib as _t
        prof = _t.loads(u.plan_profile(pid))
        prof.setdefault("goal", {})
        if target_s:
            prof["goal"]["target_time"] = fmt_time(target_s)
        else:
            prof["goal"].pop("target_time", None)
        g["target_time_s"] = target_s
        u.set_plan_goal_target(pid, target_s, PF.to_toml(prof), data)
    seasons.sync_b_race(u, rid, clock())
    _replan_now(u)
    return RedirectResponse("/season#races", status_code=303)


@app.post("/season/race/{rid}/delete")
def season_delete(request: Request, rid: int):
    u = me(request)
    linked = any(r["season_id"] == rid for r in u.races())
    u.delete_season_race(rid)
    if linked:
        _replan_now(u)
    return RedirectResponse("/season#races", status_code=303)


@app.post("/season/start")
def season_start(request: Request, index: int = Form(...)):
    u = me(request)
    seasons.start_block(u, clock(), index)
    _replan_now(u)
    return RedirectResponse("/plan", status_code=303)


# ---------------------------------------------------------------------- Log
@app.get("/log/{sid}", response_class=HTMLResponse)
def log_form(request: Request, sid: str):
    u = me(request)
    pid, data = u.active_plan()
    w, s, d = store.find_session(data or {"weeks": []}, sid)
    if s is None:
        raise HTTPException(404)
    return page(request, "log.html", v=session_view(data, w, s, u.logs(pid)), result=None, error=None,
                watch=watch_view(u, pid, data, w, s))


def watch_view(u: UserData, pid: int, data: dict, w: dict, s: dict) -> dict | None:
    """What the watch recorded for this session: totals, the reps against their target, drift."""
    a = u.activity_for_session(pid, s["id"])
    if a is None:
        return None
    laps = json.loads(a["laps"] or "[]")
    reps, band = icu.reps_for(data, w, s, laps) if s["kind"] == "quality" else ([], None)
    long_enough = s["kind"] == "long" and (a["minutes"] or 0) >= 60
    return {"a": a, "pace": analysis.pace(a["gap"] or a["speed"]), "reps": reps, "band": band,
            "summary": analysis.rep_summary(reps, band) if band else "",
            "drift": analysis.decoupling_note(a["decoupling"]) if long_enough else ""}


@app.post("/log/{sid}", response_class=HTMLResponse)
def log_save(request: Request, sid: str, completed: str = Form(...), minutes: str = Form(""),
             rpe: str = Form(""), feel: str = Form(""), reserve: str = Form(""), avg_hr: str = Form(""),
             notes: str = Form(""), result: str = Form("")):
    u = me(request)
    pid, data = u.active_plan()
    w, s, d = store.find_session(data or {"weeks": []}, sid)
    if s is None:
        raise HTTPException(404)
    result_s = None
    if result.strip():
        try:
            result_s = parse_time_text(result)
        except ValueError:
            return page(request, "log.html", v=session_view(data, w, s, u.logs(pid)), result=None,
                        error="Write the finish time as mm:ss or h:mm:ss", watch=None)
    z = store.zones_of(data, w)
    res = store.score_log(z, s, completed, _num(minutes), _num(rpe), feel or None, reserve == "yes", _num(avg_hr))
    old = u.get_log(pid, sid)
    from_watch = bool(old and (old["source"] or "").startswith("icu"))
    u.save_log(pid, sid, d, completed=completed, minutes=_num(minutes), rpe=_num(rpe), feel=feel or None,
               reserve=1 if reserve == "yes" else 0, avg_hr=_num(avg_hr), notes=notes.strip() or None,
               score=res["score"], step=res["step"], flags=json.dumps(res["flags"]), result_s=result_s,
               source="icu+me" if from_watch else None,
               km=old["km"] if from_watch and completed != "no" else None)
    n_events = len(u.events())
    replan(u, pid, data, max(clock(), d))
    events = u.events()
    res["changes"] = [e["text"] for e in events[:len(events) - n_events]]
    w, s, d = store.find_session(data, sid)
    return page(request, "log.html", v=session_view(data, w, s, u.logs(pid)), result=res, error=None,
                watch=watch_view(u, pid, data, w, s))


# ------------------------------------------------------------ recap, calendar
@app.get("/recap", response_class=HTMLResponse)
def recap_page(request: Request):
    u = me(request)
    t = clock()
    pid, data = active(u, t)
    if data is None:
        return RedirectResponse("/setup")
    tr = trends.watch_trends(u, pid, data, t)
    return page(request, "recap.html", r=pride.recap(u, pid, data, t, tr), t=t)


@app.get("/help/watch", response_class=HTMLResponse)
def help_watch_page(request: Request):
    """Step-by-step: Garmin / Apple Watch → intervals.icu → this app."""
    return page(request, "help_watch.html", icu=me(request).icu())


@app.get("/plan.ics")
def plan_ics(request: Request):
    u = me(request)
    pid, data = u.active_plan()
    if data is None:
        raise HTTPException(404)
    from fastapi.responses import Response
    return Response(pride.ics(data, f"RunningCoach - {request.state.user['name']}"), media_type="text/calendar",
                    headers={"Content-Disposition": 'attachment; filename="runningcoach.ics"'})


# ---------------------------------------------------------------- Race plan
@app.get("/race/{sid}", response_class=HTMLResponse)
def race_page(request: Request, sid: str, temp: str = "", hum: str = "", goal: str = "", mine: str = ""):
    """The race-day plan for a race or time trial: splits, warm-up timing, fuelling (spec §13)."""
    from coach_engine.conditions import race_plan
    from coach_engine.fitness import race_time
    u = me(request)
    pid, data = u.active_plan()
    w, s, d = store.find_session(data or {"weeks": []}, sid)
    if s is None or s["kind"] != "tt":
        raise HTTPException(404)
    m = round(sum(g["km"] for g in s["segments"] if g["zone"] == "TT") * 1000, 1)
    final = w["index"] == len(data["weeks"])
    predicted = data["target_time_s"] if final and data.get("target_time_s") and \
        abs(m - data["goal"]["distance_m"]) < 1 else race_time(store.zones_of(data, w).vdot, m)
    own = data["goal"].get("target_time_s") if abs(m - data["goal"]["distance_m"]) < 1 else None
    custom = None
    goal = mine.strip() or goal
    if goal and goal not in ("predicted", "own"):
        try:
            custom = parse_time_text(goal)                # a time of your own
        except ValueError:
            custom = None
    choice = "custom" if custom else (goal if goal in ("predicted", "own") else "predicted")
    goal_s = own if choice == "own" and own else predicted
    rd = u.get_readiness(d)
    t_c = _num(temp.replace(",", ".")) if temp.strip() else (rd["temp_c"] if rd and rd["temp_c"] is not None else None)
    humidity = hum if hum in ("dry", "normal", "humid") else (rd["humidity"] if rd and rd["humidity"] else "normal")
    rp = race_plan(m, custom or goal_s, t_c, humidity)
    return page(request, "race.html", s=s, d=d, rp=rp, m=m, predicted=predicted, own=own, choice=choice,
                custom=custom, temp=t_c, humidity=humidity, final=final)


# ------------------------------------------------------------ Morning check
@app.get("/check", response_class=HTMLResponse)
def check_form(request: Request, d: str | None = None):
    u = me(request)
    t = today(d)
    return page(request, "check.html", t=t, r=u.get_readiness(t), result=None, d=d, **watch_morning(u, t))


def watch_morning(u: UserData, t: date) -> dict:
    """The watch's night: sleep and resting HR to pre-fill the check, an HRV line to show."""
    wl = u.wellness_on(t)
    return {"wsleep": icu.sleep_scale(wl), "whr": wl["resting_hr"] if wl else None,
            "hrv": icu.hrv_note(u.wellness(t - timedelta(days=8)), wl), "today_pain": u.niggles_on(t)}


@app.post("/check", response_class=HTMLResponse)
def check_save(request: Request, sleep: int = Form(...), soreness: int = Form(...), mood: int = Form(...),
               ill: str = Form(""), waking_hr: str = Form(""), d: str = Form(""), temp_c: str = Form(""),
               humidity: str = Form("normal"), pain_area: str = Form(""), pain: int = Form(0), gait: str = Form("")):
    u = me(request)
    t = today(d or None)
    baseline = store.waking_hr_baseline(u.readiness_before(t, 7))
    hr = _num(waking_hr)
    level, flags = store.check_readiness(sleep, soreness, mood, ill == "yes", hr, baseline)
    prev = u.get_readiness(t)
    applied = prev["applied"] if prev else None
    changes = []
    pid, data = u.active_plan()
    # apply once per level: a later, worse check the same day can still downgrade further
    if data is not None and store.SEVERITY[level] > store.SEVERITY[applied]:
        changes = [nice_days(c) for c in store.apply_readiness(data, t, level)]
        if changes:
            u.save_plan_data(pid, data)
            for c in changes:
                u.add_event(pid, t, c.split(":")[0], c)
        applied = level
    # S33: pain - today's runs become cross-training or easy (once per severity per day)
    niggle = None
    if pain_area in PF.AREAS and (pain > 0 or gait == "yes"):
        from coach_engine import adapt
        action = adapt.niggle_action(pain, gait == "yes")
        before = max([store.NIGGLE_RANK[n["action"]] for n in u.niggles_on(t)] + [0])
        if data is not None and store.NIGGLE_RANK[action] > before:
            prof = profile_from_toml(u.plan_profile(pid), date.fromisoformat(data["created"]))
            ch = [nice_days(c) for c in store.apply_niggle(data, t, action, prof.availability.cross_training)]
            if ch:
                u.save_plan_data(pid, data)
                for c in ch:
                    u.add_event(pid, t, "S33", c)
                changes += ch
        u.save_niggle(t, pain_area, pain, gait == "yes", action)
        hist = [(date.fromisoformat(n["date"]), n["area"], n["pain"]) for n in u.niggles(t - timedelta(days=14))]
        trend = adapt.niggle_trend(hist, pain_area, t)
        niggle = {"area": pain_area, "pain": pain, "action": action, "trend": trend}
    temp = _num(temp_c.replace(",", ".")) if temp_c.strip() else None
    if temp is not None and not -30 <= temp <= 50:
        temp = None
    u.save_readiness(t, sleep=sleep, soreness=soreness, mood=mood, ill=1 if ill == "yes" else 0, waking_hr=hr,
                     level=level, flags=json.dumps(flags), applied=applied, temp_c=temp,
                     humidity=humidity if humidity in ("dry", "normal", "humid") else "normal")
    if data is not None:
        replan(u, pid, data, t)
    return page(request, "check.html", t=t, r=u.get_readiness(t), d=d or None,
                result={"level": level, "flags": flags, "changes": changes, "baseline": baseline,
                        "heat": store.day_heat(u.get_readiness(t))[1], "niggle": niggle},
                **watch_morning(u, t))


# -------------------------------------------------------------------- Diary
@app.get("/diary", response_class=HTMLResponse)
def diary(request: Request):
    u = me(request)
    pid, data = u.active_plan()
    titles = {}
    if data:
        for w in data["weeks"]:
            for s in w["sessions"]:
                titles[s["id"]] = s["title"]
    return page(request, "diary.html", logs=u.all_logs(), readiness=u.all_readiness(),
                events=u.events(), titles=titles, extras=u.extras(), niggles=u.niggles())


# ------------------------------------------------- extra activities (not in the plan)
def _duration_min(text: str) -> float:
    """How long, in minutes: "45", "45.5", "1:10" / "1h10" (hours and minutes)."""
    t = text.strip().lower().replace(",", ".")
    m = re.fullmatch(r"(\d+)\s*(?::|h)\s*(\d{1,2})?\s*(?:m|min)?", t)
    if m:
        return int(m.group(1)) * 60 + int(m.group(2) or 0)
    return float(t.removesuffix("min").removesuffix("m").strip())



@app.get("/extra", response_class=HTMLResponse)
def extra_form(request: Request, d: str | None = None, id: int | None = None):
    u = me(request)
    x = u.extra(id) if id else None
    if id and x is None:
        raise HTTPException(404)
    day = date.fromisoformat(x["date"]) if x else min(today(d), clock())
    return page(request, "extra.html", x=x, day=day, t=clock(), error=None, v={}, attach=attach_choices(u, x))


def attach_choices(u: UserData, x) -> list:
    """A watch activity saved as an extra: the planned sessions of that day it could be instead."""
    if x is None or u.activity_by_extra(x["id"]) is None:
        return []
    pid, data = u.active_plan()
    if data is None:
        return []
    w, day = store.week_for(data, date.fromisoformat(x["date"]))
    if w is None:
        return []
    logs = u.logs(pid)
    kinds = icu.FITS.get(x["kind"], ()) or ("easy", "long", "quality", "tt", "xt")
    return [s for s in w["sessions"] if s["day"] == day and s["kind"] in kinds and s["id"] not in logs]


@app.post("/extra/{xid}/attach")
def extra_attach(request: Request, xid: int, session_id: str = Form(...)):
    """"This was my planned session": the watch activity logs that session instead of an extra."""
    u = me(request)
    row = u.activity_by_extra(xid)
    pid, data = u.active_plan()
    w, s, d = store.find_session(data or {"weeks": []}, session_id)
    if row is None or s is None:
        raise HTTPException(404)
    icu.attach(u, pid, data, row, w, s)
    _replan_now(u)
    return RedirectResponse(f"/log/{session_id}", status_code=303)


@app.post("/extra", response_class=HTMLResponse)
def extra_save(request: Request, day: str = Form(...), kind: str = Form(...), minutes: str = Form(...),
               km: str = Form(""), rpe: str = Form(""), notes: str = Form(""), id: str = Form("")):
    u = me(request)
    v = {"day": day, "kind": kind, "minutes": minutes, "km": km, "rpe": rpe, "notes": notes}
    x = u.extra(int(id)) if id else None
    try:
        d = date.fromisoformat(day)
        mins = _duration_min(minutes)
        dist = float(km.replace(",", ".")) if km.strip() and kind == "run" else None
        feel = float(rpe) if rpe else None
        if kind not in store.EXTRA_KINDS:
            raise ValueError("pick what you did")
        if d > clock():
            raise ValueError("that day hasn't happened yet")
        if not 0 < mins <= 600:
            raise ValueError("minutes: between 1 and 600")
        if dist is not None and not 0 <= dist <= 200:
            raise ValueError("km: between 0 and 200")
    except (ValueError, TypeError) as e:
        known = str(e) and not str(e).startswith(("could not", "invalid", "Invalid"))
        msg = str(e) if known else "check the numbers"
        return page(request, "extra.html", x=x, day=clock(), t=clock(), error=msg[0].upper() + msg[1:] + ".", v=v)
    u.save_extra(int(id) if id else None, d, kind, round(mins, 1), dist, feel, notes.strip())
    return RedirectResponse("/today" + ("" if d == clock() else f"?d={d.isoformat()}"), status_code=303)


@app.post("/extra/{xid}/delete")
def extra_delete(request: Request, xid: int):
    u = me(request)
    x = u.extra(xid)
    u.delete_extra(xid)
    d = x["date"] if x else None
    return RedirectResponse("/today" + (f"?d={d}" if d and d != clock().isoformat() else ""), status_code=303)


# ------------------------------------------------------- Setup / onboarding
def _preview(toml: str, start: str | None):
    t = clock()
    prof = profile_from_toml(toml, t)
    plan = build_plan(prof, t, date.fromisoformat(start) if start else None)
    new = store.plan_to_dict(plan)
    rows = [(w, store.week_stats(w), 0.0) for w in new["weeks"]]
    return new, rows


def _goal_preview(toml: str, new: dict):
    try:
        return progress.preview_check(toml, new, clock())
    except (ValueError, KeyError, ZeroDivisionError):
        return None


def _build(u: UserData, toml: str, new: dict):
    t = clock()
    u.save_profile(toml)
    pid = u.add_plan(new, toml)
    u.add_event(pid, t, "plan", f"New plan built: {len(new['weeks'])} weeks from {new['start']}, "
                                f"fitness (VDOT) {new['vdot']:.1f} from {new['fitness_basis']}")
    if icu.rematch(u, t):                     # runs the watch already sent that belong to the new plan
        _replan_now(u)
    return RedirectResponse("/plan", status_code=303)


def _start_field(form) -> str | None:
    """The onboarding's start choice: today / tomorrow / next Monday / a date."""
    when = form.get("start_when") or "monday"
    t = clock()
    if when == "today":
        return t.isoformat()
    if when == "tomorrow":
        return (t + timedelta(days=1)).isoformat()
    if when == "date":
        return (form.get("start") or "").strip() or None
    return None


@app.get("/setup", response_class=HTMLResponse)
def setup_form(request: Request):
    u = me(request)
    pid, data = u.active_plan()
    v = PF.toml_to_values(u.get_profile())
    v.setdefault("start_when", "monday")
    return page(request, "onboarding.html", v=v, error=None, preview=None, has_plan=data is not None, step=0,
                t=clock())


@app.post("/setup", response_class=HTMLResponse)
async def setup_save(request: Request):
    u = me(request)
    form = await request.form()
    pid, data = u.active_plan()
    v = {k: form.get(k) for k in form.keys()}
    try:
        prof = PF.form_to_profile(form)
        toml = PF.to_toml(prof)
        new, rows = _preview(toml, _start_field(form))
    except (ValueError, KeyError, TypeError) as e:
        msg = str(e)
        where = [(0, ("Birth", "Years")), (1, ("long-run", "3 days")), (2, ("weekly km", "Weeks off", "Easy pace")),
                 (3, ("Result", "result")), (5, ("Race date", "Target time"))]
        step = next((i for i, keys in where if any(k in msg for k in keys)), int(form.get("step") or 0))
        return page(request, "onboarding.html", v=v, error=msg, preview=None, has_plan=data is not None,
                    step=step, t=clock())
    if form.get("action") == "build":
        return _build(u, toml, new)
    return page(request, "onboarding.html", v=v, error=None, has_plan=data is not None, step=6, t=clock(),
                preview={"data": new, "weeks": rows, "top": max(st["km"] for _, st, _ in rows),
                         "goal": _goal_preview(toml, new)})


@app.get("/setup/toml", response_class=HTMLResponse)
def toml_form(request: Request):
    u = me(request)
    toml = u.get_profile() or EXAMPLE.read_text(encoding="utf-8")
    pid, data = u.active_plan()
    return page(request, "setup.html", toml=toml, preview=None, error=None, has_plan=data is not None)


@app.post("/setup/toml", response_class=HTMLResponse)
def toml_save(request: Request, toml: str = Form(...), action: str = Form("preview"), start: str = Form("")):
    u = me(request)
    toml = toml.replace("\r\n", "\n")
    pid, data = u.active_plan()
    try:
        new, rows = _preview(toml, start or None)
    except (tomllib.TOMLDecodeError, KeyError, ValueError, TypeError) as e:
        return page(request, "setup.html", toml=toml, preview=None, has_plan=data is not None,
                    error=f"{type(e).__name__}: {e}")
    if action == "build":
        return _build(u, toml, new)
    u.save_profile(toml)
    return page(request, "setup.html", toml=toml, error=None, has_plan=data is not None,
                preview={"data": new, "weeks": rows, "top": max(st["km"] for _, st, _ in rows),
                         "goal": _goal_preview(toml, new)})
