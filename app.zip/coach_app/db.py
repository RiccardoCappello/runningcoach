"""SQLite storage (stdlib sqlite3), one file for everyone using this server.

`DB` holds the accounts (users, invites, share links); `DB.for_user(uid)` gives a `UserData`
view whose methods only ever see that person's profile, plans, logs and checks.
"""
from __future__ import annotations

import json
import os
import secrets
import sqlite3
from datetime import date, datetime
from pathlib import Path

DEFAULT_DB = Path(__file__).resolve().parents[2] / "data" / "coach.db"
VERSION = 1

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name TEXT NOT NULL,
    pw TEXT NOT NULL,                  -- scrypt hash, hex
    salt TEXT NOT NULL,
    is_admin INTEGER NOT NULL DEFAULT 0,
    created TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS invite (
    code TEXT PRIMARY KEY,
    created_by INTEGER NOT NULL,
    note TEXT,
    used_by INTEGER,
    created TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS share (            -- read-only links to someone's plan
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    created TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS profile (
    user_id INTEGER PRIMARY KEY,
    toml TEXT NOT NULL,
    updated TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS plan (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL DEFAULT 1,
    created TEXT NOT NULL,
    status TEXT NOT NULL,              -- active | replaced
    profile_toml TEXT NOT NULL,        -- the profile the plan was built from
    data TEXT NOT NULL                 -- JSON snapshot (coach_engine.serialize); edited by adaptations
);
CREATE TABLE IF NOT EXISTS session_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_id INTEGER NOT NULL,          -- the plan belongs to one user
    session_id TEXT NOT NULL,
    date TEXT NOT NULL,
    completed TEXT NOT NULL,           -- yes | partial | no
    minutes REAL,
    rpe REAL,
    feel TEXT,                         -- on target | too fast | too slow
    reserve INTEGER,                   -- could have done one more rep
    avg_hr REAL,
    notes TEXT,
    score REAL,
    step INTEGER,                      -- A2: +1 / 0 / -1, quality sessions only
    flags TEXT,                        -- JSON list (A3 flat day, A4 easy creep)
    result_s REAL,                     -- time trial / race finish time
    created TEXT NOT NULL,
    UNIQUE (plan_id, session_id)
);
CREATE TABLE IF NOT EXISTS readiness (
    user_id INTEGER NOT NULL,
    date TEXT NOT NULL,
    sleep INTEGER,
    soreness INTEGER,
    mood INTEGER,
    ill INTEGER,
    waking_hr REAL,
    level TEXT,                        -- green | amber | red
    flags TEXT,                        -- JSON list
    applied TEXT,                      -- highest level already applied to the plan that day
    created TEXT NOT NULL,
    PRIMARY KEY (user_id, date)
);
CREATE TABLE IF NOT EXISTS time_off (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL DEFAULT 1,
    first TEXT NOT NULL,               -- first day without running
    last TEXT,                         -- last day without running (NULL = still off)
    cross_trained INTEGER NOT NULL DEFAULT 0,
    reason TEXT,
    created TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS extra (            -- training that wasn't in the plan
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    date TEXT NOT NULL,
    kind TEXT NOT NULL,                -- run | bike | swim | walk | gym | sport
    minutes REAL NOT NULL,
    km REAL,                           -- runs only count towards the weekly km
    rpe REAL,                          -- 1-10; the training load is minutes x rpe
    notes TEXT,
    created TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS race (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL DEFAULT 1,
    date TEXT NOT NULL,
    distance_m REAL NOT NULL,
    name TEXT,
    created TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS season_race (         -- the races a season is planned around (spec §11)
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    date TEXT NOT NULL,
    distance_m REAL NOT NULL,
    priority TEXT NOT NULL DEFAULT 'A', -- A goal race | B tune-up | C training run
    name TEXT,
    target_time_s REAL,
    created TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS icu (                  -- intervals.icu connection (Garmin data, spec §12)
    user_id INTEGER PRIMARY KEY,
    athlete_id TEXT NOT NULL,
    api_key TEXT NOT NULL,             -- stays in this database: on the phone it never leaves the phone
    synced_at TEXT,                    -- last successful sync
    error TEXT,                        -- last error, shown in Settings
    created TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS activity (             -- activities from the watch
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    ext_id TEXT NOT NULL,              -- intervals.icu activity id
    date TEXT NOT NULL,
    start TEXT,                        -- local start time
    kind TEXT NOT NULL,                -- run | bike | swim | walk | gym | sport
    name TEXT,
    minutes REAL,                      -- moving time
    km REAL,
    avg_hr REAL,
    max_hr REAL,
    speed REAL,                        -- m/s
    gap REAL,                          -- grade-adjusted m/s
    elev_m REAL,
    feels_like REAL,                   -- deg C
    decoupling REAL,                   -- %
    rpe REAL,
    laps TEXT,                         -- JSON: intervals (type, km, secs, speed, gap, hr)
    plan_id INTEGER,                   -- matched planned session (or NULL: logged as an extra)
    session_id TEXT,
    extra_id INTEGER,
    created TEXT NOT NULL,
    UNIQUE (user_id, ext_id)
);
CREATE TABLE IF NOT EXISTS wellness (             -- resting HR, HRV and sleep from the watch
    user_id INTEGER NOT NULL,
    date TEXT NOT NULL,
    resting_hr REAL,
    hrv REAL,
    sleep_secs REAL,
    sleep_score REAL,
    PRIMARY KEY (user_id, date)
);
CREATE TABLE IF NOT EXISTS niggle (            -- pain, by body area (S33)
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    date TEXT NOT NULL,
    area TEXT NOT NULL,
    pain INTEGER NOT NULL,             -- 0-10
    gait INTEGER NOT NULL DEFAULT 0,   -- it changes how I run
    action TEXT,                       -- S33 action applied that day: xt | easy | ok | none
    created TEXT NOT NULL,
    UNIQUE (user_id, date, area)
);
CREATE TABLE IF NOT EXISTS bump (                -- accepted A11 fitness bumps
    user_id INTEGER NOT NULL,
    date TEXT NOT NULL,
    plan_id INTEGER,
    PRIMARY KEY (user_id, date)
);
CREATE TABLE IF NOT EXISTS plan_event (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL DEFAULT 1,
    plan_id INTEGER,
    date TEXT NOT NULL,
    rule TEXT NOT NULL,
    text TEXT NOT NULL,
    created TEXT NOT NULL
);
"""


def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _cols(con, table) -> set:
    return {r[1] for r in con.execute(f"PRAGMA table_info({table})")}


def _migrate_v0(con):
    """Single-user database (before accounts) -> everything belongs to user 1, the first
    account created on this server."""
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "profile" in tables and "user_id" not in _cols(con, "profile"):
        con.execute("ALTER TABLE profile RENAME TO profile_v0")
        con.execute("CREATE TABLE profile (user_id INTEGER PRIMARY KEY, toml TEXT NOT NULL, updated TEXT NOT NULL)")
        con.execute("INSERT INTO profile SELECT 1, toml, updated FROM profile_v0")
        con.execute("DROP TABLE profile_v0")
    for t in ("plan", "time_off", "race", "plan_event"):
        if t in tables and "user_id" not in _cols(con, t):
            con.execute(f"ALTER TABLE {t} ADD COLUMN user_id INTEGER NOT NULL DEFAULT 1")
    if "session_log" in tables and "result_s" not in _cols(con, "session_log"):
        con.execute("ALTER TABLE session_log ADD COLUMN result_s REAL")
    for t in ("readiness", "bump"):                  # primary key changes: rebuild the table
        if t in tables and "user_id" not in _cols(con, t):
            cols = _cols_ordered(con, t)
            con.execute(f"ALTER TABLE {t} RENAME TO {t}_v0")
            con.execute(_create_stmt(t))
            con.execute(f"INSERT INTO {t} (user_id, {', '.join(cols)}) SELECT 1, {', '.join(cols)} FROM {t}_v0")
            con.execute(f"DROP TABLE {t}_v0")


def _cols_ordered(con, table) -> list:
    return [r[1] for r in con.execute(f"PRAGMA table_info({table})")]


def _create_stmt(table: str) -> str:
    start = SCHEMA.index(f"CREATE TABLE IF NOT EXISTS {table} (")
    return SCHEMA[start:SCHEMA.index(");", start) + 2]


class DB:
    def __init__(self, path: str | os.PathLike | None = None):
        self.path = Path(path or os.environ.get("COACH_DB") or DEFAULT_DB)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.con = sqlite3.connect(self.path, check_same_thread=False)
        self.con.row_factory = sqlite3.Row
        if self.con.execute("PRAGMA user_version").fetchone()[0] < VERSION:
            with self.con:
                _migrate_v0(self.con)
            self.con.execute(f"PRAGMA user_version = {VERSION}")
        self.con.executescript(SCHEMA)
        if "backup_at" not in _cols(self.con, "users"):        # phone app: last backup saved
            with self.con:
                self.con.execute("ALTER TABLE users ADD COLUMN backup_at TEXT")
        if "source" not in _cols(self.con, "session_log"):     # filled in from the watch (spec §12)
            with self.con:
                self.con.execute("ALTER TABLE session_log ADD COLUMN source TEXT")
                self.con.execute("ALTER TABLE session_log ADD COLUMN km REAL")
        if "temp_c" not in _cols(self.con, "readiness"):       # today's weather: heat-adjusted paces
            with self.con:
                self.con.execute("ALTER TABLE readiness ADD COLUMN temp_c REAL")
                self.con.execute("ALTER TABLE readiness ADD COLUMN humidity TEXT")
        if "season_id" not in _cols(self.con, "race"):         # a B race put in the plan by the season
            with self.con:
                self.con.execute("ALTER TABLE race ADD COLUMN season_id INTEGER")

    def for_user(self, uid: int) -> "UserData":
        return UserData(self.con, uid)

    # ---------------------------------------------------------------- accounts
    def n_users(self) -> int:
        return self.con.execute("SELECT COUNT(*) FROM users").fetchone()[0]

    def user(self, uid: int):
        return self.con.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()

    def user_by_name(self, username: str):
        return self.con.execute("SELECT * FROM users WHERE username = ?", (username.strip(),)).fetchone()

    def users(self) -> list:
        return self.con.execute("SELECT * FROM users ORDER BY id").fetchall()

    def add_user(self, username: str, name: str, pw: str, salt: str, is_admin: bool) -> int:
        with self.con:
            cur = self.con.execute("INSERT INTO users (username, name, pw, salt, is_admin, created) "
                                   "VALUES (?, ?, ?, ?, ?, ?)", (username.strip(), name.strip(), pw, salt,
                                                                 int(is_admin), now()))
        return cur.lastrowid

    def set_name(self, uid: int, name: str):
        with self.con:
            self.con.execute("UPDATE users SET name = ? WHERE id = ?", (name, uid))

    def set_backup(self, uid: int):
        with self.con:
            self.con.execute("UPDATE users SET backup_at = ? WHERE id = ?", (now(), uid))

    def set_password(self, uid: int, pw: str, salt: str):
        with self.con:
            self.con.execute("UPDATE users SET pw = ?, salt = ? WHERE id = ?", (pw, salt, uid))

    def new_invite(self, by: int, note: str = "") -> str:
        code = secrets.token_urlsafe(9)
        with self.con:
            self.con.execute("INSERT INTO invite (code, created_by, note, created) VALUES (?, ?, ?, ?)",
                             (code, by, note.strip(), now()))
        return code

    def invite(self, code: str):
        return self.con.execute("SELECT * FROM invite WHERE code = ? AND used_by IS NULL", (code,)).fetchone()

    def invites(self) -> list:
        return self.con.execute("SELECT i.*, u.name AS used_name FROM invite i LEFT JOIN users u ON u.id = i.used_by "
                                "ORDER BY i.created DESC").fetchall()

    def use_invite(self, code: str, uid: int):
        with self.con:
            self.con.execute("UPDATE invite SET used_by = ? WHERE code = ?", (uid, code))

    def delete_invite(self, code: str):
        with self.con:
            self.con.execute("DELETE FROM invite WHERE code = ? AND used_by IS NULL", (code,))

    # ------------------------------------------------------------ share links
    def share_owner(self, token: str) -> int | None:
        r = self.con.execute("SELECT user_id FROM share WHERE token = ?", (token,)).fetchone()
        return r["user_id"] if r else None


class UserData:
    """Everything below is one person's data."""

    def __init__(self, con: sqlite3.Connection, uid: int):
        self.con, self.uid = con, uid

    # ---------------------------------------------------------------- profile
    def get_profile(self) -> str | None:
        r = self.con.execute("SELECT toml FROM profile WHERE user_id = ?", (self.uid,)).fetchone()
        return r["toml"] if r else None

    def save_profile(self, toml: str):
        with self.con:
            self.con.execute("INSERT INTO profile (user_id, toml, updated) VALUES (?, ?, ?) "
                             "ON CONFLICT(user_id) DO UPDATE SET toml = excluded.toml, updated = excluded.updated",
                             (self.uid, toml, now()))

    # ------------------------------------------------------------------ plans
    def active_plan(self):
        """(plan_id, data dict) of the active plan, or (None, None)."""
        r = self.con.execute("SELECT id, data FROM plan WHERE status = 'active' AND user_id = ? "
                             "ORDER BY id DESC LIMIT 1", (self.uid,)).fetchone()
        return (r["id"], json.loads(r["data"])) if r else (None, None)

    def add_plan(self, data: dict, profile_toml: str) -> int:
        with self.con:
            self.con.execute("UPDATE plan SET status = 'replaced' WHERE status = 'active' AND user_id = ?",
                             (self.uid,))
            cur = self.con.execute("INSERT INTO plan (user_id, created, status, profile_toml, data) "
                                   "VALUES (?, ?, 'active', ?, ?)",
                                   (self.uid, now(), profile_toml, json.dumps(data)))
        return cur.lastrowid

    def plan_profile(self, plan_id: int) -> str:
        return self.con.execute("SELECT profile_toml FROM plan WHERE id = ? AND user_id = ?",
                                (plan_id, self.uid)).fetchone()["profile_toml"]

    def save_plan_data(self, plan_id: int, data: dict):
        with self.con:
            self.con.execute("UPDATE plan SET data = ? WHERE id = ? AND user_id = ?",
                             (json.dumps(data), plan_id, self.uid))

    # ------------------------------------------------------------------- logs
    def get_log(self, plan_id: int, session_id: str):
        return self.con.execute("SELECT l.* FROM session_log l JOIN plan p ON p.id = l.plan_id "
                                "WHERE l.plan_id = ? AND l.session_id = ? AND p.user_id = ?",
                                (plan_id, session_id, self.uid)).fetchone()

    def logs(self, plan_id: int) -> dict:
        rows = self.con.execute("SELECT l.* FROM session_log l JOIN plan p ON p.id = l.plan_id "
                                "WHERE l.plan_id = ? AND p.user_id = ?", (plan_id, self.uid)).fetchall()
        return {r["session_id"]: r for r in rows}

    def all_logs(self) -> list:
        return self.con.execute("SELECT l.* FROM session_log l JOIN plan p ON p.id = l.plan_id "
                                "WHERE p.user_id = ? ORDER BY l.date DESC, l.id DESC", (self.uid,)).fetchall()

    def save_log(self, plan_id: int, session_id: str, d: date, **f):
        owner = self.con.execute("SELECT user_id FROM plan WHERE id = ?", (plan_id,)).fetchone()
        if owner is None or owner["user_id"] != self.uid:
            raise PermissionError("not your plan")
        cols = ["completed", "minutes", "rpe", "feel", "reserve", "avg_hr", "notes", "score", "step", "flags",
                "result_s", "source", "km"]
        with self.con:
            self.con.execute(
                f"INSERT INTO session_log (plan_id, session_id, date, {', '.join(cols)}, created) "
                f"VALUES (?, ?, ?, {', '.join('?' * len(cols))}, ?) "
                f"ON CONFLICT(plan_id, session_id) DO UPDATE SET "
                + ", ".join(f"{c} = excluded.{c}" for c in cols + ["date", "created"]),
                (plan_id, session_id, d.isoformat(), *[f.get(c) for c in cols], now()))

    # -------------------------------------------------------------- readiness
    def get_readiness(self, d: date):
        return self.con.execute("SELECT * FROM readiness WHERE user_id = ? AND date = ?",
                                (self.uid, d.isoformat())).fetchone()

    def readiness_before(self, d: date, days: int) -> list:
        return self.con.execute("SELECT * FROM readiness WHERE user_id = ? AND date < ? ORDER BY date DESC LIMIT ?",
                                (self.uid, d.isoformat(), days)).fetchall()

    def readiness_since(self, d: date) -> list:
        return self.con.execute("SELECT * FROM readiness WHERE user_id = ? AND date >= ?",
                                (self.uid, d.isoformat())).fetchall()

    def all_readiness(self) -> list:
        return self.con.execute("SELECT * FROM readiness WHERE user_id = ? ORDER BY date DESC", (self.uid,)).fetchall()

    def save_readiness(self, d: date, **f):
        cols = ["sleep", "soreness", "mood", "ill", "waking_hr", "level", "flags", "applied", "temp_c", "humidity"]
        with self.con:
            self.con.execute(
                f"INSERT INTO readiness (user_id, date, {', '.join(cols)}, created) "
                f"VALUES (?, ?, {', '.join('?' * len(cols))}, ?) "
                f"ON CONFLICT(user_id, date) DO UPDATE SET "
                + ", ".join(f"{c} = excluded.{c}" for c in cols + ["created"]),
                (self.uid, d.isoformat(), *[f.get(c) for c in cols], now()))

    # ------------------------------------------------------ time off / races
    def time_off(self) -> list:
        return self.con.execute("SELECT * FROM time_off WHERE user_id = ? ORDER BY first DESC", (self.uid,)).fetchall()

    def add_time_off(self, first: date, last: date | None, cross_trained: bool, reason: str):
        with self.con:
            self.con.execute("INSERT INTO time_off (user_id, first, last, cross_trained, reason, created) "
                             "VALUES (?, ?, ?, ?, ?, ?)", (self.uid, first.isoformat(),
                                                           last.isoformat() if last else None,
                                                           int(cross_trained), reason, now()))

    def end_time_off(self, id_: int, last: date):
        with self.con:
            self.con.execute("UPDATE time_off SET last = ? WHERE id = ? AND user_id = ?",
                             (last.isoformat(), id_, self.uid))

    def delete_time_off(self, id_: int):
        with self.con:
            self.con.execute("DELETE FROM time_off WHERE id = ? AND user_id = ?", (id_, self.uid))

    def races(self) -> list:
        return self.con.execute("SELECT * FROM race WHERE user_id = ? ORDER BY date", (self.uid,)).fetchall()

    def add_race(self, d: date, distance_m: float, name: str, season_id: int | None = None):
        with self.con:
            self.con.execute("INSERT INTO race (user_id, date, distance_m, name, season_id, created) "
                             "VALUES (?, ?, ?, ?, ?, ?)", (self.uid, d.isoformat(), distance_m, name, season_id, now()))

    def delete_race(self, id_: int):
        with self.con:
            self.con.execute("DELETE FROM race WHERE id = ? AND user_id = ?", (id_, self.uid))

    # ----------------------------------------------------------- niggles (S33)
    def save_niggle(self, d: date, area: str, pain: int, gait: bool, action: str):
        with self.con:
            self.con.execute("INSERT INTO niggle (user_id, date, area, pain, gait, action, created) "
                             "VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(user_id, date, area) DO UPDATE SET "
                             "pain = excluded.pain, gait = excluded.gait, action = excluded.action",
                             (self.uid, d.isoformat(), area, pain, int(gait), action, now()))

    def niggles(self, since: date | None = None) -> list:
        q, args = "SELECT * FROM niggle WHERE user_id = ?", [self.uid]
        if since:
            q, args = q + " AND date >= ?", args + [since.isoformat()]
        return self.con.execute(q + " ORDER BY date DESC, id DESC", args).fetchall()

    def niggles_on(self, d: date) -> list:
        return self.con.execute("SELECT * FROM niggle WHERE user_id = ? AND date = ?",
                                (self.uid, d.isoformat())).fetchall()

    # --------------------------------------------------- watch (intervals.icu)
    def icu(self):
        return self.con.execute("SELECT * FROM icu WHERE user_id = ?", (self.uid,)).fetchone()

    def set_icu(self, athlete_id: str, api_key: str):
        with self.con:
            self.con.execute("INSERT INTO icu (user_id, athlete_id, api_key, created) VALUES (?, ?, ?, ?) "
                             "ON CONFLICT(user_id) DO UPDATE SET athlete_id = excluded.athlete_id, "
                             "api_key = excluded.api_key, error = NULL", (self.uid, athlete_id, api_key, now()))

    def icu_status(self, synced: bool, error: str | None):
        with self.con:
            if synced:
                self.con.execute("UPDATE icu SET synced_at = ?, error = NULL WHERE user_id = ?", (now(), self.uid))
            else:
                self.con.execute("UPDATE icu SET error = ? WHERE user_id = ?", (error, self.uid))

    def delete_icu(self):
        with self.con:
            self.con.execute("DELETE FROM icu WHERE user_id = ?", (self.uid,))

    def activity_by_ext(self, ext_id: str):
        return self.con.execute("SELECT * FROM activity WHERE user_id = ? AND ext_id = ?",
                                (self.uid, ext_id)).fetchone()

    def activity_for_session(self, plan_id: int, session_id: str):
        return self.con.execute("SELECT * FROM activity WHERE user_id = ? AND plan_id = ? AND session_id = ?",
                                (self.uid, plan_id, session_id)).fetchone()

    def activities(self, since: date | None = None, kind: str | None = None) -> list:
        q, args = "SELECT * FROM activity WHERE user_id = ?", [self.uid]
        if since:
            q, args = q + " AND date >= ?", args + [since.isoformat()]
        if kind:
            q, args = q + " AND kind = ?", args + [kind]
        return self.con.execute(q + " ORDER BY date, start", args).fetchall()

    def save_activity(self, **f) -> int:
        cols = ["ext_id", "date", "start", "kind", "name", "minutes", "km", "avg_hr", "max_hr", "speed", "gap",
                "elev_m", "feels_like", "decoupling", "rpe", "laps", "plan_id", "session_id", "extra_id"]
        with self.con:
            self.con.execute(
                f"INSERT INTO activity (user_id, {', '.join(cols)}, created) VALUES (?, {', '.join('?' * len(cols))}, ?) "
                f"ON CONFLICT(user_id, ext_id) DO UPDATE SET " + ", ".join(f"{c} = excluded.{c}" for c in cols[1:]),
                (self.uid, *[f.get(c) for c in cols], now()))
        return self.activity_by_ext(f["ext_id"])["id"]

    def save_wellness(self, d: str, resting_hr, hrv, sleep_secs, sleep_score):
        with self.con:
            self.con.execute("INSERT INTO wellness (user_id, date, resting_hr, hrv, sleep_secs, sleep_score) "
                             "VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(user_id, date) DO UPDATE SET "
                             "resting_hr = excluded.resting_hr, hrv = excluded.hrv, sleep_secs = excluded.sleep_secs, "
                             "sleep_score = excluded.sleep_score", (self.uid, d, resting_hr, hrv, sleep_secs, sleep_score))

    def wellness(self, since: date) -> list:
        return self.con.execute("SELECT * FROM wellness WHERE user_id = ? AND date >= ? ORDER BY date",
                                (self.uid, since.isoformat())).fetchall()

    def wellness_on(self, d: date):
        return self.con.execute("SELECT * FROM wellness WHERE user_id = ? AND date = ?",
                                (self.uid, d.isoformat())).fetchone()

    # ---------------------------------------------------------------- season
    def season_races(self) -> list:
        return self.con.execute("SELECT * FROM season_race WHERE user_id = ? ORDER BY date", (self.uid,)).fetchall()

    def season_race(self, id_: int):
        return self.con.execute("SELECT * FROM season_race WHERE id = ? AND user_id = ?", (id_, self.uid)).fetchone()

    def add_season_race(self, d: date, distance_m: float, priority: str, name: str,
                        target_time_s: float | None) -> int:
        with self.con:
            cur = self.con.execute("INSERT INTO season_race (user_id, date, distance_m, priority, name, target_time_s, "
                                   "created) VALUES (?, ?, ?, ?, ?, ?, ?)",
                                   (self.uid, d.isoformat(), distance_m, priority, name, target_time_s, now()))
        return cur.lastrowid

    def delete_season_race(self, id_: int):
        with self.con:
            self.con.execute("DELETE FROM season_race WHERE id = ? AND user_id = ?", (id_, self.uid))
            self.con.execute("DELETE FROM race WHERE season_id = ? AND user_id = ?", (id_, self.uid))

    def plans(self) -> list:
        """Every plan of this person, newest first: (id, status, data dict)."""
        rows = self.con.execute("SELECT id, status, data FROM plan WHERE user_id = ? ORDER BY id DESC",
                                (self.uid,)).fetchall()
        return [(r["id"], r["status"], json.loads(r["data"])) for r in rows]

    # ----------------------------------------------------- extra activities
    def extras(self, first: date | None = None, last: date | None = None) -> list:
        q, args = "SELECT * FROM extra WHERE user_id = ?", [self.uid]
        if first:
            q, args = q + " AND date >= ?", args + [first.isoformat()]
        if last:
            q, args = q + " AND date <= ?", args + [last.isoformat()]
        return self.con.execute(q + " ORDER BY date DESC, id DESC", args).fetchall()

    def extra(self, id_: int):
        return self.con.execute("SELECT * FROM extra WHERE id = ? AND user_id = ?", (id_, self.uid)).fetchone()

    def save_extra(self, id_: int | None, d: date, kind: str, minutes: float, km: float | None,
                   rpe: float | None, notes: str) -> int:
        with self.con:
            if id_:
                self.con.execute("UPDATE extra SET date = ?, kind = ?, minutes = ?, km = ?, rpe = ?, notes = ? "
                                 "WHERE id = ? AND user_id = ?",
                                 (d.isoformat(), kind, minutes, km, rpe, notes, id_, self.uid))
            else:
                id_ = self.con.execute("INSERT INTO extra (user_id, date, kind, minutes, km, rpe, notes, created) "
                                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                                       (self.uid, d.isoformat(), kind, minutes, km, rpe, notes, now())).lastrowid
        return id_

    def delete_extra(self, id_: int):
        with self.con:
            self.con.execute("DELETE FROM extra WHERE id = ? AND user_id = ?", (id_, self.uid))

    def bumps(self, plan_id: int) -> list:
        return [date.fromisoformat(r["date"]) for r in
                self.con.execute("SELECT date FROM bump WHERE user_id = ? AND plan_id = ?", (self.uid, plan_id))]

    def add_bump(self, plan_id: int, d: date):
        with self.con:
            self.con.execute("INSERT OR IGNORE INTO bump (user_id, date, plan_id) VALUES (?, ?, ?)",
                             (self.uid, d.isoformat(), plan_id))

    # ----------------------------------------------------------------- events
    def add_event(self, plan_id: int | None, d: date, rule: str, text: str):
        with self.con:
            self.con.execute("INSERT INTO plan_event (user_id, plan_id, date, rule, text, created) "
                             "VALUES (?, ?, ?, ?, ?, ?)", (self.uid, plan_id, d.isoformat(), rule, text, now()))

    def events(self) -> list:
        return self.con.execute("SELECT * FROM plan_event WHERE user_id = ? ORDER BY id DESC", (self.uid,)).fetchall()

    # ------------------------------------------------------------ share links
    def shares(self) -> list:
        return self.con.execute("SELECT * FROM share WHERE user_id = ? ORDER BY created DESC", (self.uid,)).fetchall()

    def new_share(self) -> str:
        token = secrets.token_urlsafe(16)
        with self.con:
            self.con.execute("INSERT INTO share (token, user_id, created) VALUES (?, ?, ?)", (token, self.uid, now()))
        return token

    def delete_share(self, token: str):
        with self.con:
            self.con.execute("DELETE FROM share WHERE token = ? AND user_id = ?", (token, self.uid))
