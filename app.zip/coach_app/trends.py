"""Trends from the watch (spec §12): aerobic efficiency, drift on long runs, benchmark sessions.

Read-only, like progress.py. Works across every plan (a season is several plans)."""
from __future__ import annotations

import json
import statistics
from datetime import date, timedelta

from coach_engine import analysis as A
from coach_engine.profile_io import profile_from_toml

from . import icu, store

FAMILY_NAME = {"threshold": "Threshold", "intervals": "Intervals", "reps": "Repetitions", "race_pace": "Race pace",
               "over_under": "Over-unders"}


def _sessions(u) -> dict:
    """(plan id, session id) -> (plan data, week, session) for every plan."""
    out = {}
    for pid, _, data in u.plans():
        for w in data["weeks"]:
            for s in w["sessions"]:
                out[(pid, s["id"])] = (data, w, s)
    return out


def hr_rest(u, pid: int, data: dict, t: date) -> float:
    """Resting HR: the watch's (median of 2 weeks), else the profile's, else 55."""
    vals = [w["resting_hr"] for w in u.wellness(t - timedelta(days=14)) if w["resting_hr"]]
    if vals:
        return statistics.median(vals)
    prof = profile_from_toml(u.plan_profile(pid), date.fromisoformat(data["created"]))
    return prof.physiology.hr_rest or 55.0


def watch_trends(u, pid: int, data: dict, t: date) -> dict | None:
    acts = u.activities(t - timedelta(weeks=26))
    if not acts and u.icu() is None:
        return None
    where = _sessions(u)
    cur, _ = store.week_for(data, t)
    z = store.zones_of(data, cur)
    ref = A.reference_hr(z)
    rest = hr_rest(u, pid, data, t)

    runs, drift = [], []
    for a in acts:
        hit = where.get((a["plan_id"], a["session_id"])) if a["session_id"] else None
        sess = hit[2] if hit else None
        runs.append(_run(a, sess, z))
        if a["kind"] == "run" and a["decoupling"] is not None and (a["minutes"] or 0) >= 60 and \
                (sess is None or sess["kind"] == "long"):
            drift.append({"date": date.fromisoformat(a["date"]), "value": a["decoupling"], "km": a["km"]})
    eff = A.efficiency(runs, ref, rest, t)

    # the efficiency chart: pace at the reference HR (faster = higher), trend line, hot runs hollow
    chart = None
    if len(eff.points) >= 2:
        W, H, pad = 320.0, 110.0, 10.0
        d0 = eff.points[0].date
        span = max((eff.points[-1].date - d0).days, 7)
        ps = [e.pace for e in eff.points]
        lo, hi = min(ps) - 5, max(ps) + 5
        X = lambda d: round(pad + (W - 2 * pad) * (d - d0).days / span, 1)
        Y = lambda p: round(pad + (H - 2 * pad) * (p - lo) / (hi - lo), 1)      # faster pace = higher
        chart = {"W": W, "H": H, "pts": [{"x": X(e.date), "y": Y(e.pace), "hot": e.hot, "odd": e.odd,
                                          "title": f"{e.date:%d %b}: {A.fmt(e.pace)}/km at {ref:.0f} bpm"
                                          + (" (warm day)" if e.hot else "")} for e in eff.points],
                 "top": A.fmt(lo), "bottom": A.fmt(hi)}
        if eff.slope_s_per_week is not None:
            fit = [e for e in eff.points if not e.hot and not e.odd]
            chart["line"] = (X(fit[0].date), Y(eff.start_pace), X(fit[-1].date), Y(eff.end_pace))

    return {"eff": eff, "ref": ref, "rest": rest, "chart": chart, "drift": drift[-6:],
            "bench": benchmarks(u, where), "connected": u.icu() is not None,
            "drift_note": A.decoupling_note(drift[-1]["value"]) if drift else ""}


def _run(a, sess, z) -> dict:
    return {"date": date.fromisoformat(a["date"]), "minutes": a["minutes"], "speed": a["speed"],
            "gap": a["gap"], "avg_hr": a["avg_hr"], "feels_like": a["feels_like"],
            "steady": icu.steady(a, sess, z)}


def fitness_set_on(u, pid: int, data: dict) -> date:
    """When the plan's fitness was last measured or raised: its creation, a time trial or race, an
    accepted +1. Watch evidence only counts after that (spec §19)."""
    days = [date.fromisoformat(data["created"])] + list(u.bumps(pid))
    for sid, lg in u.logs(pid).items():
        if lg["result_s"]:
            days.append(date.fromisoformat(lg["date"]))
    return max(days)


def fitness_signals(u, pid: int, data: dict, t: date):
    """The watch's evidence for a fitness rise since it was last set (replan.Signals, spec §19)."""
    from coach_engine.replan import Signals, target_rpe
    sg = Signals()
    if data.get("provisional") or u.icu() is None:
        return sg
    since = max(fitness_set_on(u, pid, data), t - timedelta(days=42))
    logs = u.logs(pid)
    checked = []
    for w in data["weeks"]:
        for s in w["sessions"]:
            d = date.fromisoformat(w["start"]) + timedelta(days=s["day"])
            if s["kind"] != "quality" or not since < d <= t or s["id"] not in logs:
                continue
            a = u.activity_for_session(pid, s["id"])
            if a is None:
                continue
            reps, _ = icu.reps_for(data, w, s, json.loads(a["laps"] or "[]"))
            if reps:
                checked.append((d, A.rep_feel(reps), logs[s["id"]]["rpe"], target_rpe(s)[1]))
    checked = sorted(checked)[-4:]
    sg.checked_sessions = len(checked)
    sg.fast_sessions = sum(f == "too fast" for _, f, _, _ in checked)
    sg.hard_effort = any(f == "too slow" or (r is not None and r > top) for _, f, r, top in checked)
    # easy pace at the reference HR, only runs since fitness was last set
    z = store.zones_of(data, store.week_for(data, t)[0])
    ref, rest = A.reference_hr(z), hr_rest(u, pid, data, t)
    where = _sessions(u)
    runs = []
    for a in u.activities(since):
        hit = where.get((a["plan_id"], a["session_id"])) if a["session_id"] else None
        runs.append(_run(a, hit[2] if hit else None, z))
    eff = A.efficiency(runs, ref, rest, t)
    if eff.slope_s_per_week is not None and eff.end_pace < eff.start_pace:
        sg.eff_gain = A.vdot_gain_from_efficiency(data["vdot"], eff.start_pace, eff.end_pace)
        sg.eff_weeks = eff.weeks
        sg.eff_text = f"{A.fmt(eff.start_pace)} → {A.fmt(eff.end_pace)}/km at {ref:.0f} bpm in {eff.weeks:.0f} weeks"
    return sg


def benchmarks(u, where: dict) -> dict:
    """Repeated sessions (same structure) and each family of key sessions, with their trend."""
    by_key, by_fam = {}, {}
    for pid, _, data in u.plans():
        logs = u.logs(pid)
        for w in data["weeks"]:
            for s in w["sessions"]:
                lg = logs.get(s["id"])
                key = A.benchmark_key(s)
                if key is None or lg is None or lg["completed"] == "no":
                    continue
                d = date.fromisoformat(w["start"]) + timedelta(days=s["day"])
                a = u.activity_for_session(pid, s["id"])
                pace_s = hr = None
                on = n = 0
                if a is not None and s["kind"] == "quality":
                    reps, band = icu.reps_for(data, w, s, json.loads(a["laps"] or "[]"))
                    if reps:
                        pace_s = statistics.mean(r["pace"] for r in reps)
                        hrs = [r["hr"] for r in reps if r["hr"]]
                        hr = statistics.mean(hrs) if hrs else None
                        on, n = sum(r["verdict"] == "on" for r in reps), len(reps)
                elif s["kind"] == "tt" and lg["result_s"]:
                    km = sum(g["km"] for g in s["segments"] if g["zone"] == "TT")
                    pace_s, hr = lg["result_s"] / km, lg["avg_hr"]
                run = A.BenchRun(d, pace_s, hr, lg["rpe"], on, n)
                by_key.setdefault(key, []).append(run)
                if s["kind"] == "quality":
                    by_fam.setdefault(s["family"], []).append(run)
    rows = []
    for key, runs in by_key.items():
        runs.sort(key=lambda r: r.date)
        if len(runs) >= 2:
            rows.append({"key": key, "runs": runs, "trend": A.benchmark_trend(runs), "spark": _spark(runs)})
    rows.sort(key=lambda r: r["runs"][-1].date, reverse=True)
    fams = []
    for fam, runs in by_fam.items():
        runs.sort(key=lambda r: r.date)
        paced = [r for r in runs if r.pace]
        if len(paced) >= 2:
            fams.append({"name": FAMILY_NAME.get(fam, fam), "n": len(runs), "first": paced[0], "last": paced[-1],
                         "spark": _spark(paced)})
    return {"repeats": rows, "families": fams}


def _spark(runs: list) -> str:
    """Polyline points (viewBox 100 x 24) of rep pace over time, faster = higher."""
    ps = [(r.date, r.pace) for r in runs if r.pace]
    if len(ps) < 2:
        return ""
    lo, hi = min(p for _, p in ps), max(p for _, p in ps)
    span = max((ps[-1][0] - ps[0][0]).days, 1)
    rng = max(hi - lo, 1.0)
    return " ".join(f"{100 * (d - ps[0][0]).days / span:.1f},{2 + 20 * (p - lo) / rng:.1f}" for d, p in ps)
