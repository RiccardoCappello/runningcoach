"""The Season page (spec §11): the races of the season, the blocks the engine chains between them,
and starting the next block as the active plan.

The season is computed on every visit from the profile and the races; nothing of it is stored
except the races. Block 1 is the active plan when the active plan is the plan for that race."""
from __future__ import annotations

import tomllib
from datetime import date, timedelta

from coach_engine.builder import build_plan
from coach_engine.fitness import HALF, MARATHON, fmt_time, parse_distance
from coach_engine.profile_io import profile_from_toml
from coach_engine.season import SeasonRace, plan_season

from . import profile_form as PF
from . import store

DIST_KEYS = {5000.0: "5k", 10000.0: "10k", HALF: "half", MARATHON: "marathon"}
PRIORITY_TEXT = {"A": "Goal race", "B": "Tune-up", "C": "Training run"}


def dist_key(m: float):
    return next((k for d, k in DIST_KEYS.items() if abs(d - m) < 1), m)


def season_races(u) -> list:
    return [SeasonRace(date.fromisoformat(r["date"]), r["distance_m"], r["priority"], r["name"] or "",
                       r["target_time_s"], r["id"]) for r in u.season_races()]


def results(u) -> list:
    """Every time trial / race result logged in any plan: [{date, distance_m, time_s, kind}]."""
    out = []
    for pid, _, data in u.plans():
        logs = u.logs(pid)
        for w in data["weeks"]:
            for s in w["sessions"]:
                log = logs.get(s["id"])
                if s["kind"] != "tt" or log is None or not log["result_s"]:
                    continue
                km = sum(g["km"] for g in s["segments"] if g["zone"] == "TT")
                out.append({"date": log["date"], "distance_m": round(km * 1000, 1), "time_s": log["result_s"],
                            "kind": "race" if s["family"] == "race" or "RACE" in s["title"] else "time_trial"})
    return out


def profile_dict(u, t: date) -> dict:
    """The stored profile, brought up to date for a new block: results logged since are added,
    and after a finished plan the volume it reached carries over (spec §11)."""
    d = tomllib.loads(u.get_profile())
    perfs = d.setdefault("performance", [])
    have = set()
    for p in perfs:
        try:
            have.add((str(p["date"])[:10], round(parse_distance(p["distance"]))))
        except (KeyError, ValueError):
            pass                                     # the 12-minute test: not a distance
    for r in results(u):
        if (r["date"], round(r["distance_m"])) not in have:
            perfs.append({"distance": dist_key(r["distance_m"]), "time": fmt_time(r["time_s"]),
                          "date": r["date"], "kind": r["kind"]})
    pid, data = u.active_plan()
    if data is not None and store.plan_end(data) < t:
        prof = profile_from_toml(u.plan_profile(pid), date.fromisoformat(data["created"]))
        peak = store.plan_peak(data, prof)
        rec = d.setdefault("recent", {})
        rec.update(status="regular", weekly_km=round(0.85 * peak, 1),
                   max_sustained_km=max(peak, rec.get("max_sustained_km") or 0),
                   consistent_weeks=max(rec.get("consistent_weeks", 0), len(data["weeks"])))
        for k in ("weeks_off", "cross_trained", "easy_pace", "continuous_min"):
            rec.pop(k, None)
        longs = [store.session_km(s) for w in data["weeks"] for s in w["sessions"] if s["kind"] == "long"]
        if longs:
            rec["long_run_km"] = round(0.85 * max(longs), 1)
    return d


def _active_match(data: dict, races: list, t: date):
    """The A race the active plan is for (same date and distance), if it hasn't finished."""
    if data is None or data["goal"]["type"] != "race" or store.plan_end(data) < t:
        return None
    g = data["goal"]
    return next((r for r in races if r.priority == "A" and r.date.isoformat() == g["race_date"]
                 and abs(r.distance_m - g["distance_m"]) < 1), None)


def compute(u, t: date) -> dict:
    races = season_races(u)
    if u.get_profile() is None:
        return {"season": None, "races": races, "active": None}
    pid, data = u.active_plan()
    match = _active_match(data, races, t)
    if match:
        created = date.fromisoformat(data["created"])
        prof = profile_from_toml(u.plan_profile(pid), created)
        season = plan_season(prof, [r for r in races if r.date > t or r is match], created,
                             start=date.fromisoformat(data["start"]))
        first = season.blocks[0]
        # block 1 is the plan as it is now (re-planned from the logs), not as it was built
        first.vdot_end, first.predicted_s = data.get("goal_vdot"), data.get("target_time_s")
        first.weekly = [(date.fromisoformat(w["start"]), w["target_km"],
                         "taper" if w["kind"] == "taper" else w["block"]) for w in data["weeks"]]
        return {"season": season, "races": races, "active": 0}
    prof = profile_from_toml(PF.to_toml(profile_dict(u, t)), t)
    if prof.recent.status == "beginner":
        return {"season": None, "races": races, "active": None, "beginner": True}
    return {"season": plan_season(prof, races, t), "races": races, "active": None}


def goal_table(block) -> dict:
    """The [goal] of the profile for this block."""
    if block.kind == "race":
        r = block.race
        g = {"type": "race", "distance": dist_key(r.distance_m), "race_date": r.date.isoformat()}
        if r.target_time_s:
            g["target_time"] = fmt_time(r.target_time_s)
        return g
    return {"type": "general", "distance": dist_key(block.distance_m),
            "weeks": sum(n for ph, n in block.phases if ph != "lead-in")}


def start_block(u, t: date, index: int):
    """Make block `index` (the first one that can start) the active plan. Returns the plan id."""
    view = compute(u, t)
    season = view["season"]
    block = season.blocks[index]
    d = profile_dict(u, t)
    intensity = d.get("goal", {}).get("intensity")
    d["goal"] = goal_table(block)
    if intensity:
        d["goal"]["intensity"] = intensity
    toml = PF.to_toml(d)
    plan = build_plan(profile_from_toml(toml, t), t, max(block.start, t))
    new = store.plan_to_dict(plan)
    u.save_profile(toml)
    pid = u.add_plan(new, toml)
    u.add_event(pid, t, "§11", f"Season: started the {block.title} block, {len(new['weeks'])} weeks from "
                               f"{new['start']}, fitness (VDOT) {new['vdot']:.1f}")
    end = store.plan_end(new)
    have = {(r["date"], round(r["distance_m"])) for r in u.races()}
    for r in block.races:
        if r.priority == "B" and t < r.date <= end and (r.date.isoformat(), round(r.distance_m)) not in have:
            u.add_race(r.date, r.distance_m, r.name, season_id=r.id)
    return pid


def sync_b_race(u, row_id: int, t: date) -> bool:
    """A B race added to the season inside the active plan's dates goes into the plan (A14/A15)."""
    r = u.season_race(row_id)
    pid, data = u.active_plan()
    if r is None or data is None or r["priority"] != "B":
        return False
    d = date.fromisoformat(r["date"])
    if not (t < d <= store.plan_end(data) and d >= date.fromisoformat(data["start"])):
        return False
    u.add_race(d, r["distance_m"], r["name"] or "", season_id=row_id)
    return True


# ----------------------------------------------------------------- display
PHASE_LABEL = {"base": "Base", "build": "Build", "sharpen": "Sharpen", "taper": "Taper", "lead-in": "Lead-in",
               "recovery": "Recovery"}


def timeline(season, t: date, width: float = 320.0) -> dict:
    """Everything the timeline SVG needs, in pixels: phase segments, weekly bars, races, months."""
    if not season or not season.blocks:
        return {}
    t0 = season.blocks[0].start
    t1 = max(season.end, *(r.date for r in season.races if r.date >= t0)) if season.races else season.end
    span = max((t1 - t0).days + 1, 7)
    X = lambda d: round(width * (d - t0).days / span, 2)
    segs, bars = [], []
    top = max([km for b in season.blocks for _, km, _ in b.weekly] + [1])
    for b in season.blocks:
        if b.kind == "recovery":
            segs.append({"x": X(b.start), "w": max(1.0, X(b.end + timedelta(days=1)) - X(b.start)),
                         "ph": "recovery", "title": f"Recovery {b.start:%d %b} - {b.end:%d %b}"})
            continue
        for start, km, ph in b.weekly:
            end = min(start + timedelta(days=7), b.end + timedelta(days=1))
            s0 = max(start, b.start)
            if segs and segs[-1]["ph"] == ph and abs(segs[-1]["x"] + segs[-1]["w"] - X(s0)) < 0.5:
                segs[-1]["w"] = X(end) - segs[-1]["x"]
            else:
                segs.append({"x": X(s0), "w": X(end) - X(s0), "ph": ph, "title": PHASE_LABEL.get(ph, ph)})
            bars.append({"x": X(s0), "w": max(0.8, X(end) - X(s0) - 0.8), "h": km / top, "ph": ph,
                         "title": f"Week of {start:%d %b}: {km:.0f} km"})
    races = [{"x": X(r.date), "p": r.priority, "title": f"{r.label} · {r.date:%d %b} · {PRIORITY_TEXT[r.priority]}",
              "short": r.label[:14]} for r in season.races if t0 <= r.date <= t1]
    # month ticks; a long season labels every 2nd month, January carries the year
    months, m = [], date(t0.year, t0.month, 1)
    n_months = (t1.year - t0.year) * 12 + t1.month - t0.month + 1
    every = 1 if n_months <= 8 else 2 if n_months <= 18 else 3
    while m <= t1:
        if m >= t0:
            x = X(m)
            show = (m.month - 1) % every == 0 and x < width - 14
            months.append({"x": x, "label": (str(m.year) if m.month == 1 else m.strftime("%b")) if show else ""})
        m = date(m.year + (m.month == 12), m.month % 12 + 1, 1)
    return {"segs": segs, "bars": bars, "races": races, "months": months,
            "today": X(t) if t0 <= t <= t1 else None, "top": top}
