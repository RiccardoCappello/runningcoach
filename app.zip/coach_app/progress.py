"""The Progress page: race predictions, the goal check (with a what-if), training load.

Everything here is read-only: it explains the plan and the logs, it never changes them."""
from __future__ import annotations

from datetime import date, timedelta

from coach_engine import load as LD
from coach_engine import predict as PR
from coach_engine.fitness import age_on, fmt_pace, fmt_time, parse_distance
from coach_engine.profile_io import profile_from_toml

from . import store

GOAL_DISTANCES = [(5000.0, "5 km"), (10000.0, "10 km"), (21097.5, "Half marathon"), (42195.0, "Marathon")]


def current_volume(data: dict, logs: dict, prof, t: date) -> tuple:
    """(weekly km, longest recent long run): from the last 4 finished plan weeks once there are
    logs, else what the profile says."""
    weekly, longest = prof.recent.weekly_km, prof.recent.long_run_km or 0.0
    done = []
    for w in data["weeks"]:
        start = date.fromisoformat(w["start"])
        if start + timedelta(days=6) < t and start >= t - timedelta(days=42):
            km = sum(store.done_km(s, logs.get(s["id"])) for s in w["sessions"])
            if any(s["id"] in logs for s in w["sessions"]):
                done.append(km)
            for s in w["sessions"]:
                if s["kind"] == "long" and s["id"] in logs and logs[s["id"]]["completed"] != "no":
                    longest = max(longest, store.done_km(s, logs[s["id"]]))
    if len(done) >= 2:
        weekly = sum(done[-4:]) / len(done[-4:])
    return weekly, longest


def curve(data: dict, prof, t: date) -> dict:
    """The runner's curve, with the plan's current VDOT (it moves after time trials and bumps)."""
    created = date.fromisoformat(data["created"])
    vd0, basis_m, slope, n = PR.runner_curve(prof, created)
    return {"vdot": data["vdot"], "basis_m": basis_m, "slope": slope, "n": n,
            "provisional": data.get("provisional", False)}


def check(data, prof, c, weekly, longest, t, distance_m=None, target_s=None, race_date=None):
    g = data["goal"]
    distance_m = distance_m or g["distance_m"]
    weeks = None
    if race_date is None and distance_m == g["distance_m"] and g.get("race_date"):
        race_date = date.fromisoformat(g["race_date"])
    if race_date is None:
        weeks = max(0.0, (store.plan_end(data) - t).days / 7)
    if target_s is None and distance_m == g["distance_m"]:
        target_s = g.get("target_time_s")
    # the plan's own goal: "realistic by then" is the plan's end-of-plan prediction, the number
    # the Plan page shows (a what-if for another distance or date is modelled from today)
    end_vdot = race_km = None
    own_date = date.fromisoformat(g["race_date"]) if g.get("race_date") else None
    if abs(distance_m - g["distance_m"]) < 1 and race_date == own_date and data.get("goal_vdot"):
        end_vdot, race_km = data["goal_vdot"], store.plan_peak(data, prof)
    a = prof.athlete
    av = prof.availability
    return PR.goal_check(distance_m, t, c["vdot"], c["basis_m"], c["slope"], weekly, longest, a.years_running,
                         age_on(a.birth_date, t), target_s, race_date, weeks,
                         cautious=a.injury_prone or age_on(a.birth_date, t) >= 40 or a.years_running < 1,
                         cap_km=av.max_weekly_km, race_weekly_km=race_km, end_vdot=end_vdot)


def check_view(gc) -> dict:
    return {"verdict": gc.verdict, "headline": gc.headline, "reasons": gc.reasons, "tips": gc.tips,
            "weeks_available": None if gc.weeks_available is None else round(gc.weeks_available, 1),
            "weeks_needed": gc.weeks_needed if gc.weeks_needed < 99 else None,
            "target": fmt_time(gc.target_s) if gc.target_s else None,
            "now": fmt_time(gc.predicted_now_s),
            "realistic": fmt_time(gc.realistic_s) if gc.realistic_s else None,
            "distance": PR.NAMES.get(gc.distance_m, "")}


def context(u, pid: int, data: dict, t: date) -> dict:
    prof = profile_from_toml(u.plan_profile(pid), date.fromisoformat(data["created"]))
    logs = u.logs(pid)
    weekly, longest = current_volume(data, logs, prof, t)
    c = curve(data, prof, t)
    now = PR.all_predictions(c["vdot"], c["basis_m"], c["slope"], weekly)
    end = PR.all_predictions(data.get("goal_vdot") or c["vdot"], c["basis_m"], c["slope"],
                             store.plan_peak(data, prof))
    preds = [{"name": a.name, "m": a.distance_m, "now": fmt_time(a.time_s), "now_pace": fmt_pace(a.pace_s),
              "end": fmt_time(b.time_s), "end_pace": fmt_pace(b.pace_s), "note": a.note,
              "goal": abs(a.distance_m - data["goal"]["distance_m"]) < 1} for a, b in zip(now, end)]
    gc = check(data, prof, c, weekly, longest, t)

    # fitness history: the VDOT in force each week (it changes after a time trial / accepted bump)
    hist, last = [], None
    for w in data["weeks"]:
        v = (w.get("zones") or data["zones"])["vdot"]
        if date.fromisoformat(w["start"]) <= t and v != last:
            hist.append({"date": w["start"], "vdot": v})
            last = v

    # training load: seeded with the recent weekly km at easy effort
    # seed: the load of the first full planned week (what you were doing, at the plan's mix of
    # easy and hard), so the curves start at "usual" instead of zero or easy-only
    first = next((w for w in data["weeks"] if w["kind"] == "normal"), data["weeks"][0])
    seed = sum(LD.planned_load(s) for s in first["sessions"] if s["kind"] != "rest") / 7
    series = LD.daily_load(data, logs, t, seed)
    status = LD.load_status(series, t)
    weeks = []
    for w in data["weeks"]:
        s, e = w["start"], (date.fromisoformat(w["start"]) + timedelta(days=6)).isoformat()
        days = [x for x in series if s <= x["date"] <= e]
        weeks.append({"index": w["index"], "kind": w["kind"], "planned": sum(x["planned"] for x in days),
                      "done": sum(x["done"] or 0 for x in days) if any(x["done"] is not None for x in days) else None,
                      "past": date.fromisoformat(s) <= t})
    return {"curve": c, "preds": preds, "goal": check_view(gc), "hist": hist, "series": series,
            "status": status, "load_weeks": weeks, "weekly": weekly, "longest": longest,
            "distances": GOAL_DISTANCES, "goal_m": data["goal"]["distance_m"],
            "goal_date": data["goal"].get("race_date") or store.plan_end(data).isoformat()}


def what_if(u, pid: int, data: dict, t: date, distance: str, target: str, when: str) -> dict:
    """The goal check for any distance / time / date (the what-if on the Progress page)."""
    from coach_engine.fitness import parse_time_text
    prof = profile_from_toml(u.plan_profile(pid), date.fromisoformat(data["created"]))
    weekly, longest = current_volume(data, u.logs(pid), prof, t)
    c = curve(data, prof, t)
    m = parse_distance(distance) if not distance.replace(".", "").isdigit() else float(distance)
    target_s = parse_time_text(target) if target.strip() else None
    race_date = date.fromisoformat(when) if when else None
    if race_date is not None and race_date < t:
        raise ValueError("that date is in the past")
    return check_view(check(data, prof, c, weekly, longest, t, m, target_s, race_date))


def preview_check(toml: str, new: dict, t: date) -> dict:
    """The goal check for a plan that is only a preview (onboarding / Setup), from the profile alone."""
    prof = profile_from_toml(toml, t)
    vd, basis_m, slope, n = PR.runner_curve(prof, t)
    c = {"vdot": new["vdot"], "basis_m": basis_m, "slope": slope}
    if prof.recent.status == "beginner":
        return None
    return check_view(check(new, prof, c, prof.recent.weekly_km, prof.recent.long_run_km or 0.0, t))


def today_summary(u, pid: int, data: dict, t: date) -> dict | None:
    """The two small things Today shows: the countdown to the goal and the load status."""
    try:
        cx = context(u, pid, data, t)
    except (ValueError, KeyError, ZeroDivisionError):
        return None
    g = data["goal"]
    when = date.fromisoformat(g["race_date"]) if g.get("race_date") else store.plan_end(data)
    goal_pred = next((p for p in cx["preds"] if p["goal"]), None)
    return {"name": PR.NAMES.get(g["distance_m"], f"{g['distance_m'] / 1000:g} km"),
            "what": "Race" if g.get("race_date") else "Time trial", "date": when, "days": (when - t).days,
            "verdict": cx["goal"]["verdict"] if cx["goal"] else None,
            "now": goal_pred["now"] if goal_pred else None,
            "by_then": cx["goal"]["realistic"] if cx["goal"] else None,
            "target": cx["goal"]["target"] if cx["goal"] else None,
            "provisional": cx["curve"]["provisional"], "status": cx["status"]}
