"""Garmin data through intervals.icu (spec §12): activities, laps and wellness arrive on their own.

Garmin uploads every activity to intervals.icu (its official Garmin link); the app reads them
with the runner's personal API key. intervals.icu allows calls from the phone app's address
(CORS), so on the phone this runs in the browser with no server in between.

Each new activity is matched to the planned session of that day (key sessions may also be a day
early or late) and logged as if the runner had typed it: minutes, average HR, the feel from the
reps against their target paces, the finish time of a time trial. Anything that matches nothing
becomes an extra activity. A session the runner logged by hand is never overwritten.

Strava activities that reach intervals.icu are not served by its API (Strava's terms), so Garmin
must be linked to intervals.icu directly.
"""
from __future__ import annotations

import base64
import json
import urllib.error
import urllib.request
from datetime import date, datetime, timedelta

from coach_engine import analysis as A
from coach_engine.load import rpe_from_hr

from . import store

API = "https://intervals.icu/api/v1"
FIRST_SYNC_DAYS = 56          # the first sync reaches back this far (efficiency trend history)
OVERLAP_DAYS = 3              # later syncs re-read the last days (activities processed late)
AUTO_EVERY_MIN = 20           # Today syncs on its own when the last sync is older than this
RECENT_DAYS = 14              # activities this recent always show (as extras if no session fits), even
                              # before the plan starts; older ones from before the plan feed the trends only


class IcuError(Exception):
    pass


# ------------------------------------------------------------------ transport
async def _fetch_json(url: str, key: str):
    """GET url with the API key (basic auth, user API_KEY). In the phone app (Pyodide) through
    the browser's fetch, on a server with urllib."""
    auth = "Basic " + base64.b64encode(f"API_KEY:{key}".encode()).decode()
    headers = {"Authorization": auth, "Accept": "application/json"}
    try:
        from pyodide.http import pyfetch          # noqa: PLC0415 - only exists in the phone app
    except ImportError:
        pyfetch = None
    if pyfetch is not None:
        try:
            r = await pyfetch(url, headers=headers)
        except Exception as e:                    # offline, blocked
            raise IcuError("no connection to intervals.icu") from e
        if r.status != 200:
            raise IcuError(_status_text(r.status))
        return await r.json()

    def get():
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=25) as f:
                return json.load(f)
        except urllib.error.HTTPError as e:
            raise IcuError(_status_text(e.code)) from e
        except OSError as e:
            raise IcuError("no connection to intervals.icu") from e
    import anyio.to_thread                        # noqa: PLC0415
    return await anyio.to_thread.run_sync(get)


def _status_text(code: int) -> str:
    if code in (401, 403):
        return "intervals.icu refused the API key (check it in intervals.icu > Settings > Developer settings)"
    if code == 404:
        return "intervals.icu doesn't know that athlete ID"
    if code == 429:
        return "intervals.icu is busy (too many requests): it will try again later"
    return f"intervals.icu answered {code}"


fetch_json = _fetch_json          # tests replace this


async def check_key(athlete_id: str, key: str) -> str:
    """The athlete's id if the key works (athlete id 0 = the key's own athlete)."""
    a = await fetch_json(f"{API}/athlete/{athlete_id or '0'}", key)
    return str(a.get("id") or athlete_id or "0")


# --------------------------------------------------------------------- parse
def kind_of(icu_type: str) -> str:
    t = (icu_type or "").lower()
    if "run" in t:
        return "run"
    if "ride" in t or "cycl" in t or "bike" in t:
        return "bike"
    if "swim" in t:
        return "swim"
    if t in ("walk", "hike"):
        return "walk"
    if t in ("weighttraining", "workout", "crossfit", "yoga", "pilates"):
        return "gym"
    return "sport"


def _num(x):
    return float(x) if isinstance(x, (int, float)) else None


def parse_activity(a: dict) -> dict:
    gap = _num(a.get("gap"))
    return {
        "ext_id": str(a["id"]), "date": str(a["start_date_local"])[:10],
        "start": str(a["start_date_local"])[11:16] or None, "kind": kind_of(a.get("type")),
        "name": a.get("name") or "", "minutes": round((_num(a.get("moving_time")) or 0) / 60, 1),
        "km": round((_num(a.get("distance")) or _num(a.get("icu_distance")) or 0) / 1000, 2),
        "avg_hr": _num(a.get("average_heartrate")), "max_hr": _num(a.get("max_heartrate")),
        "speed": _num(a.get("average_speed")), "gap": gap if gap and 0.5 < gap < 10 else None,
        "elev_m": _num(a.get("total_elevation_gain")),
        "feels_like": _num(a.get("average_feels_like")) if a.get("average_feels_like") is not None
        else _num(a.get("average_weather_temp")),
        "decoupling": _num(a.get("decoupling")),
        "rpe": _num(a.get("icu_rpe")) or _num(a.get("perceived_exertion")),
    }


def parse_laps(dto: dict) -> list:
    out = []
    for i in (dto or {}).get("icu_intervals") or []:
        gap = _num(i.get("gap"))
        out.append({"type": i.get("type") or "WORK", "km": round((_num(i.get("distance")) or 0) / 1000, 3),
                    "secs": _num(i.get("moving_time")) or _num(i.get("elapsed_time")),
                    "speed": _num(i.get("average_speed")), "gap": gap if gap and 0.5 < gap < 10 else None,
                    "hr": _num(i.get("average_heartrate"))})
    return out


# ------------------------------------------------------------------- matching
FITS = {"run": ("easy", "long", "quality", "tt"), "bike": ("xt",), "swim": ("xt",), "sport": ("xt",),
        "walk": (), "gym": ("strength",)}


def match(data: dict, logs: dict, act: dict, taken: set):
    """(week, session) this activity is, or (None, None). Same day first; a long run or key
    session may also be a day early or late if its own day has nothing that fits."""
    d = date.fromisoformat(act["date"])

    def candidates(day: date, kinds: tuple):
        w, wd = store.week_for(data, day)
        if w is None:
            return []
        return [(w, s) for s in w["sessions"] if s["day"] == wd and s["kind"] in kinds and s["id"] not in taken
                and (s["id"] not in logs or logs[s["id"]]["source"] == "icu")]

    kinds = FITS.get(act["kind"], ())
    best = candidates(d, kinds)
    if not best and act["kind"] == "run":
        moved = candidates(d - timedelta(days=1), ("long", "quality")) + candidates(d + timedelta(days=1), ("long", "quality"))
        best = [(w, s) for w, s in moved if abs(store.session_minutes(s) - act["minutes"]) <= 0.3 * store.session_minutes(s)]
    if not best:
        return None, None
    return min(best, key=lambda ws: abs(store.session_minutes(ws[1]) - act["minutes"]))


def tt_result(s: dict, act: dict, laps: list) -> float | None:
    """Finish time of a time trial / race: the whole activity if it is the race distance, else the
    work lap of that distance (warm-up recorded in the same activity)."""
    km = sum(g["km"] for g in s["segments"] if g["zone"] == "TT")
    if not km:
        return None
    if act["km"] and abs(act["km"] - km) / km < 0.04:
        return act["minutes"] * 60
    fits = [l for l in laps if l["km"] and abs(l["km"] - km) / km < 0.04 and l["secs"]]
    return min(l["secs"] for l in fits) if fits else None


def reps_for(data: dict, w: dict, s: dict, laps: list) -> tuple:
    """(reps, band) of a key session from its laps; ([], None) when it has no paced reps."""
    zone = A.work_zone(s)
    z = store.zones_of(data, w)
    band = z.paces.get(zone) if zone and zone != "TT" else None
    if not band or band[1] is None or not laps:
        return [], None
    return A.work_reps(laps, band, A.planned_reps(s)), band


def log_fields(data: dict, w: dict, s: dict, act: dict, laps: list) -> dict:
    planned = store.session_minutes(s)
    mins = act["minutes"] or None
    completed = "yes" if not planned or (mins or 0) >= 0.85 * planned else "partial"
    reps, _ = reps_for(data, w, s, laps) if s["kind"] == "quality" else ([], None)
    feel = A.rep_feel(reps)
    rpe = act["rpe"]
    res = store.score_log(store.zones_of(data, w), s, completed, mins, rpe, feel, False, act["avg_hr"])
    return {"completed": completed, "minutes": mins, "rpe": rpe, "feel": feel, "reserve": 0, "avg_hr": act["avg_hr"],
            "notes": None, "score": res["score"], "step": res["step"], "flags": json.dumps(res["flags"]),
            "result_s": tt_result(s, act, laps) if s["kind"] == "tt" else None, "source": "icu",
            "km": act["km"] if act["kind"] == "run" and act["km"] else None,
            # no feel from the watch: the effort its heart rate shows, for the load (steady runs only)
            "effort": rpe_from_hr(act["avg_hr"], store.zones_of(data, w).hr)
            if rpe is None and s["kind"] in ("easy", "long") else None}


def steady(act_row, sess: dict | None, z) -> bool:
    """Counts for the efficiency trend: an easy or plain long run, or an unplanned run at easy HR."""
    if act_row["kind"] != "run" or not act_row["avg_hr"]:
        return False
    if sess is not None:
        return sess["kind"] in ("easy", "long") and sess["family"] in ("easy", "long", "hills")
    hi = z.hr["E"][1] if z else None
    return hi is not None and act_row["avg_hr"] <= hi + 3


# ----------------------------------------------------------------------- sync
def attach(u, pid: int, data: dict, row, w: dict, s: dict) -> None:
    """Make a stored watch activity the given planned session: log the session from it (unless it
    was logged by hand) and remove the extra activity the sync had made for it."""
    act = {k: row[k] for k in row.keys()}
    laps = json.loads(act["laps"] or "[]")
    if u.get_log(pid, s["id"]) is None:
        d = date.fromisoformat(w["start"]) + timedelta(days=s["day"])
        u.save_log(pid, s["id"], d, **log_fields(data, w, s, act, laps))
    if act["extra_id"]:
        x = u.extra(act["extra_id"])
        if x is not None and (x["notes"] or "").startswith("from Garmin"):
            u.delete_extra(act["extra_id"])
    act.update(plan_id=pid, session_id=s["id"], extra_id=None)
    u.save_activity(**act)


def backfill_effort(u) -> None:
    """Watch-logged easy / long runs from before the HR effort existed: add it (for the load)."""
    pid, data = u.active_plan()
    if data is None:
        return
    logs = u.logs(pid)
    for row in u.activities(date.fromisoformat(data["start"])):
        lg = logs.get(row["session_id"]) if row["plan_id"] == pid else None
        if lg is None or lg["rpe"] is not None or lg["effort"] is not None or not (lg["source"] or "").startswith("icu"):
            continue
        w, s, _ = store.find_session(data, row["session_id"])
        if s is not None and s["kind"] in ("easy", "long"):
            e = rpe_from_hr(row["avg_hr"], store.zones_of(data, w).hr)
            if e is not None:
                u.set_log_effort(pid, s["id"], e)


def rematch(u, t: date) -> list:
    """Watch activities already stored that aren't a session of the active plan (synced before this
    plan was built or its start moved): match them again. Returns the titles logged."""
    pid, data = u.active_plan()
    if data is None:
        return []
    rows = u.activities(date.fromisoformat(data["start"]))
    taken = {r["session_id"] for r in rows if r["plan_id"] == pid and r["session_id"]}
    logs = u.logs(pid)
    done = []
    for row in rows:
        if (row["plan_id"] == pid and row["session_id"]) or row["date"] > t.isoformat():
            continue
        act = {k: row[k] for k in row.keys()}
        w, s = match(data, logs, act, taken)
        if s is None:
            continue
        taken.add(s["id"])
        attach(u, pid, data, row, w, s)
        logs = u.logs(pid)
        done.append(s["title"])
    return done


def _shows(act: dict, data: dict | None, t: date) -> bool:
    """Not matched to a session: does it become an extra activity? Inside the plan, or recent."""
    return (data is not None and act["date"] >= data["start"]) or         act["date"] >= (t - timedelta(days=RECENT_DAYS)).isoformat()


def _as_extra(u, act: dict, z=None) -> int:
    note = f"from Garmin: {act['name']}" if act.get("name") else "from Garmin"
    rpe = act["rpe"]
    if rpe is None and act["kind"] == "run" and z is not None:
        rpe = rpe_from_hr(act["avg_hr"], z.hr)               # its heart rate tells how hard it was
        if rpe is not None:
            note += " (feel estimated from heart rate)"
    return u.save_extra(None, date.fromisoformat(act["date"]), act["kind"], max(1.0, act["minutes"] or 1.0),
                        act["km"] if act["kind"] == "run" else None, rpe, note)



def due(cfg, now: datetime | None = None) -> bool:
    if cfg is None:
        return False
    if not cfg["synced_at"]:
        return True
    last = datetime.fromisoformat(cfg["synced_at"])
    return (now or datetime.now()) - last > timedelta(minutes=AUTO_EVERY_MIN)


async def sync(u, t: date) -> dict:
    """Fetch and log everything new. Returns {"new", "logged": [titles], "extras", "skipped_strava",
    "error"}; never raises for connection problems (they go to Settings)."""
    cfg = u.icu()
    out = {"new": 0, "logged": [], "extras": 0, "skipped_strava": 0, "error": None, "changed": False}
    if cfg is None:
        return out
    aid, key = cfg["athlete_id"], cfg["api_key"]
    pid, data = u.active_plan()
    if cfg["synced_at"]:
        oldest = date.fromisoformat(cfg["synced_at"][:10]) - timedelta(days=OVERLAP_DAYS)
    else:
        oldest = t - timedelta(days=FIRST_SYNC_DAYS)
    try:
        acts = await fetch_json(f"{API}/athlete/{aid}/activities?oldest={oldest.isoformat()}"
                                f"&newest={t.isoformat()}T23:59:59", key)
        logs = u.logs(pid) if pid else {}
        taken = set()
        for a in sorted(acts or [], key=lambda a: str(a.get("start_date_local"))):
            if a.get("source") == "STRAVA" or not a.get("start_date_local"):
                out["skipped_strava"] += a.get("source") == "STRAVA"
                continue
            if u.activity_by_ext(str(a["id"])) is not None:
                continue
            act = parse_activity(a)
            laps = []
            if act["kind"] == "run" and act["minutes"] >= 8:
                laps = parse_laps(await fetch_json(f"{API}/activity/{act['ext_id']}/intervals", key))
            act["laps"] = json.dumps(laps)
            out["new"] += 1
            w, s = match(data, logs, act, taken) if data else (None, None)
            if s is not None:
                taken.add(s["id"])
                act.update(plan_id=pid, session_id=s["id"])
                if s["id"] not in logs:
                    d = date.fromisoformat(w["start"]) + timedelta(days=s["day"])
                    u.save_log(pid, s["id"], d, **log_fields(data, w, s, act, laps))
                    out["logged"].append(s["title"])
            elif _shows(act, data, t):
                act["extra_id"] = _as_extra(u, act, store.zones_of(data, None) if data else None)
                out["extras"] += 1
            u.save_activity(**act)
        # activities stored before this plan existed (or its start moved): match them again
        relogged = rematch(u, t)
        out["logged"] += relogged
        out["new"] += len(relogged)
        backfill_effort(u)
        # activities stored earlier for the trends only that now count as recent: show them too
        for row in u.activities(t - timedelta(days=RECENT_DAYS)):
            if row["session_id"] is None and row["extra_id"] is None and _shows(dict(row), data, t):
                fields = {k: row[k] for k in row.keys()}
                u.save_activity(**{**fields, "extra_id": _as_extra(u, fields, store.zones_of(data, None) if data else None)})
                out["extras"] += 1
                out["new"] += 1
        for r in await fetch_json(f"{API}/athlete/{aid}/wellness?oldest={(t - timedelta(days=14)).isoformat()}"
                                  f"&newest={t.isoformat()}", key) or []:
            if r.get("id"):
                u.save_wellness(str(r["id"])[:10], _num(r.get("restingHR")), _num(r.get("hrv")),
                                _num(r.get("sleepSecs")), _num(r.get("sleepScore")))
    except IcuError as e:
        u.icu_status(False, str(e))
        out["error"] = str(e)
        return out
    u.icu_status(True, None)
    out["changed"] = bool(out["new"])
    return out


# ------------------------------------------------------------------ morning check
def sleep_scale(w) -> int | None:
    """Watch sleep -> the 1-5 sleep answer of the morning check."""
    if w is None:
        return None
    if w["sleep_score"]:
        s = w["sleep_score"]
        return 5 if s >= 85 else 4 if s >= 75 else 3 if s >= 60 else 2 if s >= 45 else 1
    if w["sleep_secs"]:
        h = w["sleep_secs"] / 3600
        return 5 if h >= 8 else 4 if h >= 7 else 3 if h >= 6 else 2 if h >= 5 else 1
    return None


def hrv_note(rows: list, today_row) -> str:
    """HRV today against the last week (shown only; the readiness rules don't use it: a single HRV
    reading is noisy, and the questionnaire works as well in studies, spec S29)."""
    vals = [r["hrv"] for r in rows if r["hrv"] and r["date"] != (today_row["date"] if today_row else "")]
    if not today_row or not today_row["hrv"] or len(vals) < 4:
        return ""
    base = sorted(vals)[len(vals) // 2]
    d = (today_row["hrv"] - base) / base
    if d < -0.15:
        return f"HRV {today_row['hrv']:.0f}, well below your usual {base:.0f}: take it easy if you also feel flat"
    if d > 0.15:
        return f"HRV {today_row['hrv']:.0f}, above your usual {base:.0f}"
    return f"HRV {today_row['hrv']:.0f}, about your usual {base:.0f}"
