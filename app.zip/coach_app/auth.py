"""Accounts: scrypt password hashes and a signed session cookie (stdlib only).

The cookie is "<user id>.<expiry>.<hmac>"; the HMAC key comes from COACH_SECRET or, if unset,
a random key stored next to the database (so logins survive restarts).
"""
from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import time
from pathlib import Path

COOKIE = "coach_session"
MAX_AGE = 60 * 60 * 24 * 90          # stay logged in for 90 days on a device


def hash_pw(pw: str, salt: str | None = None) -> tuple:
    salt = salt or secrets.token_hex(16)
    h = hashlib.scrypt(pw.encode(), salt=bytes.fromhex(salt), n=2 ** 14, r=8, p=1, dklen=32)
    return h.hex(), salt


def check_pw(pw: str, stored: str, salt: str) -> bool:
    return hmac.compare_digest(hash_pw(pw, salt)[0], stored)


def load_secret(db_path: Path) -> bytes:
    env = os.environ.get("COACH_SECRET")
    if env:
        return env.encode()
    f = Path(db_path).with_name("secret.key")
    if not f.exists():
        f.write_text(secrets.token_hex(32), encoding="ascii")
    return f.read_text(encoding="ascii").strip().encode()


def _sig(key: bytes, msg: str) -> str:
    return hmac.new(key, msg.encode(), hashlib.sha256).hexdigest()[:32]


def make_cookie(key: bytes, uid: int) -> str:
    msg = f"{uid}.{int(time.time()) + MAX_AGE}"
    return f"{msg}.{_sig(key, msg)}"


def read_cookie(key: bytes, value: str | None) -> int | None:
    try:
        uid, exp, sig = (value or "").split(".")
        if hmac.compare_digest(sig, _sig(key, f"{uid}.{exp}")) and int(exp) > time.time():
            return int(uid)
    except ValueError:
        pass
    return None
