"""Glue between the stored plan (JSON, see coach_engine.serialize) and the pages: lookups,
display helpers, logging, readiness, and the M2 re-plan after every change."""
from __future__ import annotations

import json
import statistics
from datetime import date, timedelta

from coach_engine import adapt
from coach_engine.models import DAYS
from coach_engine.profile_io import profile_from_toml
from coach_engine.render import target
from coach_engine.replan import Break, Checked, Logged, Race, main_zone, replan, target_rpe
from coach_engine.serialize import plan_to_dict, week_from, week_to_dict, zones_from  # noqa: F401 (re-export)
from coach_engine.zones import ZONE_NAMES, Zones

SEVERITY = {None: 0, "green": 0, "amber": 1, "red": 2}
STEP_TEXT = {1: "step up next time", 0: "repeat this level next time", -1: "step back next time"}
# extra activities (not in the plan); only runs count towards the weekly km
EXTRA_KINDS = {"run": "Run", "bike": "Bike", "swim": "Swim", "walk": "Walk / hike", "gym": "Gym / strength",
               "sport": "Other sport"}
BACKUP_EVERY = 14         # phone app: remind to save a backup after this many days


def extra_km(extras, first: str, last: str) -> float:
    return sum(x["km"] or 0.0 for x in extras if x["kind"] == "run" and first <= x["date"] <= last)


def week_end(w: dict) -> str:
    return (date.fromisoformat(w["start"]) + timedelta(days=6)).isoformat()


# ------------------------------------------------------------------ lookups
def week_for(data: dict, d: date):
    """(week dict, weekday) containing date d, or (None, None)."""
    for w in data["weeks"]:
        start = date.fromisoformat(w["start"])
        if start <= d < start + timedelta(days=7):
            return w, (d - start).days
    return None, None


def find_session(data: dict, sid: str):
    """(week dict, session dict, date) for a session id."""
    for w in data["weeks"]:
        for s in w["sessions"]:
            if s["id"] == sid:
                return w, s, date.fromisoformat(w["start"]) + timedelta(days=s["day"])
    return None, None, None


def plan_end(data: dict) -> date:
    return date.fromisoformat(data["weeks"][-1]["start"]) + timedelta(days=6)


def plan_peak(data: dict, prof) -> float:
    """The volume the plan races on (builder.peak_weekly): its biggest normal week."""
    return max([w["target_km"] for w in data["weeks"] if w["kind"] == "normal"] + [prof.recent.weekly_km])


def zones_of(data: dict, w: dict | None) -> Zones:
    """Paces/HR in force in week w (they change after a time trial, S40)."""
    return zones_from((w or {}).get("zones") or data["zones"])


# ----------------------------------------------------------------- display
def session_minutes(s: dict) -> float:
    return sum(g["minutes"] for g in s["segments"])


def session_km(s: dict) -> float:
    return sum(g["km"] for g in s["segments"])


def fmt_min(m: float) -> str:
    m = round(m)
    return f"{m // 60}h{m % 60:02d}" if m >= 60 else f"{m}′"


def segment_lines(z: Zones, s: dict) -> list:
    """One dict per segment: label, zone name, target text, minutes, km, and its css kind."""
    out = []
    for g in s["segments"]:
        zone, label = g["zone"], g["label"]
        plain = zone == "walk" or (zone in ("E", "rec") and any(
            w in label for w in ("warm-up", "cool-down", "jog", "walk")))
        if plain or zone in ("STR", "TT"):
            zname, tgt = "", ""
        elif zone in ("E", "XT"):
            zname, tgt = "", target(z, zone, s["primary"])
        else:
            zname, tgt = ZONE_NAMES.get(zone, zone), target(z, zone, s["primary"])
        out.append({"label": label, "zone": zname, "target": tgt, "minutes": g["minutes"], "km": g["km"],
                    "kind": "z-" + zone.lower(), "quiet": plain})
    return out


BAR_CLASS = {"E": "z-e", "rec": "z-rec", "walk": "z-walk", "M": "z-m", "T": "z-t", "RP": "z-rp", "I": "z-i",
             "R": "z-r", "S": "z-s", "TT": "z-tt", "XT": "z-xt", "STR": "z-str"}


def zone_bar(s: dict) -> list:
    """The session as a strip of zones, each as wide as its share of the time: [(percent, css, title)]."""
    total = session_minutes(s)
    if not total or s["kind"] in ("rest", "strength", "xt"):
        return []
    return [(100 * g["minutes"] / total, BAR_CLASS.get(g["zone"], "z-e"),
             f"{g['label']} · {fmt_min(g['minutes'])}") for g in s["segments"] if g["minutes"] > 0]


def explain_total(s: dict) -> str:
    """One sentence on where the total comes from: the 'NN′ easy' label is only the easy part;
    strides, hill sprints, warm-ups and recoveries add their own time and distance."""
    if s["kind"] in ("rest", "strength", "xt") or len(s["segments"]) < 2:
        return ""
    zones = {g["zone"] for g in s["segments"]}
    bits = []
    if s["family"] in ("runwalk", "test"):
        return ("The total is every line above added up: the walking counts as time, and as distance at a brisk "
                "walk. Go by the time and by feel - you should be able to talk while you run.")
    if "walk" in zones:
        bits.append("the walking back counts as time but adds only the short distance back to the start")
    if "rec" in zones:
        bits.append("the jogs between reps are part of the run")
    return ("The total is every line above added up" + (": " + "; ".join(bits) if bits else "") +
            ". Distances are estimates from your zone paces - go by the time.")


def week_stats(w: dict) -> dict:
    wk = week_from(w)
    return {"km": wk.km, "hours": wk.run_minutes / 60, "easy": wk.easy_share(),
            "hard_days": ",".join(DAYS[s.day] for s in wk.sessions if s.hard) or "-"}


def done_km(s: dict, log) -> float:
    """km actually covered, estimated from the log (planned km scaled by minutes run)."""
    if log is None or log["completed"] == "no":
        return 0.0
    planned = session_minutes(s)
    if log["minutes"] is not None and planned:
        return session_km(s) * min(1.5, log["minutes"] / planned)
    return session_km(s) * (1.0 if log["completed"] == "yes" else 0.5)


# ----------------------------------------------------------------- logging
def score_log(z: Zones, s: dict, completed: str, minutes: float | None, rpe: float | None,
              feel: str | None, reserve: bool, avg_hr: float | None) -> dict:
    """A1 score, A2 ladder step, A3 flat day, A4 easy creep for one logged session."""
    planned = session_minutes(s)
    if s["kind"] in ("rest", "strength", "xt"):
        return {"score": None, "step": None, "flags": []}
    done = 0.0 if completed == "no" else (minutes if minutes is not None else
                                          planned if completed == "yes" else planned / 2)
    trpe = target_rpe(s)
    score = adapt.session_score(planned, done, rpe, trpe, reserve=reserve, self_report=feel)
    flags = []
    step = None
    if s["kind"] in ("quality", "easy") and s["level"] is not None:     # key sessions and run/walk (§10.8)
        step = adapt.ladder_step(score, reserve, completed == "yes")
    if completed == "partial" and adapt.flat_day(rpe, trpe, cut_by_feel=True):
        flags.append("A3: flat day - cut short and felt much harder than planned; counts toward the fatigue check")
    if s["kind"] in ("easy", "long") and main_zone(g["zone"] for g in s["segments"]) in ("E", "rec", "S", "walk"):
        if adapt.easy_creep(avg_hr, z.hr["E"][1], rpe):
            flags.append(f"A4: easy creep - easy run above HR {z.hr['E'][1]} or felt 5+; keep easy days easy")
    return {"score": score, "step": step, "flags": flags}


# --------------------------------------------------------------- readiness
def waking_hr_baseline(previous: list) -> float | None:
    """7-day median waking HR (A5-A7); needs at least 3 readings."""
    vals = [r["waking_hr"] for r in previous if r["waking_hr"]]
    return statistics.median(vals) if len(vals) >= 3 else None


def check_readiness(sleep, soreness, mood, ill, waking_hr, baseline) -> tuple:
    r = adapt.Readiness(sleep=sleep, soreness=soreness, mood=mood, ill=ill,
                        waking_hr=waking_hr, hr_baseline=baseline)
    return adapt.classify(r)


def apply_readiness(data: dict, d: date, level: str) -> list:
    """A6/A7 on the stored plan, in place. Returns the change texts."""
    w, day = week_for(data, d)
    if w is None:
        return []
    wk = week_from(w)
    changes = adapt.apply_readiness(wk, day, level, data.get("gap_min", 2))
    if changes:
        data["weeks"][data["weeks"].index(w)] = week_to_dict(wk)
    return changes


# --------------------------------------------------------------- re-plan (M2)
def run_replan(dbx, pid: int, data: dict, today: date) -> list:
    """Rebuild the weeks still to come from everything logged; store the plan, write each new
    change to the plan-changes log. Returns the open proposals (A11 bump, unfinished break)."""
    created = date.fromisoformat(data["created"])
    profile = profile_from_toml(dbx.plan_profile(pid), created)
    logs = []
    for sid, r in dbx.logs(pid).items():
        flags = tuple(f.split(":")[0] for f in json.loads(r["flags"] or "[]"))
        logs.append(Logged(sid, r["completed"], r["score"], r["step"], r["rpe"], flags, r["result_s"]))
    checks = [Checked(date.fromisoformat(r["date"]), r["level"]) for r in dbx.readiness_since(created)]
    breaks = [Break(date.fromisoformat(b["first"]), date.fromisoformat(b["last"]) if b["last"] else None,
                    bool(b["cross_trained"]), b["reason"] or "") for b in dbx.time_off()]
    races = [Race(date.fromisoformat(r["date"]), r["distance_m"], r["name"] or "") for r in dbx.races()]
    res = replan(profile, data, logs, checks, today, breaks, races, dbx.bumps(pid))
    data.clear()
    data.update(res.data)
    dbx.save_plan_data(pid, data)
    for c in res.changes:
        dbx.add_event(pid, today, c.rule, c.text)
    return res.proposals
