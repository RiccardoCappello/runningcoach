"""Automatic backup of the phone app to a private GitHub repository (spec §20).

The phone app keeps everything in the browser's storage, which a phone can clear (the app deleted,
storage pressure, a new phone). Once a day, when Today opens, the whole database is gzipped and put
in a private repo of the runner's own through GitHub's contents API with a fine-grained token that
can only touch that one repo. Every backup is a commit, so older days can be got back from the repo's
history too. GitHub allows these calls from a web page (CORS), so the phone talks to it directly.

Restoring reads the file back and replaces the database on the phone. Only the phone app does this
(a server's database holds every account).

One repo, one phone: each phone has its own id, and the repo's `runningcoach.owner.json` says which
phone backs up there. A different phone (someone given the same token, or an old phone after a
restore elsewhere) stops with a warning instead of overwriting; it can take the repo over on purpose.
"""
from __future__ import annotations

import base64
import gzip
import json
import re
import urllib.error
import urllib.request
from datetime import date, datetime

API = "https://api.github.com"
PATH = "runningcoach.db.gz"
OWNER = "runningcoach.owner.json"
REPO_RE = re.compile(r"[A-Za-z0-9-]+/[A-Za-z0-9_.-]+")


class CloudError(Exception):
    pass


class OtherPhone(CloudError):
    """The repo belongs to another phone: nothing was written."""
    def __init__(self, name: str, since: str):
        self.name, self.since = name, since
        super().__init__(f"this repository holds the backup of another phone ({name}, since {since[:10]}); "
                         f"nothing was overwritten")


# ------------------------------------------------------------------ transport
async def _request(method: str, url: str, token: str, body: dict | None = None, raw: bool = False):
    """(status, json or bytes). In the phone app through the browser's fetch, on a server with urllib."""
    headers = {"Authorization": f"Bearer {token}", "X-GitHub-Api-Version": "2022-11-28",
               "Accept": "application/vnd.github.raw" if raw else "application/vnd.github+json"}
    data = json.dumps(body) if body is not None else None
    if data:
        headers["Content-Type"] = "application/json"
    try:
        from pyodide.http import pyfetch          # noqa: PLC0415 - only exists in the phone app
    except ImportError:
        pyfetch = None
    if pyfetch is not None:
        try:
            r = await pyfetch(url, method=method, headers=headers, **({"body": data} if data else {}))
        except Exception as e:                    # offline, blocked
            raise CloudError("no connection to GitHub") from e
        if r.status >= 300:
            return r.status, None
        return r.status, (await r.bytes() if raw else await r.json())

    def go():
        req = urllib.request.Request(url, data=data.encode() if data else None, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=30) as f:
                out = f.read()
                return f.status, (out if raw else json.loads(out or b"null"))
        except urllib.error.HTTPError as e:
            return e.code, None
        except OSError as e:
            raise CloudError("no connection to GitHub") from e
    import anyio.to_thread                        # noqa: PLC0415
    return await anyio.to_thread.run_sync(go)


request = _request          # tests replace this


def _why(code: int) -> str:
    if code in (401, 403):
        return "GitHub refused the token (it may have expired, or lacks Contents: read and write on this repo)"
    if code == 404:
        return "GitHub can't find that repository with this token (check the name, and that the token can see it)"
    return f"GitHub answered {code}"


# ----------------------------------------------------------------------- api
def clean_repo(text: str) -> str:
    """'github.com/me/runs', 'https://github.com/me/runs.git' or 'me/runs' -> 'me/runs'."""
    t = text.strip().removesuffix(".git").rstrip("/")
    t = re.sub(r"^(https?://)?(www\.)?github\.com/", "", t)
    if not REPO_RE.fullmatch(t):
        raise CloudError("write the repository as owner/name, e.g. riccardo/runningcoach-backup")
    return t


async def check(repo: str, token: str) -> None:
    """The repo exists, the token can see it, and it is private."""
    code, j = await request("GET", f"{API}/repos/{repo}", token)
    if code != 200:
        raise CloudError(_why(code))
    if not j.get("private"):
        raise CloudError("that repository is public: anyone could read your training and heart-rate data. "
                         "Make it private on GitHub (Settings → Danger zone → Change visibility) and try again")


async def _put(url: str, token: str, raw: bytes, message: str, sha: str | None):
    body = {"message": message, "content": base64.b64encode(raw).decode()}
    if sha:
        body["sha"] = sha
    code, _ = await request("PUT", url, token, body)
    if code not in (200, 201):
        raise CloudError(_why(code) if code != 409 else "GitHub was busy with another backup; it will try again")


async def claim(repo: str, token: str, device: str, name: str, today: date, take_over: bool = False) -> None:
    """Make sure the repo is this phone's: write the owner file if there is none (or when taking the
    repo over); raise OtherPhone if another phone owns it."""
    url = f"{API}/repos/{repo}/contents/{OWNER}"
    code, meta = await request("GET", url, token)
    if code not in (200, 404):
        raise CloudError(_why(code))
    if code == 200:
        c2, raw = await request("GET", url, token, raw=True)
        try:
            owner = json.loads(raw)
        except (TypeError, ValueError):
            owner = {}
        if owner.get("device") == device:
            return
        if owner.get("device") and not take_over:
            raise OtherPhone(owner.get("name") or "another phone", owner.get("since") or "")
    doc = {"device": device, "name": name, "since": today.isoformat()}
    await _put(url, token, json.dumps(doc, indent=1).encode(), f"RunningCoach: backups now from {name}",
               meta.get("sha") if code == 200 and meta else None)


async def upload(repo: str, token: str, db_bytes: bytes, today: date, device: str, name: str,
                 take_over: bool = False) -> int:
    """Put the gzipped database in the repo (one commit), if the repo is this phone's (claim).
    Returns the compressed size."""
    await claim(repo, token, device, name, today, take_over)
    url = f"{API}/repos/{repo}/contents/{PATH}"
    code, meta = await request("GET", url, token)
    if code not in (200, 404):
        raise CloudError(_why(code))
    gz = gzip.compress(db_bytes, 9, mtime=0)
    await _put(url, token, gz, f"RunningCoach backup {today.isoformat()} ({name})",
               meta.get("sha") if code == 200 and meta else None)
    return len(gz)


async def download(repo: str, token: str) -> bytes:
    """The database from the repo, checked to be a RunningCoach backup."""
    code, raw = await request("GET", f"{API}/repos/{repo}/contents/{PATH}", token, raw=True)
    if code == 404:
        raise CloudError(f"there is no backup in {repo} yet")
    if code != 200:
        raise CloudError(_why(code))
    try:
        out = gzip.decompress(raw)
    except (OSError, EOFError) as e:
        raise CloudError("the file in the repository isn't a RunningCoach backup") from e
    if not out.startswith(b"SQLite format 3\x00"):
        raise CloudError("the file in the repository isn't a RunningCoach backup")
    return out


def due(cfg, t: date) -> bool:
    """A backup once a day (the first time Today opens)."""
    return cfg is not None and (not cfg["backed_at"] or cfg["backed_at"][:10] < t.isoformat())


def db_bytes(con, path) -> bytes:
    """The database as one consistent file (sqlite's own copy when available)."""
    try:
        return con.serialize()
    except Exception:                            # older sqlite builds: the file itself
        return open(path, "rb").read()


def stamp() -> str:
    return datetime.now().isoformat(timespec="seconds")
