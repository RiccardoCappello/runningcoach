"""Season planning (macrocycle): several target races chained into blocks (spec §11).

- Races have a priority. A = a goal race: it gets its own block, built by the normal plan
  builder up to its date. B = a tune-up inside a block: the days around it go easy (A14/A15)
  once that block is the active plan. C = run it as training.
- Blocks follow each other: the first starts now, each later one after the recovery from the
  race before it (RECOVERY_DAYS). A block longer than MAX_WEEKS starts with a general base block
  instead (a block that is too long only stretches base and build thin).
- Fitness is chained: a later block starts from the time the block before predicts for its race
  (as if it had been run), on the volume that block reached. The spec's realistic gain (§1.5, about
  2 VDOT points per 12 weeks) is for one block; gains slow as a season goes on, so each later
  block keeps GAIN_DECAY of the gain of the one before (block 1 is exactly the active plan). When a race has been run, the real
  result replaces the prediction (the app puts it in the profile before starting the next block).

Pure: no I/O. The app supplies the profile and the races and stores nothing it computes here.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass, field
from datetime import date, timedelta

from . import library as L
from .builder import build_plan, monday_on_or_after
from .fitness import HALF, MARATHON, Performance, fmt_time, race_time
from .models import Goal, Profile

# days of easy running after a goal race before the next block starts (Daniels: about a day per
# 3 km raced before hard training again; Noakes is more cautious after a marathon)
RECOVERY_DAYS = {5000.0: 7, 10000.0: 10, HALF: 14, MARATHON: 28}
# a race block shorter than this is squeezed (still built, with a warning)
MIN_WEEKS = {5000.0: 6, 10000.0: 8, HALF: 10, MARATHON: 14}
# a race block longer than this gets a base block in front of it
MAX_WEEKS = {5000.0: 16, 10000.0: 18, HALF: 20, MARATHON: 24}
BASE_MIN_WEEKS = 4             # a shorter gap is added to the race block instead
BASE_MAX_WEEKS = 14            # a longer gap is split into several base blocks, each ending in a time trial
# what a base block aims at before a race block: speed and volume at a shorter distance first
BASE_FOCUS = {5000.0: 5000.0, 10000.0: 10000.0, HALF: 10000.0, MARATHON: HALF}
PRIORITIES = ("A", "B", "C")
GAIN_DECAY = 0.75


@dataclass
class SeasonRace:
    date: date
    distance_m: float
    priority: str = "A"                   # A | B | C
    name: str = ""
    target_time_s: float | None = None
    id: int | None = None                 # the app's row id

    @property
    def label(self) -> str:
        return self.name or f"{L.dist_name(self.distance_m)} race"


@dataclass
class Block:
    kind: str                     # race | base | recovery
    start: date                   # first day (a Monday, or the plan's first day for block 1)
    end: date                     # last day (race day for a race block)
    distance_m: float             # the race distance, or the focus of a base block
    race: SeasonRace | None = None
    phases: list = field(default_factory=list)      # [(phase, weeks)] in order: base/build/sharpen/taper
    weeks: int = 0
    vdot_start: float | None = None
    vdot_end: float | None = None
    predicted_s: float | None = None                # race block: predicted race time; base: final time trial
    start_km: float | None = None
    peak_km: float | None = None
    peak_long_km: float | None = None
    races: list = field(default_factory=list)       # B and C races inside the block
    notes: list = field(default_factory=list)
    weekly: list = field(default_factory=list)      # [(week start, target km, phase)] for the timeline
    plan: object = None                             # the built Plan (not stored)

    @property
    def title(self) -> str:
        if self.kind == "race":
            return self.race.label
        if self.kind == "base":
            return "Base block"
        return "Recovery"


@dataclass
class Season:
    blocks: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    races: list = field(default_factory=list)       # every race, sorted
    unplaced: list = field(default_factory=list)    # B/C races outside every block

    @property
    def race_blocks(self) -> list:
        return [b for b in self.blocks if b.kind == "race"]

    @property
    def end(self) -> date | None:
        return self.blocks[-1].end if self.blocks else None


def _key(table: dict, m: float) -> float:
    return L.nearest_key(table, m)


def recovery_days(distance_m: float) -> int:
    return RECOVERY_DAYS[_key(RECOVERY_DAYS, distance_m)]


def _phases(plan) -> list:
    out = []
    for w in plan.weeks:
        ph = "taper" if w.kind == "taper" else ("lead-in" if w.kind == "lead-in" else w.block)
        if out and out[-1][0] == ph:
            out[-1][1] += 1
        else:
            out.append([ph, 1])
    return [tuple(x) for x in out]


def _summarise(block: Block, plan, decay: float = 1.0) -> Block:
    """decay: share of the plan's own predicted gain this block keeps (GAIN_DECAY ** k)."""
    block.plan = plan
    block.weeks = len(plan.weeks)
    block.phases = _phases(plan)
    block.vdot_start = plan.vdot
    block.vdot_end = plan.goal_vdot
    block.predicted_s = plan.target_time_s
    if decay < 1 and plan.goal_vdot and plan.target_time_s:
        v = plan.vdot + decay * (plan.goal_vdot - plan.vdot)
        d = block.distance_m
        block.predicted_s = plan.target_time_s * race_time(v, d) / race_time(plan.goal_vdot, d)
        block.vdot_end = v
    normal = [w.target_km for w in plan.weeks if w.kind == "normal"] or [w.target_km for w in plan.weeks]
    block.start_km = plan.weeks[0].target_km
    block.peak_km = max(normal)
    longs = [s.km for w in plan.weeks for s in w.sessions if s.kind == "long"]
    block.peak_long_km = max(longs) if longs else None
    block.weekly = [(w.start, w.target_km, "taper" if w.kind == "taper" else w.block) for w in plan.weeks]
    return block


def _carry(p: Profile, block: Block, result_day: date, keep_km: float = 0.85) -> Profile:
    """The profile the next block starts from: the block's predicted result as a race, and the
    volume it reached (lower after the recovery days of a race, a little after a time trial)."""
    q = copy.deepcopy(p)
    if block.vdot_end:
        # the fitness reached, as an equivalent time (the predicted race time itself is slowed for
        # low volume over a half/marathon, which is not fitness lost)
        q.performances.append(Performance(block.distance_m, race_time(block.vdot_end, block.distance_m),
                                          result_day, "race" if block.kind == "race" else "time_trial"))
    q.recent.status = "regular"
    q.recent.weeks_off = 0.0
    q.recent.easy_pace_s = None
    q.recent.max_sustained_km = max(block.peak_km or 0.0, p.recent.max_sustained_km or 0.0) or None
    q.recent.weekly_km = round(keep_km * (block.peak_km or p.recent.weekly_km), 1)
    if block.peak_long_km:
        q.recent.long_run_km = round(keep_km * block.peak_long_km, 1)
    q.recent.consistent_weeks = max(p.recent.consistent_weeks, block.weeks)
    return q


def _with_goal(p: Profile, goal: Goal) -> Profile:
    q = copy.deepcopy(p)
    q.goal = goal
    return q


def plan_season(p: Profile, races: list, today: date, start: date | None = None) -> Season:
    """Chain the A races (in date order) into blocks from `start` (default: next Monday).

    races: SeasonRace list; races on or before today are ignored."""
    season = Season(races=sorted(races, key=lambda r: (r.date, PRIORITIES.index(r.priority))))
    future = [r for r in season.races if r.date > today]
    goals = [r for r in future if r.priority == "A"]
    if not goals:
        if future:
            season.warnings.append("Mark at least one race as A (a goal race) to plan a season around it.")
        season.unplaced = future
        return season
    first_day = start or monday_on_or_after(today)
    cursor, prof, built_on = first_day, p, today
    n_built = 0
    intensity = p.goal.intensity
    for k, race in enumerate(goals):
        dkey = _key(MAX_WEEKS, race.distance_m)
        avail = (race.date - monday_on_or_after(cursor)).days // 7 + 1
        if race.date <= cursor + timedelta(days=13):
            season.warnings.append(f"{race.label} on {race.date:%d %b} is less than 2 weeks after the block "
                                   f"before it ends: run it as a B race, or move it.")
            race_b = copy.copy(race)
            race_b.priority = "B"
            if season.blocks:
                season.blocks[-1].races.append(race_b)
            continue
        # a long gap: general base blocks first (each at most BASE_MAX_WEEKS, ending in a time
        # trial), the race block takes the last MAX_WEEKS
        if avail > MAX_WEEKS[dkey] + BASE_MIN_WEEKS - 1:
            race_start = race.date - timedelta(weeks=MAX_WEEKS[dkey] - 1, days=race.date.weekday())
            total = (race_start - monday_on_or_after(cursor)).days // 7
            n = -(-total // BASE_MAX_WEEKS)
            sizes = [total // n + (1 if j < total % n else 0) for j in range(n)]
            focus = BASE_FOCUS[_key(BASE_FOCUS, race.distance_m)]
            for j, size in enumerate(sizes):
                goal = Goal("general", focus, None, None, size, intensity)
                plan = build_plan(_with_goal(prof, goal), built_on, cursor)
                base = _summarise(Block("base", cursor, plan.weeks[-1].start + timedelta(days=6), focus), plan,
                                  GAIN_DECAY ** n_built)
                n_built += 1
                base.notes.append(f"{base.weeks} weeks to build volume and speed before the {race.label}; it "
                                  f"ends with a {L.dist_name(focus)} time trial that sets the paces")
                season.blocks.append(base)
                prof = _carry(prof, base, base.end, 0.9)
                # no recovery days after a time trial: the next block starts the next Monday
                cursor = built_on = base.end + timedelta(days=1)
            avail = (race.date - cursor).days // 7 + 1
        goal = Goal("race", race.distance_m, race.date, race.target_time_s, 12, intensity)
        plan = build_plan(_with_goal(prof, goal), built_on, cursor)
        blk = _summarise(Block("race", cursor, race.date, race.distance_m, race), plan, GAIN_DECAY ** n_built)
        n_built += 1
        if avail < MIN_WEEKS[_key(MIN_WEEKS, race.distance_m)]:
            blk.notes.append(f"only {avail} weeks for a {L.dist_name(race.distance_m)}: a short block, "
                             f"mostly race-specific work (about {MIN_WEEKS[_key(MIN_WEEKS, race.distance_m)]} "
                             f"weeks is better)")
        if race.target_time_s and blk.predicted_s and race.target_time_s < blk.predicted_s - 1:
            blk.notes.append(f"your target {fmt_time(race.target_time_s)} is faster than the predicted "
                             f"{fmt_time(blk.predicted_s)}: kept as a stretch goal")
        blk.notes += [n for n in plan.notes if "stretch goal" not in n]
        season.blocks.append(blk)
        rec = recovery_days(race.distance_m)
        rec_end = race.date + timedelta(days=rec)
        nxt = goals[k + 1] if k + 1 < len(goals) else None
        if nxt is not None and nxt.date <= rec_end + timedelta(days=14):
            rec_end = race.date + timedelta(days=max(3, (nxt.date - race.date).days // 3))
        season.blocks.append(Block("recovery", race.date + timedelta(days=1), rec_end, race.distance_m, race,
                                   notes=[f"{rec} days of easy running by feel after the {race.label}: "
                                          f"no hard sessions, no time targets"]))
        prof = _carry(prof, blk, race.date)
        cursor = monday_on_or_after(rec_end + timedelta(days=1))
        built_on = cursor
    # B and C races go to the block they fall in; warnings for awkward ones
    for r in future:
        if r.priority == "A":
            continue
        home = next((b for b in season.blocks if b.start <= r.date <= b.end), None)
        if home is None:
            season.unplaced.append(r)
            continue
        if r not in home.races:
            home.races.append(r)
        if home.kind == "race":
            gap = (home.race.date - r.date).days
            if r.priority == "B" and gap < 10:
                season.warnings.append(f"{r.label} ({r.date:%d %b}) is {gap} days before the {home.race.label}: "
                                       f"too close for a hard race - run it easy or drop it.")
            elif r.priority == "B" and r.distance_m > home.distance_m + 1 and gap < 28:
                season.warnings.append(f"{r.label} is longer than the {home.race.label} and {gap} days before "
                                       f"it: it will cost more than it gives.")
        elif home.kind == "recovery" and r.priority == "B":
            season.warnings.append(f"{r.label} ({r.date:%d %b}) falls in the recovery after the "
                                   f"{home.race.label}: run it easy, as a C race.")
    for b in season.blocks:
        b.races.sort(key=lambda r: r.date)
    return season
