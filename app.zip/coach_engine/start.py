"""Start from scratch (spec §10.8): a run/walk programme to 30 minutes of running, then a 5 km
test run whose time gives the first real fitness score.

- Three runs a week on spaced days (Noakes: at least two rest days a week for beginners), all
  easy, judged by feel - there is no result to set paces from yet.
- One level a week (library.RUN_WALK); every 4th week repeats the last level as a lighter
  consolidation week instead of moving on (Noakes: the injury window is weeks 8-12, "don't
  speed up the plan"). Where you start depends on how long you can run without stopping now.
- A2 still applies: a run/walk session logged as too hard (score < 65 or missed) means the next
  week repeats the level instead of moving on (replan.py).
- Cross-training and strength are placed as in the normal plan when asked for.
"""
from __future__ import annotations

from datetime import date, timedelta

from . import library as L
import itertools

from .builder import Context, Layout, _mk, circ, injury_areas
from .fitness import age_on, current_vdot, profile, race_time
from .models import DAYS, Plan, Profile, Week
from .zones import make_zones

CONSOLIDATE_EVERY = 4
TEST_M = 5000.0


def _schedule(first_level: int, adj, n_max: int = 30) -> list:
    """[(kind, level)] per full week until the top level has been done twice, then the test week.
    adj.levels[week]["RW"] (A2 from the logs) resets the level at the start of that week."""
    top = len(L.RUN_WALK) - 1
    out, lvl, since, done_top = [], first_level, 0, 0
    for i in range(1, n_max + 1):
        if "RW" in adj.levels.get(i, {}):
            lvl = max(0, min(adj.levels[i]["RW"], top))
        if adj.kinds.get(i) == "recovery" or (since + 1 == CONSOLIDATE_EVERY and lvl > first_level):
            out.append(("recovery", max(first_level, lvl - 1)))
            since = 0
            continue
        if i in adj.easy_only:                  # back from a break: drop two levels
            lvl = max(0, lvl - 2)
        out.append(("normal", lvl))
        since += 1
        if lvl == top:
            done_top += 1
            if done_top >= 2:
                break
        lvl = min(lvl + 1, top)
    out.append(("test", top))
    return out


def start_layout(p: Profile) -> Layout:
    """Three runs as evenly spread as the free days allow (one is the long-run day), cross-training
    on a non-run day, strength after the two shorter runs; the rest are rest days."""
    av = p.availability
    long = av.long_run_day
    free = [d for d in range(7) if d not in av.unavailable and d != long]
    best = max(itertools.combinations(free, 2),
               key=lambda ab: (min(circ(ab[0], ab[1]), circ(ab[0], long), circ(ab[1], long)),
                               -abs(circ(ab[0], long) - circ(ab[1], long))))
    runs = sorted(best)
    others = [d for d in free if d not in runs]
    n_xt = min(max(av.xt_sessions, 1 if av.cross_training else 0), max(0, len(others) - 2))
    xt = sorted(sorted(others, key=lambda d: -min(circ(d, r) for r in runs + [long]))[:n_xt])
    strength = runs if av.strength else []
    rest = [d for d in range(7) if d not in runs + xt + [long]]
    return Layout(long, [], runs, xt, rest, strength, 3)


def _runs(z, kind: str, lvl: int, is_long: bool) -> list:
    if kind == "recovery":
        return L.run_walk(z, lvl)
    top = len(L.RUN_WALK) - 1
    return L.run_walk(z, lvl, extra_run=5 if (lvl == top and is_long) else 0)


def _week(i, start, kind, lvl, ctx, lay, from_day=0) -> Week:
    z, av = ctx.zones, ctx.p.availability
    wk = Week(i, start, "base", {"test": "taper"}.get(kind, kind), 0.0)
    run_days = sorted([lay.long] + lay.q + lay.easy)
    run_days = [d for d in run_days if d >= from_day]
    n, run, w = L.RUN_WALK[lvl]
    title = (f"Run/walk: {n} x {run:g}' run" if n > 1 else f"Run {run:g}' without stopping")
    if kind == "test":
        test_day = lay.long
        for d in run_days:
            if d == test_day:
                pred = race_time(z.vdot, TEST_M)
                segs = [L.walk(5, "5' brisk walk"), L.seg(z, "E", 5, "5' very easy jog"),
                        L.Segment("TT", pred / 60, TEST_M / 1000,
                                  "5 km at a steady effort you can hold - walk breaks are fine; time it")]
                wk.sessions.append(_mk(d, "tt", "test", "Your first 5 km", segs, hard=True,
                                       note="your time gives your first fitness score and real paces"))
            elif (test_day - d) % 7 >= 2:
                wk.sessions.append(_mk(d, "easy", "runwalk", "Easy 20'", L.run_walk(z, len(L.RUN_WALK) - 3)))
        wk.note = "Graduation week: two easy runs, then your first 5 km."
        wk.rules.append("§10.8: the programme ends with a 5 km at a steady effort")
    else:
        for d in run_days:
            segs = _runs(z, kind, lvl, d == lay.long)
            t = title + (" + 5'" if d == lay.long and lvl == len(L.RUN_WALK) - 1 and kind == "normal" else "")
            wk.sessions.append(_mk(d, "easy", "runwalk", t, segs, level=lvl))
        if kind == "recovery":
            wk.note = "Consolidation week: the same as a recent week, so your legs catch up with your lungs."
            wk.rules.append("§10.8: every 4th week repeats a level (Noakes: don't speed up the plan)")
        else:
            wk.rules.append(f"§10.8: run/walk level {lvl + 1} of {len(L.RUN_WALK)}")
    for d in lay.xt:
        if d >= from_day:
            wk.sessions.append(_mk(d, "xt", "xt", "Cross-training", L.cross_training(z, 30, av.cross_training)))
    for d in lay.strength:
        if d >= from_day:
            wk.sessions.append(_mk(d, "strength", "strength", "Strength + mobility",
                                   L.strength(25, "base", True, injury_areas(ctx.p, ctx.today)),
                                   note=L.strength_note("base", True)))
    for d in range(from_day, 7):
        if not [s for s in wk.sessions if s.day == d and s.kind != "strength"]:
            wk.sessions.append(_mk(d, "rest", "rest", "Rest", []))
    wk.sessions.sort(key=lambda s: (s.day, {"strength": 1}.get(s.kind, 0)))
    wk.target_km = round(wk.km, 1)
    wk.zones = z
    return wk


def build_start_plan(p: Profile, today: date, first_day: date, start: date, off: int, adj) -> Plan:
    age = age_on(p.athlete.birth_date, today)
    fit = current_vdot(p.performances, p.athlete.birth_date, today, easy_pace_s=p.recent.easy_pace_s,
                       status="beginner")
    zones = make_zones(fit.vdot, age, TEST_M, p.physiology.hr_max, p.physiology.lthr, provisional=True)
    ctx = Context(p, today, start, age, zones, True, age >= 40, True, k_recovery=CONSOLIDATE_EVERY,
                  gap_min=2, adj=adj)
    lay = start_layout(p)
    ctx.runs = 3
    first = L.run_walk_level(p.recent.continuous_min)
    sched = _schedule(first, adj)
    weeks = []
    if off:
        weeks.append(_week(1, start - timedelta(days=7), "lead-in", first, ctx, lay, first_day.weekday()))
        weeks[-1].note = f"Starts {DAYS[first_day.weekday()]}: the first level, to get going."
    for i, (kind, lvl) in enumerate(sched, 1):
        weeks.append(_week(i, start + timedelta(weeks=i - 1), kind, lvl, ctx, lay))
        weeks[-1].index = i + off
    n, run, _ = L.RUN_WALK[first]
    notes = [f"start from scratch: run/walk from {n} x {run:g}' to 30 minutes without stopping, "
             f"then your first 5 km in week {len(sched) + off}",
             "after the 5 km, build a regular plan (Setup) - your 5 km time is its first result"]
    if p.goal.distance_m > TEST_M + 1 or p.goal.type == "race":
        notes.append("your goal comes after this: build it from your 5 km result when you finish")
    plan = Plan(p, today, fit.vdot, fit.basis, fit.flags, profile(p.performances, p.athlete.birth_date, today),
                zones, weeks, fit.vdot, race_time(fit.vdot, TEST_M), notes, provisional=True)
    plan.ctx = ctx
    plan.layout = lay
    plan.first_day = first_day
    return plan
