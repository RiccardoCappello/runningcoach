"""Plain-text rendering of a plan (CLI output)."""
from __future__ import annotations

from datetime import timedelta

from .fitness import fmt_pace, fmt_time
from .models import DAYS, Plan, Session
from .zones import RPE, ZONE_NAMES


def target(z, zone: str, primary: str) -> str:
    if zone in ("XT",):
        return f"HR < {z.hr['XT'][1]}"
    if zone in ("STR", "TT"):
        return ""
    if zone == "S":
        return "fast, relaxed"
    pace = z.paces.get(zone)
    hr = z.hr.get(zone)
    rpe = RPE.get(zone)
    p = ""
    if getattr(z, "provisional", False):
        pace = None            # fitness is a guess until the test run: go by feel and HR
    if pace and pace[1]:
        p = f"{fmt_pace(pace[0])}-{fmt_pace(pace[1])}/km"
    elif pace:
        p = f"slower than {fmt_pace(pace[0])}/km"
    h = ""
    if hr:
        lo, hi = hr
        h = f"HR {lo or ''}-{hi}" if hi else f"HR {lo}+"
        if zone in ("E", "rec"):
            h = f"HR < {hi}"
    f = f"feel {rpe[0]}-{rpe[1]}" if rpe else ""
    if primary == "hr" and zone in ("E", "rec"):
        parts = [h, f, f"({p})" if p else ""]
    elif primary == "feel":
        parts = [f, h, f"({p})" if p else ""]
    else:
        parts = [p, h, f]
    return ", ".join(x for x in parts if x)


def session_text(z, s: Session) -> str:
    if s.kind == "rest":
        return "Rest"
    bits = []
    for g in s.segments:
        if g.zone == "walk" or g.zone in ("E", "rec") and ("warm-up" in g.label or "cool-down" in g.label or "jog" in g.label
                                       or "walk" in g.label):
            bits.append(g.label)
        elif g.zone in ("E",):
            bits.append(f"{g.label} [{target(z, 'E', s.primary)}]")
        elif g.zone in ("STR", "XT", "TT"):
            t = target(z, g.zone, s.primary)
            bits.append(g.label + (f" [{t}]" if t else ""))
        else:
            bits.append(f"{g.label} {ZONE_NAMES.get(g.zone, g.zone)} [{target(z, g.zone, s.primary)}]")
    return " | ".join(bits)


def render(plan: Plan, detail: bool = True) -> str:
    z = plan.zones
    out = []
    a = plan.profile
    out.append(f"RunningCoach plan - created {plan.created}, starts {plan.weeks[0].start}")
    out.append(f"Fitness (VDOT) {plan.vdot:.1f} from {plan.fitness_basis}")
    for f in plan.fitness_flags:
        out.append(f"  ! {f}")
    rt = plan.runner_type
    out.append(f"Runner type: {rt[0]} ({rt[1]:+.1f}{', provisional' if rt[2] else ''})")
    g = a.goal
    out.append(f"Goal: {g.type} {g.distance_m/1000:g} km - realistic target {fmt_time(plan.target_time_s)} "
               f"(VDOT {plan.goal_vdot:.1f})")
    for n in plan.notes:
        out.append(f"  * {n}")
    out.append("")
    out.append(f"Heart rate: max {z.hr_max:.0f} ({z.hr_max_source}); threshold {z.lthr:.0f} ({z.lthr_source})")
    out.append("Zones:")
    for zone in ("E", "M", "T", "RP", "I", "R"):
        out.append(f"  {ZONE_NAMES[zone]:<11} {target(z, zone, 'pace')}")
    out.append("")
    out.append(" Wk  start       block    kind      target  plan km  hours  easy  hard days        check")
    for w in plan.weeks:
        hard = ",".join(DAYS[s.day] for s in w.sessions if s.hard) or "-"
        chk = "OK" if not w.warnings else "! " + "; ".join(w.warnings)
        out.append(f" {w.index:>2}  {w.start}  {w.block:<8} {w.kind:<9} {w.target_km:6.1f}  {w.km:7.1f}  "
                   f"{w.run_minutes/60:5.1f}  {w.easy_share():4.0%}  {hard:<15}  {chk}")
    if not detail:
        return "\n".join(out)
    for w in plan.weeks:
        out.append("")
        out.append(f"=== Week {w.index} ({w.start}) - {w.block}{' / ' + w.kind if w.kind != 'normal' else ''}"
                   f" - {w.km:.0f} km {'- ' + w.note if w.note else ''}")
        for s in w.sessions:
            day = w.start + timedelta(days=s.day)
            tag = "*" if s.hard else " "
            out.append(f" {tag}{DAYS[s.day]} {day:%d %b}  {s.title:<28} {session_text(z, s)}"
                       + (f"   ({s.km:.1f} km)" if s.km else ""))
        if w.rules:
            out.append("   why: " + " / ".join(w.rules))
    return "\n".join(out)
