"""Training load and trends (spec §5). Display/monitoring only - never prescribes."""
from __future__ import annotations

import math
import statistics


def session_load(rpe: float, minutes: float) -> float:
    """Foster session-RPE (CR-10 x minutes); works for any sport."""
    return rpe * minutes


def trimp(minutes: float, hr_avg: float, hr_rest: float, hr_max: float, sex: str = "M") -> float:
    """Banister TRIMP."""
    hrr = max(0.0, min(1.0, (hr_avg - hr_rest) / (hr_max - hr_rest)))
    a, b = (0.86, 1.67) if sex.upper() == "F" else (0.64, 1.92)
    return minutes * hrr * a * math.exp(b * hrr)


def ewma(daily: list, tau: float) -> list:
    """Exponentially weighted load, one value per day."""
    k = 1 - math.exp(-1 / tau)
    out, v = [], 0.0
    for x in daily:
        v += k * (x - v)
        out.append(v)
    return out


def fitness_fatigue(daily: list, tau_fit: float = 42, tau_fat: float = 7):
    fit, fat = ewma(daily, tau_fit), ewma(daily, tau_fat)
    return fit, fat, [a - b for a, b in zip(fit, fat)]


def monotony(last7: list) -> float:
    sd = statistics.pstdev(last7)
    return statistics.mean(last7) / sd if sd else float("inf")


# ----------------------------------------------------- plan + logs -> daily load (spec §5)
ZONE_RPE = {"walk": 1.0, "rec": 1.5, "E": 3.0, "XT": 3.0, "M": 4.5, "T": 5.5, "RP": 6.5, "I": 7.5,
            "R": 8.5, "S": 9.5, "TT": 9.0, "STR": 5.0}


def planned_load(session: dict) -> float:
    """Expected session-RPE load: each segment's minutes x the middle of its feel band."""
    return sum(g["minutes"] * ZONE_RPE.get(g["zone"], 3.0) for g in session["segments"])


def done_load(session: dict, log) -> float:
    """Load of a logged session: minutes run x the feel logged (planned values fill gaps)."""
    if log is None or log["completed"] == "no":
        return 0.0
    planned_min = sum(g["minutes"] for g in session["segments"]) or 1.0
    mins = log["minutes"] if log["minutes"] is not None else planned_min * (1.0 if log["completed"] == "yes" else 0.5)
    rpe = log["rpe"] if log["rpe"] is not None else planned_load(session) / planned_min
    return session_load(rpe, mins)


EXTRA_RPE = 4.0      # an extra activity logged without a feel: moderate


def daily_load(data: dict, logs: dict, today, seed_per_day: float = 0.0, extras=()) -> list:
    """One dict per day of the plan: planned and logged load, the load used for the curves
    (logged if logged, else planned for past days you may simply not have logged, planned for
    the future), and the fitness / fatigue / form EWMAs (Banister-style; display only).
    seed_per_day: the steady daily load before the plan (from the recent weekly km), so the
    curves don't start at zero. extras: activities that weren't in the plan (date, minutes,
    rpe), added on top of that day's load."""
    from datetime import date, timedelta
    days = {}
    extra = {}
    for x in extras:
        d = date.fromisoformat(x["date"])
        extra[d] = extra.get(d, 0.0) + session_load(x["rpe"] or EXTRA_RPE, x["minutes"])
    for w in data["weeks"]:
        start = date.fromisoformat(w["start"])
        for s in w["sessions"]:
            if s["kind"] == "rest":
                continue
            d = start + timedelta(days=s["day"])
            e = days.setdefault(d, {"planned": 0.0, "done": 0.0, "logged": 0, "unlogged": 0})
            e["planned"] += planned_load(s)
            lg = logs.get(s["id"])
            if lg is not None:
                e["done"] += done_load(s, lg)
                e["logged"] += 1
            elif d <= today:
                e["unlogged"] += 1
    if not days:
        return []
    first = min(date.fromisoformat(data["start"]), min(days))
    extra = {d: v for d, v in extra.items() if d >= first and d <= today}
    last = max(days)
    out = []
    fit = fat = seed_per_day
    kf, ka = 1 - math.exp(-1 / 42), 1 - math.exp(-1 / 7)
    d = first
    while d <= last:
        e = days.get(d, {"planned": 0.0, "done": 0.0, "logged": 0, "unlogged": 0})
        if d > today:
            used = e["planned"]
        elif e["logged"]:
            used = e["done"] + (e["planned"] * e["unlogged"] / (e["logged"] + e["unlogged"]))
        else:
            used = e["planned"]          # not logged: assume it was done as planned
        x = extra.get(d, 0.0)
        used += x
        fit += kf * (used - fit)
        fat += ka * (used - fat)
        done = e["done"] + x if (e["logged"] or x) else None
        out.append({"date": d.isoformat(), "planned": round(e["planned"]), "done": round(done) if done is not None else None,
                    "used": round(used), "future": d > today, "fitness": round(fit, 1), "fatigue": round(fat, 1),
                    "form": round(fit - fat, 1)})
        d += timedelta(days=1)
    return out


def load_status(series: list, today) -> dict:
    """Soft guidance from the curves on `today` (no hard rule: the ACWR evidence is contested,
    Impellizzeri 2020). ratio = fatigue / fitness (acute:chronic, EWMA)."""
    iso = today.isoformat()
    past = [x for x in series if x["date"] <= iso]
    if not past:
        return {"level": "none", "label": "No data yet", "text": "Your load curve starts with the plan.", "ratio": None}
    cur = past[-1]
    ratio = cur["fatigue"] / cur["fitness"] if cur["fitness"] > 1 else 1.0
    last7 = [x["used"] for x in past[-7:]]
    mono = monotony(last7) if len(last7) == 7 else 0.0
    if ratio > 1.5:
        level, label, text = "red", "Load spike", ("The last week was much more than you are used to. If you feel flat "
                                                   "or sore, take an easy day - the plan will adapt.")
    elif ratio > 1.3:
        level, label, text = "amber", "High load", "More than usual lately: sleep, eat, and keep the easy days easy."
    elif ratio < 0.8:
        level, label, text = "blue", "Fresh", "Less than usual lately: good before a race, detraining if it lasts weeks."
    else:
        level, label, text = "green", "Productive", "Load is building at a pace your body is used to."
    if mono > 2.0 and level in ("green", "blue"):
        text += " Your days have been very alike, though: keep the hard/easy contrast."
    return {"level": level, "label": label, "text": text, "ratio": round(ratio, 2), "monotony": round(mono, 1),
            "fitness": cur["fitness"], "fatigue": cur["fatigue"], "form": cur["form"]}
