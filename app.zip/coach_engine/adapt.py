"""Adaptation rules (spec §6): session score, ladders, readiness, breaks, races.

This is the feedback-loop core; plan re-building on top of it is milestone M2.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from .fitness import detraining_factor
from .models import Session, Week


# ------------------------------------------------------------ A1 / A2 score
def session_score(planned_min: float, done_min: float, rpe: float | None, target_rpe: tuple,
                  in_band: float | None = None, reserve: bool | None = None,
                  self_report: str | None = None) -> float:
    """A1: 40 completion + 25 effort match + 25 intensity match + 10 reserve."""
    completion = max(0.0, min(1.0, done_min / planned_min)) if planned_min else 1.0
    if rpe is None:
        effort = 0.5
    else:
        lo, hi = target_rpe
        miss = 0 if lo <= rpe <= hi else min(abs(rpe - lo), abs(rpe - hi))
        effort = max(0.0, 1 - miss / 3)
    if in_band is None:
        in_band = {"on target": 1.0, "too fast": 0.5, "too slow": 0.5}.get(self_report or "", 0.7)
    return round(40 * completion + 25 * effort + 25 * in_band + 10 * (1 if reserve else 0), 1)


def ladder_step(score: float, reserve: bool | None, completed: bool = True) -> int:
    """A2: +1 progress, 0 repeat, -1 step back."""
    if not completed or score < 65:
        return -1
    if score >= 85 and reserve:
        return 1
    return 0


def flat_day(rpe: float | None, target_rpe: tuple, cut_by_feel: bool) -> bool:
    """A3."""
    return bool(cut_by_feel and rpe is not None and rpe >= target_rpe[1] + 2)


def easy_creep(avg_hr: float | None, easy_ceiling: float, rpe: float | None) -> bool:
    """A4."""
    return (avg_hr is not None and avg_hr > easy_ceiling) or (rpe is not None and rpe >= 5)


# ------------------------------------------------------- A5-A7 readiness
@dataclass
class Readiness:
    sleep: int | None = None          # 1-5
    soreness: int = 0                 # 0-3 (Noakes grades)
    mood: int | None = None           # 1-5
    ill: bool = False
    waking_hr: float | None = None
    hr_baseline: float | None = None  # 7-day median
    hrv: float | None = None
    hrv_low: float | None = None      # lower edge of the baseline band
    waitz_yes: int | None = None      # out of 9

    def flags(self) -> list:
        f = []
        if self.waking_hr is not None and self.hr_baseline is not None and self.waking_hr >= self.hr_baseline + 5:
            f.append("waking HR +5")
        if self.hrv is not None and self.hrv_low is not None and self.hrv < self.hrv_low:
            f.append("HRV below band")
        if self.sleep is not None and self.sleep <= 2:
            f.append("poor sleep")
        if self.soreness >= 1:
            f.append(f"soreness grade {self.soreness}")
        if self.mood is not None and self.mood <= 2:
            f.append("low mood/stress")
        if self.ill:
            f.append("ill")
        return f


def classify(r: Readiness) -> tuple:
    f = r.flags()
    if r.ill or r.soreness >= 2 or len(f) >= 2 or (r.waitz_yes or 0) >= 3:
        return "red", f
    if len(f) == 1:
        return "amber", f
    return "green", f


def apply_readiness(week: Week, day: int, level: str, gap_min: int = 2) -> list:
    """A6/A7 on a built week. Returns the list of changes made."""
    from . import library as L
    changes = []
    today = [s for s in week.sessions if s.day == day and s.kind in ("quality", "tt", "long", "easy")]
    if level == "green" or not today:
        return changes
    s = today[0]
    if level == "amber" and s.hard:
        hard_days = {x.day for x in week.sessions if x.hard and x is not s}
        for x in sorted(week.sessions, key=lambda x: x.day):
            if x.day > day and x.kind == "easy" and all(abs(x.day - h) >= gap_min for h in hard_days):
                s.day, x.day = x.day, s.day
                changes.append(f"A6: amber - {s.title} moved to day {s.day}, easy run today")
                break
        else:
            _downgrade(s)
            changes.append("A6: amber - no slot to swap; today run easy, key session missed")
    elif level == "red":
        if s.kind != "easy" or s.hard:
            _downgrade(s)
        s.note = "A7: red readiness - easy 20-30' or rest"
        changes.append("A7: red - today easy/rest; re-plan the week")
    week.sessions.sort(key=lambda x: x.day)
    return changes


def _downgrade(s: Session):
    from .models import Segment
    s.kind, s.family, s.title, s.hard, s.primary = "easy", "easy", "Easy (downgraded)", False, "hr"
    mins = min(30.0, s.minutes)
    km = sum(g.km for g in s.segments if g.zone in ("E", "rec")) * mins / max(1.0, s.minutes)
    s.segments = [Segment("E", mins, km, f"{mins:.0f}' easy")]


# ------------------------------------------------------ §6.4 breaks
@dataclass
class ReturnPlan:
    vdot_factor: float
    phases: list = field(default_factory=list)    # (days, fraction of pre-break weekly km, adds)


def return_plan(days_off: int, cross_trained: bool = False) -> ReturnPlan:
    """Daniels Tables 9.1 / 9.2."""
    f = detraining_factor(days_off, cross_trained)
    if days_off <= 5:
        return ReturnPlan(f, [(5, 1.0, "")])
    if days_off <= 28:
        h = days_off // 2
        return ReturnPlan(f, [(h, 0.50, "easy only"), (days_off - h, 0.75, "easy + strides")])
    if days_off <= 56:
        t = days_off // 3
        return ReturnPlan(f, [(t, 0.33, "easy only"), (t, 0.50, "easy only"),
                              (days_off - 2 * t, 0.75, "easy + strides")])
    caps = [(0.33, 48, ""), (0.50, 64, ""), (0.70, 97, "strides"), (0.85, 120, "strides + reps"),
            (1.00, 145, "strides + threshold + reps")]
    return ReturnPlan(f, [(21, frac, f"cap {cap} km; {adds}".strip("; ")) for frac, cap, adds in caps])


# ------------------------------------------------------ A15 races
def post_race_easy_days(km_raced: float, soreness: int = 0) -> int:
    d = math.ceil(km_raced / 3)
    if soreness == 1:
        d = max(d, 7)
    elif soreness >= 2:
        d = max(d, 14)
    return d
