"""Plan <-> plain dict (JSON-safe). The stored plan is what the feedback loop edits.

Every session gets a stable id ("w3s2"): readiness swaps and missed-session moves change
the day of a session, but logs stay attached to the id.
"""
from __future__ import annotations

from dataclasses import asdict
from datetime import date

from .models import Plan, Segment, Session, Week
from .zones import Zones


def plan_to_dict(plan: Plan) -> dict:
    g = plan.profile.goal
    return {
        "created": plan.created.isoformat(),
        "start": getattr(plan, "first_day", plan.weeks[0].start).isoformat(),   # may be mid-week (lead-in)
        "vdot": plan.vdot,
        "fitness_basis": plan.fitness_basis,
        "fitness_flags": list(plan.fitness_flags),
        "runner_type": list(plan.runner_type),
        "goal": {"type": g.type, "distance_m": g.distance_m,
                 "race_date": g.race_date.isoformat() if g.race_date else None,
                 "target_time_s": g.target_time_s},
        "goal_vdot": plan.goal_vdot,
        "target_time_s": plan.target_time_s,
        "notes": list(plan.notes),
        "provisional": plan.provisional,
        "gap_min": plan.ctx.gap_min,
        "zones": zones_to_dict(plan.zones),
        "weeks": [week_to_dict(w) for w in plan.weeks],
    }


def zones_to_dict(z: Zones) -> dict:
    return asdict(z)


def week_to_dict(w: Week) -> dict:
    d = {
        "index": w.index, "start": w.start.isoformat(), "block": w.block, "kind": w.kind,
        "target_km": w.target_km, "warnings": list(w.warnings), "rules": list(w.rules), "note": w.note,
        "sessions": [session_to_dict(s, sid) for s, sid in zip(w.sessions, _ids(w))],
    }
    if w.zones is not None:
        d["zones"] = zones_to_dict(w.zones)
    return d


def _ids(w: Week) -> list:
    """Keep existing ids; new sessions get the next free "w<week>s<n>"."""
    taken = {getattr(s, "sid", None) for s in w.sessions}
    out, n = [], 0
    for s in w.sessions:
        sid = getattr(s, "sid", None)
        if sid is None:
            while f"w{w.index}s{n}" in taken:
                n += 1
            sid = f"w{w.index}s{n}"
            taken.add(sid)
        out.append(sid)
    return out


def session_to_dict(s: Session, default_id: str) -> dict:
    return {
        "id": getattr(s, "sid", default_id), "day": s.day, "kind": s.kind, "family": s.family,
        "title": s.title, "hard": s.hard, "primary": s.primary, "level": s.level, "note": s.note,
        "segments": [asdict(g) for g in s.segments],
    }


def zones_from(d: dict) -> Zones:
    d = dict(d)
    for k in ("paces", "hr", "rpe"):
        d[k] = {z: (tuple(v) if isinstance(v, list) else v) for z, v in d[k].items()}
    return Zones(**d)


def session_from(sd: dict) -> Session:
    s = Session(sd["day"], sd["kind"], sd["family"], sd["title"],
                [Segment(**g) for g in sd["segments"]], sd["hard"], sd["primary"], sd["level"], sd["note"])
    s.sid = sd["id"]
    return s


def week_from(d: dict) -> Week:
    w = Week(d["index"], date.fromisoformat(d["start"]), d["block"], d["kind"], d["target_km"],
             [session_from(sd) for sd in d["sessions"]], d["warnings"], d["rules"], d["note"])
    if "zones" in d:
        w.zones = zones_from(d["zones"])
    return w
