"""M2 feedback loop: rebuild the weeks still to come from what actually happened (spec §6).

How it works
- The stored plan (serialize.plan_to_dict) is the source of truth for the past: weeks that
  have started are never rebuilt, except for small in-week moves (A13 missed sessions, races,
  the days after a break).
- Everything that happened (logged sessions, morning checks, breaks, races, accepted fitness
  bumps) is turned into an `Adjust` keyed by week. The builder then replays the whole plan
  from its creation date with those adjustments, and the weeks after today are taken from
  that replay. Replaying (instead of patching) keeps ladder levels, the volume level, the
  long-run growth and the recovery cadence consistent.
- Decisions that depend on *when* they were noticed (a fatigue-triggered recovery week, a
  held volume step, a break's return weeks) are pinned in data["anchors"] once their week
  has started, so re-running the replan later gives the same history.
- Every change is reported once, with its rule ID (data["applied"] remembers what was said).

Pure function: no I/O. The caller (the app) supplies the logs and stores the result.
"""
from __future__ import annotations

import copy
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, timedelta

from . import adapt
from . import library as L
from .builder import Adjust, build_plan
from .fitness import HALF, fmt_time, race_time, vdot
from .models import DAYS, Profile, Session
from .serialize import session_from, week_from, week_to_dict, zones_from, zones_to_dict
from .zones import RPE

LADDERS = {"threshold": "T", "intervals": "I", "reps": "R", "race_pace": "RS", "runwalk": "RW",
           "over_under": "OU"}
FAMILY_NAME = {"threshold": "threshold", "intervals": "intervals", "reps": "repetitions",
               "race_pace": "race-pace", "runwalk": "run/walk", "over_under": "over-under"}
INTENSITY = ["TT", "S", "R", "I", "RP", "T", "M", "E", "rec", "walk", "XT", "STR"]


# ------------------------------------------------------------------ inputs
@dataclass
class Logged:
    session_id: str
    completed: str                    # yes | partial | no
    score: float | None = None        # A1
    step: int | None = None           # A2: +1 / 0 / -1 (quality sessions)
    rpe: float | None = None
    flags: tuple = ()                 # rule ids raised when it was logged: "A3", "A4"
    result_s: float | None = None     # finish time of a time trial or race


@dataclass
class Checked:
    date: date
    level: str                        # green | amber | red


@dataclass
class Break:
    first: date                       # first day without running
    last: date | None                 # last day without running (None = still off)
    cross_trained: bool = False
    reason: str = ""


@dataclass
class Race:
    date: date
    distance_m: float
    name: str = ""


@dataclass
class Change:
    rule: str
    week: int
    text: str


@dataclass
class Result:
    data: dict
    changes: list = field(default_factory=list)     # new since the last replan
    proposals: list = field(default_factory=list)   # [{"id", "rule", "text"}] the runner may accept


# ----------------------------------------------------------------- helpers
def main_zone(segment_zones) -> str:
    zs = set(segment_zones)
    return next((z for z in INTENSITY if z in zs), "E")


def target_rpe(session: dict) -> tuple:
    """Target feel for the A1 effort match. Easy and long runs are judged as easy runs: a few
    strides or hill sprints (feel 9-10 for 20 s) don't make the run a hard one."""
    if session["kind"] in ("easy", "long"):
        return RPE["E"]
    return RPE.get(main_zone(g["zone"] for g in session["segments"]), (2, 4))


def _start(w: dict) -> date:
    return date.fromisoformat(w["start"])


def _ladder_len(family: str, goal_m: float) -> int:
    if family == "race_pace":
        return len(L.RACE_SPECIFIC[L.nearest_key(L.RACE_SPECIFIC, goal_m)])
    if family == "runwalk":
        return len(L.RUN_WALK)
    return len({"threshold": L.THRESHOLD, "intervals": L.INTERVALS, "reps": L.REPS,
                "over_under": L.OVER_UNDER}[family])


# -------------------------------------------------------------------- main
def replan(p: Profile, data: dict, logs: list, checks: list, today: date,
           breaks: list = (), races: list = (), accepted: list = ()) -> Result:
    """p: the profile the plan was built from (parsed with today = the plan's creation date).
    accepted: dates on which the runner accepted an A11 fitness bump."""
    data = copy.deepcopy(data)
    weeks = data["weeks"]
    N = len(weeks)
    created = date.fromisoformat(data["created"])
    goal_m = data["goal"]["distance_m"]
    data.setdefault("base_vdot", data["vdot"])
    anchors = data.setdefault("anchors", {})
    first = next((w["index"] for w in weeks if _start(w) > today), None)
    if first is None:
        return Result(data)                                   # plan finished: nothing to rebuild
    cur = weeks[first - 2] if first >= 2 and _start(weeks[first - 2]) <= today else None
    gap = data.get("gap_min", 2)

    # anchors whose week has not started yet are re-decided now
    for k in [k for k, wk in anchors.items() if k.split(":")[0] in ("A9", "A12", "A13L") and wk >= first]:
        del anchors[k]

    where = {}
    for w in weeks:
        for s in w["sessions"]:
            where[s["id"]] = (w, s, _start(w) + timedelta(days=s["day"]))
    logs = sorted((l for l in logs if l.session_id in where), key=lambda l: where[l.session_id][2])
    by_week = defaultdict(list)
    for l in logs:
        by_week[where[l.session_id][0]["index"]].append(l)
    reds = defaultdict(int)
    for c in checks:
        if c.level == "red":
            for w in weeks:
                if _start(w) <= c.date < _start(w) + timedelta(days=7):
                    reds[w["index"]] += 1

    adj = Adjust()
    notes = {}                    # key -> Change (everything currently in force)
    proposals = []

    def note(key, rule, week, text):
        notes[key] = Change(rule, week, text)

    # ---- S40: a time trial or race result resets the paces from the next week
    for l in logs:
        w, s, d = where[l.session_id]
        if s["kind"] != "tt" or not l.result_s:
            continue
        km = sum(g["km"] for g in s["segments"] if g["zone"] == "TT")
        v = round(vdot(km * 1000, l.result_s), 1)
        wk = w["index"] + 1
        if wk <= N:
            adj.vdot.setdefault(wk, []).append(("set", v))
            note(f"S40:{l.session_id}", "S40", wk,
                 f"{s['title'].replace('RACE: ', '').capitalize()} {fmt_time(l.result_s)}: fitness (VDOT) is now {v:.1f}. "
                 f"Paces and heart-rate zones are updated from week {wk}.")

    # ---- A11: accepted fitness bumps
    for d in accepted:
        key = f"A11:{d}"
        wk = anchors.setdefault(key, max(first, 1))
        if wk <= N:
            adj.vdot.setdefault(wk, []).append(("add", 1.0))
            note(key, "A11", wk, f"Fitness raised by 1 point from week {wk}: the last weeks of key "
                                 f"sessions were all on target with effort to spare.")

    # ---- §6.4 breaks
    for b in breaks:
        key = f"break:{b.first}"
        if b.last is None or b.last >= today:
            proposals.append({"id": key, "rule": "§6.4", "text": "You're on a break. When you are running "
                              "again, set its last day so the plan can bring you back gradually."})
            continue
        days = (b.last - b.first).days + 1
        after = next((w["index"] for w in weeks if _start(w) > b.last), None)
        if after is None:
            continue
        R = anchors.setdefault(key, max(after, first))
        rp = adapt.return_plan(days, b.cross_trained)
        if rp.vdot_factor < 1:
            adj.vdot.setdefault(R, []).append(("mul", rp.vdot_factor))
        ret = []
        if days > 5:
            wk = R
            for pdays, frac, adds in rp.phases:
                for _ in range(max(1, round(pdays / 7))):
                    if wk <= N:
                        adj.easy_only[wk] = (frac, adds)
                        ret.append(f"{frac:.0%}")
                    wk += 1
        txt = f"{days} days without running{' (cross-trained)' if b.cross_trained else ''}"
        if rp.vdot_factor < 1:
            txt += f": fitness x{rp.vdot_factor:.3f} (Daniels)"
        if ret:
            txt += f"; {len(ret)} easy week(s) from week {R} at {', '.join(ret)} of your usual volume, then the plan resumes"
        else:
            txt += "; short enough to carry on as planned"
        if days > 56:
            txt += ". After 8+ weeks off, building a new plan is better than resuming this one"
        note(key, "§6.4", R, txt + ".")

    # ---- A9: weekly review -> recovery week (pinned once its week starts)
    done_weeks = [w["index"] for w in weeks if _start(w) + timedelta(days=6) <= today]
    for wi in done_weeks:
        key = f"A9:w{wi}"
        if key in anchors:                     # history: it happened
            adj.kinds[anchors[key]] = "recovery"
            notes[key] = Change("A9", anchors[key], data.get("applied", {}).get(key, "Recovery week (A9)."))
            continue
        if wi < first - 2:
            continue                           # only the latest reviews can still add a recovery week
        reasons = []
        scores = [l.score for k in (wi - 1, wi) for l in by_week[k] if l.score is not None]
        if len(scores) >= 3 and sum(scores) / len(scores) < 70:
            reasons.append(f"average session score {sum(scores) / len(scores):.0f} over two weeks")
        flats = sum(1 for l in by_week[wi] if "A3" in l.flags)
        if flats >= 2:
            reasons.append(f"{flats} flat days")
        if reds[wi] >= 2:
            reasons.append(f"{reds[wi]} red morning checks")
        if reasons:
            R = max(wi + 1, first)
            answered = any(adj.kinds.get(k) == "recovery" or (k < first and weeks[k - 1]["kind"] == "recovery")
                           for k in range(wi + 1, R + 1))   # a recovery week already follows it
            if R <= N and not answered:
                anchors[key] = R
                adj.kinds[R] = "recovery"
                note(key, "A9", R, f"Signs of fatigue in week {wi} ({'; '.join(reasons)}): "
                                   f"week {R} becomes a recovery week, then the plan resumes.")
    # past holds / long-run holds replay as they happened
    for k, wk in anchors.items():
        if k.startswith("A12:"):
            adj.hold.add(wk)
        elif k.startswith("A13L:"):
            adj.long_hold.add(wk)

    # ---- A12: the volume step after a recovery week must be earned
    prev = weeks[first - 2] if first >= 2 else None
    if prev is not None and (prev["kind"] == "recovery" or f"A12:w{first - 1}" in anchors):
        # the weeks that must earn the step: weeks already held back, then the normal weeks
        # before the recovery week
        j, hold_weeks = first - 1, []
        while j >= 1 and weeks[j - 1]["kind"] == "normal" and f"A12:w{j}" in anchors:
            hold_weeks.append(j)
            j -= 1
        while j >= 1 and weeks[j - 1]["kind"] != "normal":
            j -= 1
        while j >= 1 and weeks[j - 1]["kind"] == "normal":
            hold_weeks.append(j)
            j -= 1
        scores = [l.score for k in hold_weeks for l in by_week[k] if l.score is not None]
        red = sum(reds[k] for k in hold_weeks)
        if (len(scores) >= 3 and sum(scores) / len(scores) < 75) or red:
            why = (f"average score {sum(scores) / len(scores):.0f}" if len(scores) >= 3 and
                   sum(scores) / len(scores) < 75 else f"{red} red day(s)")
            anchors[f"A12:w{first}"] = first
            adj.hold.add(first)
            note(f"A12:w{first}", "A12", first, f"Volume stays where it is in week {first} ({why} in the "
                                                f"weeks before the recovery week): the step up waits a week.")

    # ---- A2: ladders continue from the last logged session of each family
    last = {}
    for l in logs:
        w, s, _ = where[l.session_id]
        if s["family"] == "runwalk" and w["kind"] != "normal":
            continue                 # consolidation weeks repeat an older level on purpose
        if s["family"] in LADDERS and s["level"] is not None and l.step is not None:
            last[s["family"]] = (l, s)
    for fam, (l, s) in last.items():
        step = l.step
        if fam == "runwalk":     # beginners move on unless it went badly (§10.8); a bad one is repeated
            step = 1 if l.step >= 0 else 0
        lvl = max(0, min(s["level"] + step, _ladder_len(fam, goal_m) - 1))
        adj.levels.setdefault(first, {})[LADDERS[fam]] = lvl
        verb = {1: "steps up", 0: "repeats the same level", -1: "steps back a level"}[step]
        if fam == "runwalk" and step == 1:
            continue                 # moving on is the plan anyway: only a repeat is news
        note(f"A2:{fam}:{l.session_id}", "A2", first,
             f"Next {FAMILY_NAME[fam]} session {verb} (last one: score {l.score:.0f}"
             f"{', missed' if l.completed == 'no' else ''}).")

    # ---- A13: missed key sessions in the current week
    cur_wk = week_from(cur) if cur else None
    if cur_wk is not None:
        cur_wk.zones = zones_from(cur.get("zones", data["zones"]))
        today_i = (today - cur_wk.start).days
        for l in logs:
            w, s, d = where[l.session_id]
            if w is not cur or l.completed != "no" or s["kind"] not in ("quality", "long"):
                continue
            key = f"A13:{l.session_id}"
            moved_id = l.session_id + "r"
            if any(getattr(x, "sid", "") == moved_id for x in cur_wk.sessions):
                notes[key] = Change("A13", w["index"], data.get("applied", {}).get(key, "Moved (A13)."))
                continue
            reach = 3 if s["kind"] == "quality" else 2
            others = {x.day for x in cur_wk.sessions if x.hard and getattr(x, "sid", "") != l.session_id}
            slot = None
            for dd in range(s["day"] + 1, min(7, s["day"] + reach + 1)):
                if dd <= today_i:
                    continue
                day_s = [x for x in cur_wk.sessions if x.day == dd]
                if any(x.hard for x in day_s) or not any(x.kind == "easy" for x in day_s):
                    continue
                if s["hard"] and any(abs(dd - h) < gap for h in others):
                    continue
                slot = dd
                break
            what = "long run" if s["kind"] == "long" else s["title"].lower()
            if slot is not None:
                easy = next(x for x in cur_wk.sessions if x.day == slot and x.kind == "easy")
                cur_wk.sessions.remove(easy)
                mv = session_from(dict(s, id=moved_id, day=slot, title=s["title"] + " (moved)",
                                       note=f"A13: moved from {DAYS[s['day']]} (missed)"))
                cur_wk.sessions.append(mv)
                cur_wk.sessions.sort(key=lambda x: (x.day, x.kind == "strength"))
                note(key, "A13", w["index"], f"Missed {what} on {DAYS[s['day']]}: moved to {DAYS[slot]} "
                                             f"in place of that day's easy run.")
            elif s["kind"] == "long":
                anchors[f"A13L:{l.session_id}"] = first
                adj.long_hold.add(first)
                note(key, "A13", first, f"Missed long run on {DAYS[s['day']]}: no room to move it, so next "
                                        f"week's long run doesn't grow.")
            else:
                note(key, "A13", w["index"], f"Missed {what} on {DAYS[s['day']]}: dropped - no room within "
                                             f"3 days without crowding the hard days.")

    # ---- replay the plan with everything above
    bench_mid = next((w["index"] for w in weeks[:-1] for s in w["sessions"]
                      if s["kind"] == "tt" and s["family"] == "tt"), None)
    plan = build_plan(p, created, date.fromisoformat(data["start"]), adj, bench_mid)
    new = plan.weeks[first - 1:]

    # ---- after a break: no hard sessions for the rest of the current week
    if cur_wk is not None:
        for b in breaks:
            if b.last is not None and b.last < today and (b.last - b.first).days + 1 > 5 \
                    and b.last >= cur_wk.start - timedelta(days=1):
                for x in cur_wk.sessions:
                    if x.day > (today - cur_wk.start).days and x.hard:
                        adapt._downgrade(x)
                        x.note = "§6.4: easy running only after the break"

    # ---- A14 / A15: races inside the plan
    live = ([cur_wk] if cur_wk is not None else []) + new
    for r in races:
        if not any(w.start <= r.date < w.start + timedelta(days=7) for w in live):
            continue
        key = f"race:{r.date}"
        txt = _apply_race(live, r, today)
        if txt:
            note(key, "A14", next(w.index for w in live if w.start <= r.date < w.start + timedelta(days=7)), txt)

    # ---- A11: propose a fitness bump
    recent_q = [l for l in logs if where[l.session_id][1]["kind"] == "quality"
                and today - timedelta(days=28) < where[l.session_id][2] <= today]
    last_bump = max((d for d in accepted), default=None)
    if (len(recent_q) >= 3 and (last_bump is None or (today - last_bump).days >= 28)
            and all(l.score is not None and l.score >= 85 and l.rpe is not None
                    and l.rpe <= target_rpe(where[l.session_id][1])[1] for l in recent_q)):
        proposals.append({"id": f"A11:{today}", "rule": "A11",
                          "text": f"Your last {len(recent_q)} key sessions all scored 85+ at or below the target "
                                  f"effort. Raise fitness by 1 point? Paces get about 2-3 s/km faster."})

    # ---- write back
    if cur_wk is not None:
        weeks[first - 2] = week_to_dict(cur_wk)
    data["weeks"] = weeks[:first - 1] + [week_to_dict(w) for w in new]
    z_now = new[0].zones
    data["zones"] = zones_to_dict(z_now)
    data["vdot"] = z_now.vdot
    data["provisional"] = z_now.provisional
    data["goal_vdot"] = plan.goal_vdot
    data["target_time_s"] = plan.target_time_s

    old = data.get("applied", {})
    changes = [c for k, c in notes.items() if old.get(k) != c.text]
    data["applied"] = {k: c.text for k, c in notes.items()}
    return Result(data, changes, proposals)


def _apply_race(live: list, r: Race, today: date) -> str:
    """A14: 2 easy days before (3 for half and longer); A15: ceil(km/3) easy days after."""
    days = {}
    for w in live:
        for s in w.sessions:
            days.setdefault(w.start + timedelta(days=s.day), []).append((w, s))
    rw = next(w for w in live if w.start <= r.date < w.start + timedelta(days=7))
    if r.date <= today:
        return ""
    km = r.distance_m / 1000
    before = 3 if r.distance_m >= HALF - 1 else 2
    after = adapt.post_race_easy_days(km)
    for w, s in days.get(r.date, []):
        w.sessions.remove(s)
    z = rw.zones
    name = r.name or f"{km:g} km race"
    rw.sessions.append(Session(r.date.weekday(), "tt", "race", f"RACE: {name}",
                               L.time_trial(z, r.distance_m, race_time(z.vdot, r.distance_m)), True, "feel",
                               None, f"A14/A15: {before} easy days before, {after} after; log your finish time"))
    rw.sessions.sort(key=lambda x: (x.day, x.kind == "strength"))
    changed = 0
    for k in list(range(-before, 0)) + list(range(1, after + 1)):
        d = r.date + timedelta(days=k)
        if d <= today:
            continue
        for w, x in days.get(d, []):
            if x.hard or (x.kind == "long" and abs(k) <= 2):
                adapt._downgrade(x)
                x.note = "A14: easy before the race" if k < 0 else "A15: easy after the race"
                changed += 1
    return (f"Race added on {DAYS[r.date.weekday()]} {r.date:%d %b} ({name}): {before} easy days before it and "
            f"{after} after; {changed} hard session(s) made easy.")
