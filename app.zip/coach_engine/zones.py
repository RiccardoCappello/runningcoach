"""Zones in three languages: pace, heart rate, feel (spec §2, synthesis S7-S8)."""
from __future__ import annotations

from dataclasses import dataclass, field

from .fitness import MILE, MARATHON, pace_at_fraction, race_pace

# Fractions of VDOT calibrated against Daniels Table 5.2 (prototypes/vdot_check.py)
E_FAST, E_SLOW, T_FRAC, I_FRAC = 0.73, 0.63, 0.88, 0.975

ZONE_NAMES = {
    "rec": "recovery", "E": "easy", "M": "steady", "T": "threshold",
    "RP": "race pace", "I": "interval", "R": "repetition", "S": "sprint",
    "TT": "time trial", "XT": "cross-training", "walk": "walk / rest",
}

# % of threshold HR (80/20 Table 6.1 adapted, spec §2.2)
HR_FRAC = {"rec": (0.0, 0.80), "E": (0.80, 0.89), "M": (0.90, 0.95),
           "T": (0.96, 1.00), "I": (1.01, None)}

RPE = {"rec": (1, 2), "E": (2, 4), "M": (4, 5), "T": (5, 6), "RP": (6, 7),
       "I": (7, 8), "R": (8, 9), "S": (9, 10), "TT": (9, 10), "XT": (2, 4)}


@dataclass
class Zones:
    vdot: float
    race_distance_m: float
    paces: dict            # zone -> (fast, slow) s/km ; None for effort-based
    centre: dict           # zone -> s/km used to convert time <-> distance
    hr_max: float
    hr_max_source: str
    lthr: float
    lthr_source: str
    hr: dict = field(default_factory=dict)   # zone -> (lo, hi) bpm, hi None = open
    rpe: dict = field(default_factory=lambda: dict(RPE))
    provisional: bool = False   # fitness guessed (no result yet): show feel/HR, not paces

    def km(self, zone: str, minutes: float) -> float:
        c = self.centre.get(zone)
        return 0.0 if c is None else minutes * 60.0 / c

    def minutes(self, zone: str, km: float) -> float:
        return km * self.centre[zone] / 60.0


def tanaka_hr_max(age: float) -> float:
    return 208.0 - 0.7 * age


def make_zones(vd: float, age: float, race_distance_m: float = 10000.0,
               hr_max: float | None = None, lthr: float | None = None, provisional: bool = False) -> Zones:
    e_fast = pace_at_fraction(vd, E_FAST)
    e_slow = pace_at_fraction(vd, E_SLOW)
    m = race_pace(vd, MARATHON)
    t = pace_at_fraction(vd, T_FRAC)
    rp = race_pace(vd, race_distance_m)
    i = pace_at_fraction(vd, I_FRAC)
    r = race_pace(vd, MILE)
    paces = {
        "rec": (e_slow + 15, None),
        "E": (e_fast, e_slow),
        "M": (m - 5, m + 5),
        "T": (t - 4, t + 4),
        "RP": (rp - 3, rp + 3),
        "I": (i - 3, i + 3),
        "R": (r - 2, r + 2),
        "S": None,
    }
    centre = {"rec": e_slow + 20, "E": 0.5 * (e_fast + e_slow), "M": m, "T": t,
              "RP": rp, "I": i, "R": r, "S": r * 0.92}

    hm_src = "measured" if hr_max else "estimated (208 - 0.7 x age, +-10 bpm)"
    hr_max = hr_max or tanaka_hr_max(age)
    lt_src = "measured" if lthr else "estimated (0.90 x max HR) - test it"
    lthr = lthr or 0.90 * hr_max
    hr = {z: (round(lo * lthr), round(hi * lthr) if hi else None) for z, (lo, hi) in HR_FRAC.items()}
    hr["rec"] = (None, hr["rec"][1])
    hr["XT"] = (None, hr["E"][1] - 10)   # non-impact: ~10 bpm lower (80/20 Ch 12)
    return Zones(vd, race_distance_m, paces, centre, hr_max, hm_src, lthr, lt_src, hr, provisional=provisional)
