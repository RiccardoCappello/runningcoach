"""Plan builder: blocks, volume curve, week layout, sessions (spec §3-§4).

Rule IDs (Sxx = science_synthesis.md) are attached to weeks so every choice
can be explained to the runner.
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from datetime import date, timedelta

from . import library as L
from . import predict as PR
from .fitness import HALF, MARATHON, age_on, current_vdot, profile, vdot
from .models import DAYS, Plan, Profile, Session, Week
from .validate import validate_week
from .zones import Zones, make_zones

TAPER_FACTORS = {1: [0.55], 2: [0.75, 0.55], 3: [0.85, 0.75, 0.55]}
PEAK_CAP = {5000: 60, 10000: 70, HALF: 80, MARATHON: 100}   # km/week upper band (spec §3.2)
RECOVERY_FACTOR = 0.70
SHARPEN_FACTOR = 0.95


def taper_weeks(distance_m: float) -> int:
    return 1 if distance_m <= 10000 + 1 else (2 if distance_m <= HALF + 1 else 3)


def monday_on_or_after(d: date) -> date:
    return d + timedelta(days=(7 - d.weekday()) % 7)


def round5(x: float) -> float:
    return max(5.0, 5 * round(x / 5))


def floor5(x: float) -> float:
    return max(5.0, 5 * int(x / 5 + 1e-9))


def day_cap_frac(runs: int) -> float:
    """No single run above 25% of the week - relaxed when there are only 3-4 runs (spec §4.2)."""
    return max(0.25, 1.25 / max(runs, 1))


def long_cap_frac(level_km: float, runs: int) -> float:
    """Daniels: long <= 30% (<64 km/wk) or 25%; with only 3-4 runs it may reach the daily cap."""
    return max(0.30 if level_km < 64 else 0.25, day_cap_frac(runs) if runs <= 4 else 0.0)


# Half/marathon: the long run is the key session (Noakes; Magness "not a % of mileage");
# allow (share of week, minutes, km) up to these, still limited by the hold-and-grow rule.
GOAL_LONG = {HALF: (0.35, 120, 24.0), MARATHON: (0.40, 150, 35.0)}


def long_cap_km(level_km: float, runs: int, goal_m: float, easy_pace: float) -> float:
    cap = min(long_cap_frac(level_km, runs) * level_km, 150 * 60 / easy_pace)
    if goal_m >= HALF - 1:
        frac, mins, km = GOAL_LONG[L.nearest_key(GOAL_LONG, goal_m)]
        cap = max(cap, min(frac * level_km, mins * 60 / easy_pace, km))
    return cap


# An all-out half or marathon needs the long runs behind it: at most this many times the
# longest run of the plan (a half after a 17 km long run is usual, after 10 km it is not;
# marathon plans peak around 30-32 km). 5 and 10 km are always fine.
READY_RATIO = {HALF: 1.25, MARATHON: 1.40}
BENCH_DISTANCES = [5000.0, 10000.0, HALF, MARATHON]


def ready_distance(distance_m: float, peak_long_km: float) -> float:
    """The longest standard benchmark distance up to distance_m the long runs have prepared for."""
    ok = [d for d in BENCH_DISTANCES if d <= distance_m + 1
          and (d / 1000 <= READY_RATIO.get(L.nearest_key(READY_RATIO, d), 9e9) * peak_long_km
               if d >= HALF - 1 else True)]
    return max(ok) if ok else distance_m


def peak_weekly(vols, kinds, p: Profile) -> float:
    """The volume the runner races on: the plan's biggest normal week (as the Progress page reads it)."""
    return max([t for (t, _), k in zip(vols, kinds) if k == "normal"] + [p.recent.weekly_km])


# ------------------------------------------------------------- adjustments
@dataclass
class Adjust:
    """Changes the feedback loop (replan.py, spec §6) makes to a plan, keyed by week index.

    build_plan replays the whole plan with these applied, so the state carried from week to
    week (ladder levels, volume level, long-run growth, recovery cadence) stays consistent."""
    kinds: dict = field(default_factory=dict)        # week -> "recovery"                  (A9)
    hold: set = field(default_factory=set)           # weeks whose volume step waits        (A12)
    levels: dict = field(default_factory=dict)       # week -> {ladder: level} before it    (A2)
    vdot: dict = field(default_factory=dict)         # week -> [("set", v) | ("mul", f) | ("add", d)]
    long_hold: set = field(default_factory=set)      # weeks whose long run does not grow   (A13)
    easy_only: dict = field(default_factory=dict)    # week -> (fraction of volume, adds)   (§6.4)


# ------------------------------------------------------------------ context
@dataclass
class Context:
    p: Profile
    today: date
    start: date
    age: float
    zones: Zones
    novice: bool
    masters: bool
    cautious: bool          # injury-prone, masters or novice -> recovery every 3rd week
    k_recovery: int
    gap_min: int            # min day-index distance between hard days (2 = one easy day between)
    runs: int = 5
    adj: Adjust = field(default_factory=Adjust)
    return_weeks: int = 0   # returning runner: easy weeks at the start of the plan (§10.8)
    curve: tuple = (5000.0, 0.0, 0.0, 0.0)   # (basis m, slope, end-of-plan VDOT, peak km): predict.py


@dataclass
class Layout:
    long: int
    q: list
    easy: list
    xt: list
    rest: list
    strength: list
    runs: int
    notes: list = field(default_factory=list)


@dataclass
class State:
    level_km: float
    lvl: dict = field(default_factory=lambda: {"T": 0, "I": 1, "R": 1, "RS": 0, "hills": L.HILL_SPRINTS[0], "finish": 0})
    last_long_km: float = 0.0
    peak_long_km: float = 0.0
    normal_longs: int = 0
    base_normal: int = 0
    build_normal: int = 0
    sharpen_normal: int = 0
    history_km: list = field(default_factory=list)
    notes: list = field(default_factory=list)        # plan notes found while building weeks


# ------------------------------------------------------------ plan skeleton
def n_weeks(p: Profile, start: date, return_weeks: int = 0) -> int:
    if p.goal.type == "race" and p.goal.race_date:
        return (p.goal.race_date - start).days // 7 + 1
    return max(p.goal.weeks, return_weeks + 6)      # a block after the return phase, not instead of it


def return_phase(p: Profile) -> dict:
    """Returning runner (§10.8): Daniels Table 9.2 as easy weeks at the start, keyed by week:
    {week: (fraction of the pre-break weekly km, adds)}."""
    from .adapt import return_plan
    days = round(p.recent.weeks_off * 7)
    if p.recent.status != "returning" or days <= 5:
        return {}
    out, wk = {}, 1
    for pdays, frac, adds in return_plan(days, p.recent.cross_trained).phases:
        for _ in range(max(1, round(pdays / 7))):
            out[wk] = (frac, adds)
            wk += 1
    return out


def allocate_blocks(N: int, ctx: Context) -> list:
    """Spec §3.1 (Daniels Fig 10.2 order: base, sharpen, build, then share the rest)."""
    p = ctx.p
    if N < 4:
        return ["sharpen"] * N
    base = 3
    if ctx.novice:
        base += 3
    if p.recent.weekly_km < 25:
        base += 2
    if p.recent.consistent_weeks >= 6 and not ctx.novice and not ctx.return_weeks:
        base = 2
    floor = 1
    if ctx.return_weeks:                 # Daniels: after a break, phase I first (the return weeks + 2)
        base = max(base, ctx.return_weeks + 2)
        floor = min(ctx.return_weeks + 1, N - 1)
    sharpen = max(3 + (1 if p.goal.distance_m >= MARATHON - 1 else 0), taper_weeks(p.goal.distance_m) + 2)
    build = 3
    while base + build + sharpen > N:
        if build > 1:
            build -= 1
        elif base > floor:
            base -= 1
        elif build > 0 and ctx.return_weeks:
            build -= 1
        else:
            sharpen -= 1
    rem = N - (base + build + sharpen)
    if N <= 16:
        base += (rem + 1) // 2
        build += rem // 2
    else:
        add = [rem * 0.4, rem * 0.4, rem * 0.2]
        ints = [int(a) for a in add]
        for j in sorted(range(3), key=lambda j: add[j] - ints[j], reverse=True)[: rem - sum(ints)]:
            ints[j] += 1
        base += ints[0]
        build += ints[1]
        extra_sharpen = min(ints[2], max(0, 8 - sharpen))
        sharpen += extra_sharpen
        build += ints[2] - extra_sharpen
    return ["base"] * base + ["build"] * build + ["sharpen"] * sharpen


def week_kinds(N: int, ctx: Context) -> list:
    """Recovery every k-th week, counted from the last recovery: a recovery week forced by the
    fatigue rule (A9) or a return-from-break week (§6.4) restarts the count."""
    t = taper_weeks(ctx.p.goal.distance_m) if N >= 4 else 1
    adj = ctx.adj
    kinds, since = [], 0
    for i in range(1, N + 1):
        if i > N - t:
            kinds.append("taper")
        elif i in adj.easy_only:
            kinds.append("return")
            since = 0
        elif adj.kinds.get(i) == "recovery" or since + 1 == ctx.k_recovery:
            kinds.append("recovery")
            since = 0
        else:
            kinds.append("normal")
            since += 1
    return kinds


# ------------------------------------------------------------------ layout
def circ(a: int, b: int) -> int:
    d = abs(a - b) % 7
    return min(d, 7 - d)


def make_layout(ctx: Context) -> Layout:
    """Spec §4.1: hard days spaced, long run fixed, XT and strength placed."""
    av, a = ctx.p.availability, ctx.p.athlete
    long = av.long_run_day
    free = [d for d in range(7) if d not in av.unavailable]
    notes = []
    runs, xt = av.run_days, max(av.xt_sessions, 1 if av.cross_training else 0)
    if (a.injury_prone or ctx.age >= 35) and runs >= 6:
        runs -= 1                            # that session becomes the cross-training one
        notes.append("S24: one run swapped for cross-training (injury history / age 35+)")
    runs = max(3, min(runs, len(free)))
    cands = [d for d in free if d != long]
    nq = 2 if runs >= 4 else 1

    q = []
    if nq == 2:
        best = None
        for q1, q2 in itertools.permutations(cands, 2):
            if (q1 - long) % 7 > (q2 - long) % 7:
                continue                      # q1 = first hard day after the long run
            gaps = [circ(q1, q2), circ(q1, long), circ(q2, long)]
            if min(gaps) < ctx.gap_min:
                continue
            key = (min(gaps), (long - q2) % 7, -((q1 - long) % 7))
            if best is None or key > best[0]:
                best = (key, [q1, q2])
        if best:
            q = best[1]
        else:
            nq = 1
            notes.append("S22: only one key session fits with the required easy days between hard days")
    if nq == 1:
        ok = [d for d in cands if circ(d, long) >= ctx.gap_min]
        if ok:
            q = [max(ok, key=lambda d: (circ(d, long), -((d - long) % 7)))]

    rest_pool = [d for d in free if d != long and d not in q]
    n_easy = max(0, runs - 1 - len(q))

    def easy_pen(d):
        pen = 0
        if d == (long + 1) % 7:
            pen += 2                      # rest the day after the long run
        if d == (long - 1) % 7 and xt:
            pen += 1                      # keep the day before the long run for XT
        return (pen, (d - long) % 7)
    easy = sorted(sorted(rest_pool, key=easy_pen)[:n_easy])
    left = [d for d in rest_pool if d not in easy]
    keep_rest = 1 if runs < 7 else 0
    n_xt = max(0, min(xt, len(left) - keep_rest))
    if n_xt < xt:
        notes.append("not enough free days for all cross-training sessions")
    xt_days = sorted(sorted(left, key=lambda d: (0 if d == (long - 1) % 7 else 1, (long - d) % 7))[:n_xt])
    rest = [d for d in left if d not in xt_days] + [d for d in range(7) if d in av.unavailable]

    strength = []
    if av.strength:
        before_hard = {(d - 1) % 7 for d in q + [long]}
        if q:
            strength.append(q[0])
        pool = [d for d in easy + xt_days + rest if d not in before_hard and d not in strength
                and d not in av.unavailable]
        pool.sort(key=lambda d: -circ(d, q[0] if q else long))
        strength += pool[: 2 - len(strength)]
        strength.sort()
    return Layout(long, q, easy, xt_days, sorted(rest), strength, runs, notes)


# ------------------------------------------------------------- volume curve
def budget_km(ctx: Context, lay: Layout) -> float:
    av = ctx.p.availability
    mins = sum(av.budget(d) for d in lay.easy + lay.q + [lay.long])
    return 0.95 * mins * 60 / ctx.zones.centre["E"]


def peak_km(ctx: Context, lay: Layout) -> float:
    r = ctx.p.recent
    cap = PEAK_CAP[L.nearest_key(PEAK_CAP, ctx.p.goal.distance_m)]
    sustained = r.max_sustained_km or r.weekly_km
    grow = 1.15 if ctx.p.athlete.years_running >= 2 else 1.0
    peak = max(r.weekly_km, min(cap, sustained * grow, budget_km(ctx, lay)))
    own = ctx.p.availability.max_weekly_km
    return min(peak, own) if own else peak


STEP_FRAC = {3: 0.08, 4: 0.10}     # step as a share of the level, by recovery cadence (§3.2, 2026-10-10)
STEP_MIN_KM = 1.5


def next_level(level: float, ctx: Context, lay: Layout) -> float:
    """The volume level after a hold. Daniels' step (+1 mile per weekly run) is ~15-25 % for
    anyone under ~40 km/week, and with a recovery week every 3rd week it comes every 3 weeks
    instead of his 3-4: too steep. So the step is 8 % of the level (10 % with a 4-week cadence),
    at least 1.5 km - also when climbing back to a volume held before (a 15 % "fast return"
    step, 42 -> 48 km, still felt too much in practice, 2026-10-10)."""
    daniels = min(1.5 * lay.runs, 15.0)
    return level + min(daniels, max(STEP_MIN_KM, STEP_FRAC.get(ctx.k_recovery, 0.10) * level))


def volume_targets(blocks, kinds, ctx: Context, lay: Layout) -> list:
    """Spec §3.2 / S16-S17: hold, step after each recovery week, spike guard.
    A12: a step held back (adj.hold) waits for the next normal week."""
    peak = peak_km(ctx, lay)
    level = min(ctx.p.recent.weekly_km, peak)
    out, hist = [], []
    taper_left = kinds.count("taper")
    last_level = level
    pending = False
    for i, (b, k) in enumerate(zip(blocks, kinds)):
        if k == "taper":
            n = kinds.count("taper")
            j = n - taper_left
            km = last_level * TAPER_FACTORS[n][j]
            taper_left -= 1
        elif k == "return":
            km = ctx.adj.easy_only[i + 1][0] * level
        elif k == "recovery":
            km = RECOVERY_FACTOR * level
        else:
            if i > 0 and kinds[i - 1] == "recovery":
                pending = True
            if pending and (i + 1) not in ctx.adj.hold:
                ref = sum(hist[-4:]) / len(hist[-4:])
                level = min(next_level(level, ctx, lay), peak, max(level, 1.29 * ref))
                pending = False
            km = level * (SHARPEN_FACTOR if b == "sharpen" else 1.0)
            if i > 0 and kinds[i - 1] == "return":
                km = min(km, 1.25 * hist[-1])    # out of the return weeks: one more half-step first
            last_level = level
        out.append((round(km, 1), level))
        hist.append(km)
    return out


# ----------------------------------------------------------------- weeks
def _q(ctx, family, st: State, target, maint=None):
    """A quality session sized within the caps (S18). Returns (segments, level, note) or None."""
    z, goal = ctx.zones, ctx.p.goal
    if family == "threshold":
        if maint:
            n, m, j = L.THRESHOLD_MAINT[maint]
            for k in range(n, 0, -1):          # drop reps until it fits the cap
                segs = L.reps_time(z, "T", k, m, j)
                if L.fits(segs, 0.10 * target, "T"):
                    return segs, None, "threshold (maintenance)"
            return None
        lvl, segs = L.pick_level(lambda l: L.threshold(z, l), st.lvl["T"], 0.10 * target, "T")
        if segs:
            st.lvl["T"] = min(lvl + 1, len(L.THRESHOLD) - 1)
            return segs, lvl, "threshold"
        return _shortened(z, "T", L.THRESHOLD[0], 0.10 * target, "threshold (shortened)")
    if family == "intervals":
        cap = min(0.08 * target, 10)
        lvl, segs = L.pick_level(lambda l: L.intervals(z, l), st.lvl["I"], cap, "I")
        if segs:
            st.lvl["I"] = min(lvl + 1, len(L.INTERVALS) - 1)
            return segs, lvl, "intervals"
        return _shortened(z, "I", L.INTERVALS[0], cap, "intervals (shortened)")
    if family == "reps":
        lvl, segs = L.pick_level(lambda l: L.repetitions(z, l), st.lvl["R"], min(0.05 * target, 8), "R")
        if segs:
            st.lvl["R"] = min(lvl + 1, len(L.REPS) - 1)
        return (segs, lvl, "repetitions") if segs else None
    if family == "race_pace":
        key = L.nearest_key(L.RACE_SPECIFIC, goal.distance_m)
        zone = "M" if key == MARATHON else "RP"
        cap = L.RP_CAP[key] * target
        lvl, segs = L.pick_level(lambda l: L.race_specific(z, l, goal.distance_m), st.lvl["RS"], cap, zone)
        if not segs:                           # small week: fewer reps of the first level
            kms = list(L.RACE_SPECIFIC[key][0])
            while len(kms) > 1 and sum(kms) > cap:
                kms.pop()
            if sum(kms) <= cap:
                return L.reps_dist(z, zone, kms, 2 if max(kms) <= 1 else 3), 0, "race pace (shortened)"
        if segs:
            st.lvl["RS"] = min(lvl + 1, len(L.RACE_SPECIFIC[key]) - 1)
        return (segs, lvl, "race pace") if segs else None
    raise ValueError(family)


def _shortened(z, zone, first_level, cap, title):
    """Small week: fewer reps of the first ladder level, down to 2 (else None)."""
    n, m, j = first_level
    for k in range(n - 1, 1, -1):
        segs = L.reps_time(z, zone, k, m, j)
        if L.fits(segs, cap, zone):
            return segs, 0, title
    return None


def _fit_warmup(z, segs, max_km):
    """Small weeks: shorten warm-up/cool-down (15'/10' -> 10'/5') so one session stays within its share."""
    if sum(s.km for s in segs) <= max_km:
        return segs
    out = list(segs)
    for idx, mins in ((0, 10), (len(out) - 1, 5)):
        g = out[idx]
        if g.zone == "E" and g.minutes > mins:
            word = "warm-up" if idx == 0 else "cool-down"
            out[idx] = L.seg(z, "E", mins, f"{mins}' {word}")
    return out


def sharpener_kms(cap_km: float) -> list:
    """Race-week sharpener: up to 3 x 1 km, shorter reps if the taper cap is small."""
    if cap_km >= 3:
        return [1.0] * 3
    if cap_km >= 2:
        return [1.0] * 2
    if cap_km >= 1:
        return [0.5] * int(cap_km / 0.5)
    return [0.2] * max(2, int(cap_km / 0.2))


PRIMARY = {"easy": "hr", "long": "hr", "long_finish": "hr", "threshold": "pace", "intervals": "pace",
           "reps": "pace", "race_pace": "pace", "tt": "feel", "test": "feel", "xt": "hr", "strength": "feel",
           "hills": "feel", "runwalk": "feel"}


def _mk(day, kind, family, title, segs, hard=False, level=None, note=""):
    return Session(day, kind, family, title, segs, hard, PRIMARY.get(family, "hr"), level, note)


def build_week(i, block, kind, target, level_km, ctx: Context, lay: Layout, st: State,
               bench: dict, build_normals: int, final_week: bool) -> Week:
    z, p = ctx.zones, ctx.p
    av = p.availability
    start = ctx.start + timedelta(weeks=i - 1)
    wk = Week(i, start, block, kind, target)
    S = wk.sessions
    rules = wk.rules
    used = set()

    # ---------------- final week with the benchmark / race: taper template (S37, S38)
    if final_week and bench.get(i):
        rd, dist, label = bench[i][:3]
        peak = st.peak_long_km or p.recent.long_run_km or 0.0
        ready = ready_distance(dist, peak) if peak else dist
        tt_note = ""
        if ready < dist and p.goal.type != "race":
            # your own time trial: run the longest one the long runs prepared you for, the goal
            # time is predicted from it
            rules.append(f"S41: final time trial {L.dist_name(dist)} -> {L.dist_name(ready)} "
                         f"(longest run {peak:.0f} km)")
            st.notes.append(f"final time trial over {L.dist_name(ready)}, not the {L.dist_name(dist)}: your "
                            f"longest run is {peak:.0f} km, an all-out {L.dist_name(dist)} would be a big jump; "
                            f"the {L.dist_name(dist)} time is predicted from it")
            tt_note = f"your {L.dist_name(dist)} time is predicted from this"
            dist, label = ready, f"{L.dist_label(ready)} TIME TRIAL"
        elif ready < dist:
            # a race: the date and the distance are fixed - say how to run it
            tt_note = (f"your longest run was {peak:.0f} km: start slower than goal pace and treat the "
                       f"first half as a long run")
            st.notes.append(f"the race is much longer than your longest run ({peak:.0f} km): "
                            f"run it controlled, not all-out")
        basis_m, slope, end_v, peak_km = ctx.curve
        pred = PR.predict(dist, end_v, basis_m, slope, peak_km).time_s
        S.append(_mk(rd, "tt", "tt", label, L.time_trial(z, dist, pred, not z.provisional, short=level_km < 25),
                     hard=True, note=tt_note))
        # easy runs scale down for low-volume runners (30'/20' is most of a 20 km week)
        f = min(1.0, level_km / 40)
        tmpl = {-5: ("easy", max(15, floor5(30 * f)), 6), -4: ("sharp", 0, 0),
                -2: ("easy", max(15, floor5(20 * f)), 4)}
        for off, (what, mins, strides) in tmpl.items():
            d = (rd + off) % 7
            if d in av.unavailable or (rd + off) < 0:
                continue
            if what == "easy":
                S.append(_mk(d, "easy", "easy", "Easy + strides", L.easy(z, mins, strides=strides)))
            else:
                key = L.nearest_key(L.RP_CAP, p.goal.distance_m)
                kms = sharpener_kms(L.RP_CAP[key] * target)
                segs = _fit_warmup(z, L.reps_dist(z, "RP" if dist < MARATHON - 1 else "M", kms, 2),
                                   day_cap_frac(ctx.runs) * level_km)
                S.append(_mk(d, "quality", "race_pace", f"Sharpener: {len(kms)} x {kms[0]*1000:g} m at race pace",
                             segs, hard=True,
                             note="last quality session, 4 days out (Daniels)"))
        for d in range(7):
            if not wk.by_day(d):
                S.append(_mk(d, "rest", "rest", "Rest", []))
        rules += ["S37: taper -45% volume, intensity kept", "S38: 2 easy/rest days before the benchmark"]
        wk.note = f"Taper week. {label} on {DAYS[rd]}."
        _finish(wk, ctx, lay, level_km)
        return wk

    # ---------------- long run (S18 cap measured on the volume level)
    cap_km = long_cap_km(level_km, ctx.runs, p.goal.distance_m, z.centre["E"])
    if kind == "recovery":
        long_km = 0.75 * st.last_long_km
    elif kind == "return":
        long_km = min(cap_km, 0.30 * target)
    elif block == "sharpen" or kind == "taper":
        # sharpen keeps the long run near its peak (marathon: at the peak, Noakes/Magness);
        # taper weeks shorten it with the volume
        keep = 1.0 if p.goal.distance_m >= MARATHON - 1 else SHARPEN_FACTOR
        if kind == "taper":
            keep *= target / max(level_km, 1e-9)
        long_km = min(cap_km, keep * st.peak_long_km)
    else:
        # first long run: what you ran recently, but at least a bit above an average run
        first = max(p.recent.long_run_km or 0.0, 1.2 * p.recent.weekly_km / ctx.runs)
        # +2 km a week at most, ~12 % for shorter long runs (8 -> 9 km, not 8 -> 10);
        # A13: a missed long run -> no growth step
        grow = 0.0 if i in ctx.adj.long_hold else min(2.0, max(1.0, 0.12 * st.last_long_km))
        long_km = min(cap_km, (st.last_long_km + grow) if st.last_long_km else first)
    long_min = floor5(z.minutes("E", long_km))
    long_hard = False
    finish = 0
    if kind == "normal" and block in ("base", "build"):
        st.normal_longs += 1
        if st.normal_longs % 3 == 0 and i >= 3:
            finish = L.LONG_FINISH[st.lvl["finish"]]
            if z.km("M", finish) <= min(0.20 * target, 29):
                st.lvl["finish"] = min(st.lvl["finish"] + 1, len(L.LONG_FINISH) - 1)
                long_hard = True
                rules.append("long run carries steady running (Magness 3-week long-run cycle)")
            else:
                finish = 0
    if finish:   # the steady part covers more ground per minute: size the run in km (S18)
        long_min = floor5(z.minutes("E", max(0.0, long_km - z.km("M", finish)))) + finish
    if (kind == "normal" and block != "sharpen") or kind == "return":
        st.last_long_km = z.km("E", long_min)
        st.peak_long_km = max(st.peak_long_km, st.last_long_km)
    S.append(_mk(lay.long, "long", "long_finish" if finish else "long",
                 "Long run" + (" with fast finish" if finish else ""),
                 L.long_run(z, long_min, finish), hard=long_hard))
    used.add(lay.long)

    # ---------------- key sessions
    q1 = lay.q[0] if lay.q else None
    q2 = lay.q[1] if len(lay.q) > 1 else None
    plan_q = {}          # day -> ("quality", family, maint) | ("easy", strides, hills) | ("tt", ...)
    hills_n = st.lvl["hills"]

    mid = bench.get(i)
    if mid and kind not in ("recovery", "return") and mid[3] == "test":
        # test run (§10.8): no usable result yet -> the first key slot is a test, nothing else hard
        rd = q1 if q1 is not None else q2
        if rd is not None:
            plan_q[rd] = ("tt",) + mid[1:]
            for d in (q1, q2):
                if d is not None and d != rd:
                    plan_q[d] = ("easy", 6, 0)
            rules.append("§10.8: test run - your time replaces the guessed fitness and sets the paces")
    elif kind == "recovery":
        rules.append(f"S17: recovery week ({int(RECOVERY_FACTOR*100)}% volume, one week in {ctx.k_recovery})")
        if mid:
            rd = q2 if q2 is not None else q1
            plan_q[rd] = ("tt",) + mid[1:]
            if q1 is not None and q1 != rd:
                plan_q[q1] = ("easy", 6, 0)
        elif block == "base":
            if q1 is not None:
                plan_q[q1] = ("easy", 6, 0)
            if q2 is not None:
                plan_q[q2] = ("easy", 0, hills_n)
        else:
            if q1 is not None:
                plan_q[q1] = ("quality", "threshold", "recovery")
            if q2 is not None:
                plan_q[q2] = ("easy", 6, 0)
    elif kind == "return":
        frac, adds = ctx.adj.easy_only[i]
        n_str = 6 if "strides" in adds else 0
        for d in (q1, q2):
            if d is not None:
                plan_q[d] = ("easy", n_str, 0)
        rules.append(f"§6.4: back from a break - easy running only, {frac:.0%} of your usual volume"
                     + (", strides allowed" if n_str else ""))
    elif block == "base":
        if st.base_normal == 0:
            if q1 is not None:
                plan_q[q1] = ("easy", 0, hills_n)
            if q2 is not None:
                plan_q[q2] = ("easy", 6, 0)
            rules.append("base: settle in; hill sprints start (Magness)")
        else:
            if q1 is not None:
                plan_q[q1] = ("quality", "threshold", None)
            if q2 is not None:
                plan_q[q2] = ("easy", 6 if long_hard else 0, hills_n)
            rules.append("S12: base - threshold is the one key session")
        st.base_normal += 1
    elif block == "build":
        long_goal = p.goal.distance_m >= 10000 - 1
        second_half = st.build_normal >= build_normals / 2
        fam2 = "intervals" if (second_half and long_goal) else "reps"
        if long_hard:
            if q1 is not None:
                plan_q[q1] = ("quality", fam2, None)
            if q2 is not None:
                plan_q[q2] = ("easy", 6, hills_n)
            rules.append("S19: long run is hard this week -> only one other key session")
        else:
            if q1 is not None:
                plan_q[q1] = ("quality", "threshold", None)
            if q2 is not None:
                plan_q[q2] = ("quality", fam2, None)
        rules.append("S12: build - pyramidal (threshold first, then " + fam2 + ")")
        st.build_normal += 1
    else:   # sharpen (and early taper weeks of long races)
        if q1 is not None:
            plan_q[q1] = ("quality", "race_pace", None)
        if q2 is not None and kind == "taper":
            plan_q[q2] = ("easy", 6, 0)          # early taper week: keep the race-pace session only
            rules.append("S37: taper week - one key session, volume down")
        elif q2 is not None:
            plan_q[q2] = ("quality", "threshold", "sharpen") if st.sharpen_normal % 2 == 0 else ("quality", "intervals", None)
        rules.append("S12: sharpen - race pace + intervals, threshold on maintenance")
        st.sharpen_normal += 1

    for d, what in plan_q.items():
        if what[0] == "quality":
            res = _q(ctx, what[1], st, target, what[2])
            if res:
                segs, lvl, title = res
                segs = _fit_warmup(z, segs, day_cap_frac(ctx.runs) * level_km)
                S.append(_mk(d, "quality", what[1], title.capitalize(), segs, hard=True, level=lvl))
            else:
                S.append(_mk(d, "easy", "easy", "Easy + strides", L.easy(z, 0, strides=6)))
                rules.append(f"S18: weekly volume too small for a {what[1]} session - strides instead")
        elif what[0] == "tt":
            _, dist, label, fam = what
            S.append(_mk(d, "tt", fam, label, L.time_trial(z, dist, PR.predict(dist, z.vdot, *ctx.curve[:2], level_km).time_s,
                                                          not z.provisional),
                         hard=True, note="new fitness score from this; 2 easy days after (1 per 3 km, A15)"))
            if fam == "tt":
                rules.append("S40: mid-block time trial resets the paces")
        else:
            _, strides, hills = what
            S.append(_mk(d, "easy", "hills" if hills else "easy",
                         "Easy" + (" + hill sprints" if hills else "") + (" + strides" if strides else ""),
                         L.easy(z, 0, strides=strides, hills=hills)))
            if hills:
                st.lvl["hills"] = min(st.lvl["hills"] + 1, L.HILL_SPRINTS[1])
        used.add(d)

    # ---------------- cross-training and strength (S24, S25, S34)
    for d in lay.xt:
        S.append(_mk(d, "xt", "xt", "Cross-training", L.cross_training(z, 40 if kind == "recovery" else 45,
                                                                      av.cross_training)))
    for d in lay.strength:
        S.append(_mk(d, "strength", "strength", "Strength", L.strength(30 if kind == "recovery" else 35)))

    # ---------------- easy runs fill the remaining volume
    easy_days = [d for d in lay.easy if d not in used]
    if any(w[0] == "tt" for w in plan_q.values()):
        # after the time trial: 2 easy days (A15) -> drop the run right after it if short of days
        tt_day = [d for d, w in plan_q.items() if w[0] == "tt"][0]
        easy_days = [d for d in easy_days if d != (tt_day + 1) % 7] or easy_days
    no_speed = kind == "return" and "strides" not in ctx.adj.easy_only[i][1]
    if not any("strides" in s.title for s in S) and easy_days and not no_speed:
        # one easy run a week carries strides (Magness: never leave speed behind); placed
        # before sizing so the add-on fits the day's time budget
        d = max(easy_days, key=lambda d: (d - lay.long) % 7)
        S.append(_mk(d, "easy", "easy", "Easy + strides", L.easy(z, 0, strides=6)))
        easy_days.remove(d)
    _fill_easy(wk, ctx, easy_days, target, level_km, plan_q)

    for d in range(7):
        if not [s for s in S if s.day == d and s.kind != "strength"]:
            S.append(_mk(d, "rest", "rest", "Rest", []))
    _finish(wk, ctx, lay, level_km)
    return wk


def _fill_easy(wk: Week, ctx: Context, days: list, target: float, level_km: float, plan_q: dict):
    z, av = ctx.zones, ctx.p.availability
    fixed = sum(s.km for s in wk.sessions)
    # easy days that already hold add-ons (strides/hills) also get easy minutes
    addon_days = [s for s in wk.sessions if s.kind == "easy"]
    n = len(days) + len(addon_days)
    if n == 0:
        return
    rem_km = max(0.0, target - fixed)
    per_min = z.minutes("E", rem_km / n)
    day_cap_min = z.minutes("E", day_cap_frac(ctx.runs) * level_km)
    longs = [s.minutes for s in wk.sessions if s.kind == "long"]
    if longs:
        day_cap_min = min(day_cap_min, longs[0])       # no easy run longer than the long run
    # easy runs >= 30' (S20); 20' in small weeks and in the return weeks after a break
    lo = min(30 if level_km >= 25 and wk.kind != "return" else 20, day_cap_min)
    # a small week (a recovery week with a time trial, the first weeks back after a break) gets
    # fewer runs rather than runs padded up to the minimum - but never fewer than 3
    days = list(days)
    plain = [s for s in addon_days if len(s.segments) == 1]
    runs = len([s for s in wk.sessions if s.kind in ("easy", "long", "quality", "tt")])
    def can_drop():
        k = len(days) + len(addon_days)
        return (wk.kind in ("return", "recovery") and runs + len(days) > 3 and k > 1
                and rem_km < 0.9 * k * z.km("E", lo)                   # can't give every run its minimum
                and rem_km <= (k - 1) * z.km("E", day_cap_min) + z.km("E", 3))   # the others can take the rest
    while can_drop():
        if days:
            days.pop()
        elif plain:
            s = plain.pop()
            wk.sessions.remove(s)
            addon_days.remove(s)
            runs -= 1
        else:
            break
    n = len(days) + len(addon_days)
    if n == 0:
        return
    per_min = z.minutes("E", rem_km / n)
    sized = []   # (session, max easy minutes)
    for s in addon_days:
        room = floor5(min(av.budget(s.day) - s.minutes, day_cap_min - s.minutes))
        m = floor5(min(max(round5(per_min), lo), room))
        s.segments[0] = L.seg(z, "E", m, f"{m:.0f}' easy")
        sized.append((s, room))
    for d in days:
        room = floor5(min(av.budget(d), day_cap_min))
        m = floor5(min(max(round5(per_min), lo), room))
        wk.sessions.append(_mk(d, "easy", "easy", "Easy", L.easy(z, m)))
        sized.append((wk.sessions[-1], room))
    # rounding every run to 5' can leave the week long or short: take off / hand out 5' at a time
    step_km = z.km("E", 5)
    while wk.km - target > 0.6 * step_km:
        cut = [s for s, _ in sized if s.segments[0].minutes - 5 >= lo]
        if not cut:
            break
        s = max(cut, key=lambda x: (x.segments[0].minutes, -x.day))
        m = s.segments[0].minutes - 5
        s.segments[0] = L.seg(z, "E", m, f"{m:.0f}' easy")
    while target - wk.km > 0.6 * step_km:
        open_ = [(s, room) for s, room in sized if s.segments[0].minutes + 5 <= room]
        if not open_:
            break
        s, _ = min(open_, key=lambda x: (x[0].segments[0].minutes, x[0].day))
        m = s.segments[0].minutes + 5
        s.segments[0] = L.seg(z, "E", m, f"{m:.0f}' easy")


def _finish(wk: Week, ctx: Context, lay: Layout, level_km: float):
    wk.sessions.sort(key=lambda s: (s.day, {"strength": 1}.get(s.kind, 0)))
    wk.warnings += validate_week(wk, ctx, level_km)


# ------------------------------------------------------------------- plan
def apply_vdot_ops(vd: float, ops: list) -> float:
    for op, x in ops:
        vd = x if op == "set" else vd * x if op == "mul" else vd + x
    return round(vd, 1)


def build_lead_in(ctx: Context, lay: Layout, monday: date, from_day: int, level_km: float) -> Week:
    """Plan started mid-week: the days up to Sunday are an easy lead-in (no key sessions), sized
    to the share of the week's runs that are left. The plan proper starts the next Monday."""
    z, p = ctx.zones, ctx.p
    left = [d for d in lay.easy + lay.q + [lay.long] if d >= from_day]
    target = round(level_km * len(left) / max(lay.runs, 1), 1)
    wk = Week(1, monday, "base", "lead-in", target)
    S = wk.sessions
    used = set()
    if lay.long >= from_day:
        cap_km = long_cap_km(level_km, ctx.runs, p.goal.distance_m, z.centre["E"])
        first = max(p.recent.long_run_km or 0.0, 1.2 * p.recent.weekly_km / ctx.runs)
        S.append(_mk(lay.long, "long", "long", "Long run", L.long_run(z, floor5(z.minutes("E", min(cap_km, first))))))
        used.add(lay.long)
    q_days = [d for d in lay.q if d >= from_day]
    if q_days:
        S.append(_mk(q_days[0], "easy", "easy", "Easy + strides", L.easy(z, 0, strides=6)))
        used.add(q_days[0])
    for d in lay.xt:
        if d >= from_day:
            S.append(_mk(d, "xt", "xt", "Cross-training", L.cross_training(z, 45, p.availability.cross_training)))
    for d in lay.strength:
        if d >= from_day:
            S.append(_mk(d, "strength", "strength", "Strength", L.strength(35)))
    easy_days = sorted(d for d in left if d not in used)
    _fill_easy(wk, ctx, easy_days, target, level_km, {})
    for d in range(from_day, 7):
        if not [s for s in S if s.day == d and s.kind != "strength"]:
            S.append(_mk(d, "rest", "rest", "Rest", []))
    wk.rules.append(f"lead-in: the plan starts on {DAYS[from_day]}; easy running until Sunday, "
                    f"the first full week starts on Monday")
    wk.note = f"Starts {DAYS[from_day]}. Easy lead-in, no key sessions yet."
    _finish(wk, ctx, lay, level_km)
    return wk


def _shift(adj: Adjust, off: int) -> Adjust:
    """Week indices of the plan -> indices of its full weeks (after a lead-in week).
    Fitness changes aimed at the lead-in carry into the first full week."""
    if not off:
        return adj
    out = Adjust()
    for k, ops in sorted(adj.vdot.items()):
        out.vdot.setdefault(max(1, k - off), []).extend(ops)
    out.kinds = {k - off: v for k, v in adj.kinds.items() if k > off}
    out.hold = {k - off for k in adj.hold if k > off}
    out.levels = {k - off: v for k, v in adj.levels.items() if k > off}
    out.long_hold = {k - off for k in adj.long_hold if k > off}
    out.easy_only = {k - off: v for k, v in adj.easy_only.items() if k > off}
    return out


def build_plan(p: Profile, today: date, start: date | None = None, adj: Adjust | None = None,
               bench_mid: int | None = None) -> Plan:
    """start: the first day of the plan, any weekday. A mid-week start gets a lead-in week up
    to Sunday (week 1); the full weeks follow from Monday.

    adj / bench_mid are used by the re-planner (replan.py) to replay a plan with what has
    happened since it was built; `today` is then the plan's creation date. Their week indices
    are the plan's (lead-in included)."""
    first_day = start or monday_on_or_after(today)
    start = monday_on_or_after(first_day)
    off = 1 if first_day < start else 0
    adj = _shift(adj or Adjust(), off)
    if bench_mid is not None:
        bench_mid -= off
    if p.recent.status == "beginner":
        from .start import build_start_plan
        return build_start_plan(p, today, first_day, start, off, adj)
    age = age_on(p.athlete.birth_date, today)
    r = p.recent
    off_days = r.weeks_off * 7 if r.status == "returning" else 0
    fit = current_vdot(p.performances, p.athlete.birth_date, today, off_days, r.cross_trained,
                       r.easy_pace_s, r.status)
    vd = fit.vdot
    zones = make_zones(vd, age, p.goal.distance_m, p.physiology.hr_max, p.physiology.lthr, fit.provisional)
    novice = p.athlete.years_running < 1
    masters = age >= 40
    returning = return_phase(p)
    cautious = p.athlete.injury_prone or masters or novice or r.weeks_off * 7 > 56   # Daniels: "reruns"
    for wk, v in returning.items():            # the return weeks are part of the plan from the start
        adj.easy_only.setdefault(wk, v)
    ctx = Context(p, today, start, age, zones, novice, masters, cautious,
                  k_recovery=3 if cautious else 4, gap_min=3 if masters else 2, adj=adj,
                  return_weeks=len(returning))
    lay = make_layout(ctx)
    ctx.runs = lay.runs

    N = n_weeks(p, start, len(returning))
    blocks = allocate_blocks(N, ctx)
    kinds = week_kinds(N, ctx)
    vols = volume_targets(blocks, kinds, ctx, lay)

    # benchmarks: mid-block time trial in the recovery week nearest the middle (N >= 10), final at the end
    bench = {}
    race_m = p.goal.distance_m
    if p.goal.type == "race" and p.goal.race_date:
        bench[N] = (p.goal.race_date.weekday(), race_m, f"RACE {L.dist_name(race_m)}", "tt")
    else:
        bench[N] = (lay.long, race_m, f"{L.dist_label(race_m)} TIME TRIAL", "tt")
    # test run (§10.8): no usable result -> week 2, or the first week after the return weeks
    test_wk = None
    if fit.needs_test:
        test_wk = len(returning) + 1 if returning else 2
        if test_wk >= N - 2:
            test_wk = None
        else:
            bench[test_wk] = (None, 5000.0, "5 km TEST RUN", "test")
    rec_weeks = [i + 1 for i, k in enumerate(kinds) if k == "recovery"]
    if N >= 10 and rec_weeks and race_m <= HALF + 1 and vols[0][1] >= 25:
        if bench_mid is not None:     # replay: keep the time trial where it was (or the next recovery week)
            mid = next((w for w in rec_weeks if w >= bench_mid), None)
        else:
            mid = min(rec_weeks, key=lambda w: (abs(w - N / 2), w))
        tt_m = 5000.0 if race_m <= 10000 + 1 else 10000.0
        if mid is not None and mid < N and not (test_wk and abs(mid - test_wk) < 4):
            bench[mid] = (None, tt_m, f"{tt_m/1000:g} km TIME TRIAL", "tt")

    # the end-of-plan target: the same rule as the goal check and the Progress page (predict.py)
    a = p.athlete
    end_day = start + timedelta(weeks=N - 1, days=6)
    changed = [w for w, ops in adj.vdot.items() if ops and w <= N]
    vd_end = vd
    for w in sorted(changed):
        vd_end = apply_vdot_ops(vd_end, adj.vdot[w])
    if changed:   # fitness re-measured mid-plan: only the weeks still to come add to it
        v0, since = vd_end, start + timedelta(weeks=max(changed) - 1)
    else:
        v0, since = vd, today
    _, basis_m, slope, _ = PR.runner_curve(p, today)
    peak = peak_weekly(vols, kinds, p)
    goal_vdot, target_time = PR.end_of_plan(race_m, v0, basis_m, slope, a.years_running, age,
                                            (end_day - since).days / 7, peak)
    ctx.curve = (basis_m, slope, goal_vdot, peak)

    st = State(level_km=vols[0][1])
    build_normals = sum(1 for b, k in zip(blocks, kinds) if b == "build" and k == "normal")
    weeks = []
    if off:
        lead_km = vols[0][0] if kinds[0] == "return" else vols[0][1]
        weeks.append(build_lead_in(ctx, lay, start - timedelta(days=7), first_day.weekday(), lead_km))
        weeks[-1].zones = ctx.zones
    vd_now = vd
    prov = fit.provisional
    for i, ((target, level), b, k) in enumerate(zip(vols, blocks, kinds), 1):
        if adj.vdot.get(i):
            vd_now = apply_vdot_ops(vd_now, adj.vdot[i])
            if any(op == "set" for op, _ in adj.vdot[i]):
                prov = False                   # a measured result replaces the guess
            ctx.zones = make_zones(vd_now, age, p.goal.distance_m, p.physiology.hr_max, p.physiology.lthr, prov)
        if i in adj.levels:
            st.lvl.update(adj.levels[i])
        weeks.append(build_week(i, b, k, target, level, ctx, lay, st, bench, build_normals, i == N))
        weeks[-1].zones = ctx.zones
        weeks[-1].index = i + off
        st.history_km.append(weeks[-1].km)
    ctx.zones = zones

    notes = list(lay.notes) + st.notes
    if returning:
        fr = ", ".join(f"{v[0]:.0%}" for v in returning.values())
        notes.append(f"back after {r.weeks_off:g} weeks off: {len(returning)} easy weeks first ({fr} of the "
                     f"{r.weekly_km:g} km/week you ran before), then the plan builds (Daniels Table 9.2)")
    if test_wk:
        notes.append(f"week {test_wk + off}: a 5 km test run - its time sets your paces from the week after")
    if p.goal.target_time_s:
        user_vdot = vdot(race_m, p.goal.target_time_s)
        if user_vdot > goal_vdot + 0.05:
            notes.append(f"your target needs VDOT {user_vdot:.1f}; realistic this block is {goal_vdot:.1f} "
                         f"-> kept yours as a stretch goal (spec §1.5)")
    plan = Plan(p, today, vd, fit.basis, fit.flags, profile(p.performances, a.birth_date, today), zones,
                weeks, goal_vdot, target_time, notes, provisional=prov)
    plan.ctx = ctx
    plan.layout = lay
    plan.first_day = first_day
    return plan
