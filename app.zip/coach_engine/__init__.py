"""coach_engine - science-based adaptive running plans (pure Python, no I/O in the core).

See ../docs/algorithm_spec.md for the rules this implements.
"""
from .builder import build_plan
from .fitness import Performance, current_vdot, race_time, vdot
from .models import Athlete, Availability, Goal, Physiology, Profile, RecentTraining
from .zones import make_zones

__all__ = ["build_plan", "Performance", "current_vdot", "race_time", "vdot", "Athlete",
           "Availability", "Goal", "Physiology", "Profile", "RecentTraining", "make_zones"]
__version__ = "0.1.0"
