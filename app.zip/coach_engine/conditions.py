"""Running in the heat, and the race-day plan (spec §13).

Heat: the slowdown for the same effort grows with temperature and humidity. The rule used is the
common "temperature + dew point" heuristic of running calculators (Hadley): the sum in °F maps to a
% slowdown (100 -> 0 %, 150 -> 4.5 %, 180 -> 10 %). It is a heuristic, not a fitted model; it agrees
in direction and size with Ely et al. 2007 (marathon times slow with WBGT, more for slower runners).

Race plan: splits from the goal pace with a small negative split, warm-up timing, and fuelling for
the half and the marathon (30-60 g of carbohydrate an hour for races over ~75 minutes, Jeukendrup
2014 / ACSM 2016). The app says when, never what to eat beyond that.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from .fitness import HALF, MARATHON, fmt_time

HUMIDITY = {"dry": 35.0, "normal": 60.0, "humid": 85.0}     # % relative humidity for the 3 choices
# (temperature °F + dew point °F) -> slowdown %
_HADLEY = [(100, 0.0), (110, 0.5), (120, 1.0), (130, 2.0), (140, 3.0), (150, 4.5), (160, 6.0),
           (170, 8.0), (180, 10.0)]


def dew_point(t_c: float, rh: float) -> float:
    """Magnus formula, °C."""
    a, b = 17.62, 243.12
    g = math.log(max(rh, 1.0) / 100.0) + a * t_c / (b + t_c)
    return b * g / (a - g)


def heat_slowdown(t_c: float | None, humidity: str | float = "normal") -> float:
    """Fraction to slow paces by for this temperature (°C) and humidity (dry/normal/humid or %RH)."""
    if t_c is None:
        return 0.0
    rh = HUMIDITY.get(humidity, 60.0) if isinstance(humidity, str) else float(humidity)
    f = (t_c * 9 / 5 + 32) + (dew_point(t_c, rh) * 9 / 5 + 32)
    if f <= _HADLEY[0][0]:
        return 0.0
    if f >= _HADLEY[-1][0]:
        return _HADLEY[-1][1] / 100
    for (x0, y0), (x1, y1) in zip(_HADLEY, _HADLEY[1:]):
        if x0 <= f <= x1:
            return (y0 + (y1 - y0) * (f - x0) / (x1 - x0)) / 100
    return 0.0


def heat_text(frac: float, t_c: float, humidity: str) -> str:
    if frac < 0.003:
        return f"{t_c:g} °C: no change to your paces"
    hum = "" if humidity == "normal" else f", {humidity}"
    return f"{t_c:g} °C{hum}: paces {frac * 100:.1f} % slower for the same effort"


def too_hot(t_c: float | None, humidity: str = "normal") -> bool:
    return heat_slowdown(t_c, humidity) >= 0.08


# ------------------------------------------------------------------ race plan
@dataclass
class RacePlan:
    distance_m: float
    goal_s: float
    pace_s: float                     # s/km on average, heat included
    heat: float = 0.0
    splits: list = field(default_factory=list)      # [(km mark, split s/km, elapsed s)]
    halves: tuple = ()                               # (first half s, second half s)
    warmup: list = field(default_factory=list)      # [(minutes before the start, what)]
    fuel: list = field(default_factory=list)        # [text]
    notes: list = field(default_factory=list)


NEG_SPLIT = {5000.0: 0.004, 10000.0: 0.006, HALF: 0.008, MARATHON: 0.010}   # first half slower by this


def _key(m: float) -> float:
    return min(NEG_SPLIT, key=lambda k: abs(k - m))


def race_plan(distance_m: float, goal_s: float, t_c: float | None = None, humidity: str = "normal") -> RacePlan:
    """Splits for a goal time, slowed for the heat; first half a little slower than the second."""
    heat = heat_slowdown(t_c, humidity)
    total = goal_s * (1 + heat)
    km = distance_m / 1000
    pace = total / km
    neg = NEG_SPLIT[_key(distance_m)]
    p1, p2 = pace * (1 + neg), pace * (1 - neg)
    rp = RacePlan(distance_m, total, pace, heat)
    rp.halves = (p1 * km / 2, p2 * km / 2)
    marks = [float(k) for k in range(1, int(km) + 1)]
    if km - int(km) > 0.01:
        marks.append(km)
    elapsed, prev = 0.0, 0.0
    for m in marks:
        seg = m - prev
        # the first km a touch easier still (the start is crowded and it's easy to go out fast)
        p = p1 if m <= km / 2 else p2
        if m == 1.0 and km >= 10:
            p += 2
        elapsed += p * seg
        rp.splits.append((m, p, elapsed))
        prev = m
    # rounding the extra seconds of km 1 back out of the second half
    drift = elapsed - total
    if abs(drift) > 0.5:
        late = [i for i, (m, _, _) in enumerate(rp.splits) if m > km / 2]
        if late:
            per = drift / sum(rp.splits[i][0] - (rp.splits[i - 1][0] if i else 0) for i in late)
            el = 0.0
            out = []
            for i, (m, p, _) in enumerate(rp.splits):
                if i in late:
                    p -= per
                el += p * (m - (rp.splits[i - 1][0] if i else 0))
                out.append((m, p, el))
            rp.splits = out
    # warm-up: longer for shorter races (Daniels / common practice); walk to the start for long ones
    if distance_m <= 10000 + 1:
        rp.warmup = [(45, "Arrive, toilet, bag drop"), (35, "Easy jog 10-15′"), (20, "A few drills, 4 × 20 s strides"),
                     (10, "Into the start pen, keep moving"), (0, "Start")]
    elif distance_m <= HALF + 1:
        rp.warmup = [(50, "Arrive, toilet, bag drop"), (30, "Easy jog 5-10′"), (20, "2-3 × 20 s strides"),
                     (10, "Into the start pen"), (0, "Start - the first km is part of the warm-up")]
    else:
        rp.warmup = [(60, "Arrive, toilet, bag drop"), (25, "Walk and a couple of minutes of easy jogging at most"),
                     (15, "Into the start pen"), (0, "Start - the first 3 km are the warm-up")]
    # fuel
    if total >= 75 * 60:
        rp.fuel.append("Breakfast 2-3 hours before: mostly carbohydrate, what you've had before long runs")
        every = 35 * 60 if distance_m >= MARATHON - 1 else 40 * 60
        t = every
        times = []
        while t < total - 10 * 60:
            times.append(t)
            t += every
        if times:
            rp.fuel.append("Gel or similar (about 25 g carbohydrate) at " +
                           ", ".join(f"{fmt_time(x)} (≈ km {x / pace:.0f})" for x in times) +
                           ": 30-60 g an hour, practised in long runs first")
        rp.fuel.append("Drink to thirst at the stations; more on a warm day")
    elif total >= 50 * 60:
        rp.fuel.append("No gels needed; a sip of water at a station if it's warm")
    else:
        rp.fuel.append("Nothing needed during the race")
    if distance_m >= MARATHON - 1:
        rp.notes.append("The 2 days before: more carbohydrate than usual (carb-loading), less fibre")
    if heat >= 0.02:
        rp.notes.append(f"Hot: goal time {fmt_time(goal_s)} becomes {fmt_time(total)} for the same effort - start at "
                        f"that pace, not at your cool-weather pace")
    if too_hot(t_c, humidity):
        rp.notes.append("Very hot for racing: run for the experience, by feel, and drink often")
    rp.notes.append("Run the first half by the splits even if it feels easy: the second half is where the time is made")
    return rp
