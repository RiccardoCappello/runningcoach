"""What the watch data says (spec §12): reps against their targets, aerobic efficiency, benchmarks.

Pure functions on plain dicts. An activity here is what the app stores from the watch:
  {"date", "minutes", "km", "avg_hr", "speed" (m/s), "gap" (grade-adjusted m/s or None),
   "feels_like" (°C or None), "decoupling" (% or None), "laps": [interval dicts]}
and a lap / interval: {"type": "WORK" | "RECOVERY", "km", "secs", "speed", "gap", "hr"}.
"""
from __future__ import annotations

import re
import statistics
from dataclasses import dataclass, field
from datetime import date, timedelta

from .zones import Zones

# ------------------------------------------------------------- reps vs targets
REP_ZONES = ("R", "I", "T", "RP", "M", "TT")
TOLERANCE_S = 2.0          # s/km outside the band before a rep counts as fast / slow
ODD_FRAC = 0.12           # a run this far from the median pace at the reference HR is left out of the line
HOT_C = 20.0               # feels-like temperature above which pace is slower for the same effort


def pace(speed_mps: float | None) -> float | None:
    return 1000.0 / speed_mps if speed_mps and speed_mps > 0.3 else None


def work_reps(laps: list, band: tuple, n_planned: int | None = None) -> list:
    """The work reps of a session, each with its verdict against the target pace band
    (fast, slow) s/km. Warm-up / cool-down and jogs are left out: only WORK intervals within
    35 % of the band's centre count (the watch's lap detection also marks a brisk warm-up WORK)."""
    lo, hi = band
    centre = 0.5 * (lo + hi)
    out = []
    for lap in laps:
        p = pace(lap.get("gap") or lap.get("speed"))
        if lap.get("type") != "WORK" or p is None or abs(p - centre) > 0.35 * centre:
            continue
        verdict = "fast" if p < lo - TOLERANCE_S else "slow" if p > hi + TOLERANCE_S else "on"
        out.append({"n": len(out) + 1, "km": lap.get("km"), "secs": lap.get("secs"), "pace": p,
                    "hr": lap.get("hr"), "verdict": verdict})
    if n_planned and len(out) > n_planned:
        # more candidates than planned reps: keep the n closest to the target
        keep = sorted(out, key=lambda r: abs(r["pace"] - centre))[:n_planned]
        out = [r for r in out if r in keep]
        for i, r in enumerate(out, 1):
            r["n"] = i
    return out


def rep_feel(reps: list) -> str | None:
    """The A1 self-report from the reps: on target / too fast / too slow (None: no reps)."""
    if not reps:
        return None
    n = len(reps)
    slow = sum(r["verdict"] == "slow" for r in reps)
    fast = sum(r["verdict"] == "fast" for r in reps)
    if slow > n / 2:
        return "too slow"
    if fast > n / 2:
        return "too fast"
    return "on target"


def rep_summary(reps: list, band: tuple) -> str:
    if not reps:
        return ""
    on = sum(r["verdict"] == "on" for r in reps)
    avg = statistics.mean(r["pace"] for r in reps)
    fade = reps[-1]["pace"] - reps[0]["pace"]
    txt = f"{on} of {len(reps)} reps on target, average {fmt(avg)}/km (target {fmt(band[0])}-{fmt(band[1])})"
    if len(reps) >= 3 and fade > 5:
        txt += f"; the last rep was {fade:.0f} s/km slower than the first"
    return txt


def fmt(s: float) -> str:
    s = round(s)
    return f"{s // 60}:{s % 60:02d}"


# ------------------------------------------------------------ aerobic efficiency
def speed_at_hr(speed: float, hr: float, ref_hr: float, hr_rest: float) -> float | None:
    """Speed scaled to a reference heart rate along the heart-rate reserve. In the aerobic range
    HR rises about linearly with speed (%HRR ~ %VO2 reserve, Swain 1997), so this is a fair way to
    compare easy runs done at slightly different HR. Only the trend for one runner matters."""
    if not speed or not hr or hr <= hr_rest + 20:
        return None
    return speed * (ref_hr - hr_rest) / (hr - hr_rest)


@dataclass
class EffPoint:
    date: date
    pace: float              # s/km at the reference HR
    hot: bool = False
    minutes: float = 0.0
    odd: bool = False        # far from the others (a warm-up saved on its own, a GPS glitch): not in the line


@dataclass
class Efficiency:
    ref_hr: float
    points: list = field(default_factory=list)       # EffPoint, oldest first
    slope_s_per_week: float | None = None            # negative = getting faster
    start_pace: float | None = None                  # fitted line at the first / last point
    end_pace: float | None = None
    weeks: float = 0.0

    @property
    def change(self) -> float | None:
        return None if self.start_pace is None else self.end_pace - self.start_pace


def efficiency(runs: list, ref_hr: float, hr_rest: float, today: date, weeks: int = 16) -> Efficiency:
    """Pace at ref_hr from steady easy runs of the last `weeks` weeks (each: an activity dict
    with "steady": True for easy/long runs). Hot runs are shown but kept out of the trend line."""
    eff = Efficiency(ref_hr)
    since = today - timedelta(weeks=weeks)
    for r in runs:
        if not r.get("steady") or r["date"] < since or (r.get("minutes") or 0) < 20:
            continue
        v = speed_at_hr(r.get("gap") or r.get("speed"), r.get("avg_hr"), ref_hr, hr_rest)
        p = pace(v)
        if p is None or not 150 < p < 900:
            continue
        hot = r.get("feels_like") is not None and r["feels_like"] > HOT_C
        eff.points.append(EffPoint(r["date"], p, hot, r.get("minutes") or 0.0))
    eff.points.sort(key=lambda e: e.date)
    cool = [e.pace for e in eff.points if not e.hot]
    if len(cool) >= 5:
        mid = statistics.median(cool)
        for e in eff.points:
            e.odd = abs(e.pace - mid) > ODD_FRAC * mid
    fit = [e for e in eff.points if not e.hot and not e.odd]
    if len(fit) >= 4 and (fit[-1].date - fit[0].date).days >= 14:
        xs = [(e.date - fit[0].date).days / 7 for e in fit]
        ys = [e.pace for e in fit]
        mx, my = statistics.mean(xs), statistics.mean(ys)
        sxx = sum((x - mx) ** 2 for x in xs)
        b = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx
        eff.slope_s_per_week = b
        eff.start_pace = my + b * (xs[0] - mx)
        eff.end_pace = my + b * (xs[-1] - mx)
        eff.weeks = xs[-1]
    return eff


def vdot_gain_from_efficiency(vdot_now: float, pace_before: float, pace_after: float) -> float:
    """Fitness change implied by a faster easy pace at the same heart rate (spec §19). The same HR is
    about the same share of VO2max (Swain 1997), so VO2max scales with the oxygen cost of the two
    speeds (Daniels' running-cost equation, the one VDOT itself is built on)."""
    from .fitness import vo2
    v0, v1 = 60000.0 / pace_before, 60000.0 / pace_after          # m/min
    return vdot_now * (vo2(v1) / vo2(v0) - 1)


def reference_hr(z: Zones) -> float:
    """The middle of the easy HR zone: the HR the efficiency trend is quoted at."""
    lo, hi = z.hr["E"]
    return round(0.5 * (lo + hi))


# -------------------------------------------------------------------- benchmarks
def benchmark_key(session: dict) -> str | None:
    """Sessions with the same structure are the same benchmark: "Intervals 5 x 3′", "Race pace
    3 x 2 km". Easy and long runs are not benchmarks (the efficiency trend covers them)."""
    if session["kind"] not in ("quality", "tt") or session["family"] in ("race", "test"):
        return None
    if session["kind"] == "tt":
        km = sum(g["km"] for g in session["segments"] if g["zone"] == "TT")
        return f"Time trial {km:g} km"
    work = [g for g in session["segments"] if g["zone"] in REP_ZONES]
    if not work:
        return None
    labels = [g["label"] for g in work if g["label"]]
    shape = labels[0] if labels else f"{len(work)} reps"
    shape = re.sub(r"\s*(at|@).*$", "", shape)
    name = {"threshold": "Threshold", "intervals": "Intervals", "reps": "Repetitions",
            "race_pace": "Race pace"}.get(session["family"], session["title"])
    return f"{name} {shape}".strip()


@dataclass
class BenchRun:
    date: date
    pace: float | None        # average work-rep pace s/km
    hr: float | None          # average work-rep HR
    rpe: float | None
    on: int = 0               # reps on target
    n: int = 0


def benchmark_trend(runs: list) -> dict:
    """runs: BenchRun list for one benchmark, oldest first -> the change from the first to the
    last: pace (s/km, negative = faster), HR (bpm) and a one-line verdict."""
    with_pace = [r for r in runs if r.pace]
    if len(with_pace) < 2:
        return {"n": len(runs), "text": "" if len(runs) < 2 else "the first runs have no watch data"}
    a, b = with_pace[0], with_pace[-1]
    dp = b.pace - a.pace
    dh = (b.hr - a.hr) if a.hr and b.hr else None
    bits = []
    if abs(dp) >= 1:
        bits.append(f"{abs(dp):.0f} s/km {'faster' if dp < 0 else 'slower'}")
    else:
        bits.append("same pace")
    if dh is not None and abs(dh) >= 2:
        bits.append(f"{abs(dh):.0f} bpm {'lower' if dh < 0 else 'higher'} HR")
    elif dh is not None:
        bits.append("same HR")
    if a.rpe and b.rpe and abs(b.rpe - a.rpe) >= 1:
        bits.append(f"feel {a.rpe:g} → {b.rpe:g}")
    better = (dp <= -1 and (dh is None or dh <= 3)) or (abs(dp) < 1 and dh is not None and dh <= -2)
    return {"n": len(runs), "pace_change": dp, "hr_change": dh, "better": better,
            "text": ", ".join(bits) + f" since {a.date:%d %b}"}


def decoupling_note(value: float | None) -> str:
    """Aerobic decoupling (pace:HR drift between the two halves of a steady run, Friel)."""
    if value is None:
        return ""
    if value < 5:
        return "under 5 %: your aerobic base held up for the whole run"
    if value < 10:
        return "5-10 %: some drift in the second half - normal on hot days or near the longest runs"
    return "over 10 %: big drift - too fast early, too hot, or the run is beyond your current base"



def planned_reps(session: dict) -> int | None:
    """How many work reps the session has: "5 x 3′" -> 5, "2 km + 2 km + 1 km" -> 3."""
    for g in session["segments"]:
        if g["zone"] not in REP_ZONES or g["zone"] == "TT":
            continue
        m = re.match(r"\s*(\d+)\s*x", g["label"] or "")
        if m:
            return int(m.group(1))
        if "+" in (g["label"] or ""):
            return g["label"].count("+") + 1
        return 1
    return None


def work_zone(session: dict) -> str | None:
    """The zone the reps are run in (the hardest one in the session)."""
    zs = {g["zone"] for g in session["segments"]}
    return next((z for z in REP_ZONES if z in zs), None)
