"""Plain data: what the engine takes in and what it gives back (spec §0)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date

from .fitness import Performance

DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


@dataclass
class Athlete:
    birth_date: date
    sex: str = "M"
    years_running: float = 2.0
    injury_prone: bool = False
    injuries: list = field(default_factory=list)   # [{"area": "knee", "year": 2025}]
    body_mass_kg: float | None = None


@dataclass
class Availability:
    run_days: int = 5
    long_run_day: int = 6                     # 0 = Mon ... 6 = Sun
    unavailable: set = field(default_factory=set)
    max_minutes: dict = field(default_factory=dict)   # weekday -> minutes
    cross_training: list = field(default_factory=lambda: ["bike"])
    xt_sessions: int = 1
    strength: bool = True
    max_weekly_km: float | None = None        # the runner's own ceiling on weekly volume

    def budget(self, day: int) -> float:
        return self.max_minutes.get(day, 150 if day >= 5 else 90)


@dataclass
class Physiology:
    hr_max: float | None = None
    hr_rest: float | None = None
    lthr: float | None = None


@dataclass
class RecentTraining:
    weekly_km: float                          # returning: the weekly km BEFORE the break
    max_sustained_km: float | None = None     # best 4-week average, last 12 months
    long_run_km: float | None = None
    consistent_weeks: int = 0                 # weeks in a row at about this volume
    status: str = "regular"                   # regular | returning | beginner (spec §10.8)
    weeks_off: float = 0.0                    # returning: weeks without running
    cross_trained: bool = False               # returning: aerobic cross-training during the break
    continuous_min: float | None = None       # beginner: minutes you can run without stopping now
    easy_pace_s: float | None = None          # your usual easy pace (s/km): a first guess at fitness


@dataclass
class Goal:
    type: str = "general"                     # general | race | base (easy + long runs only, §10.14)
    distance_m: float = 10000.0               # race distance or general focus
    race_date: date | None = None
    target_time_s: float | None = None
    weeks: int = 12                           # general cycle length
    intensity: str = "pyramidal"              # pyramidal | polarized: how the hard ~15 % is split (spec §10.12)


@dataclass
class Profile:
    athlete: Athlete
    availability: Availability
    physiology: Physiology
    recent: RecentTraining
    performances: list                        # list[Performance]
    goal: Goal


# ------------------------------------------------------------------ outputs
@dataclass
class Segment:
    zone: str            # rec E M T RP I R S TT XT STR
    minutes: float
    km: float
    label: str = ""      # e.g. "3 x 5'" ; rendered with the zone's targets


@dataclass
class Session:
    day: int
    kind: str            # easy | long | quality | tt | xt | strength | rest
    family: str          # easy, threshold, intervals, reps, race_pace, long, long_finish, tt, xt, strength
    title: str
    segments: list = field(default_factory=list)
    hard: bool = False
    primary: str = "hr"  # hr | pace | feel (spec S8)
    level: int | None = None   # ladder level used
    note: str = ""

    @property
    def km(self) -> float:
        return sum(s.km for s in self.segments)

    @property
    def minutes(self) -> float:
        return sum(s.minutes for s in self.segments)

    def zone_km(self, zone: str) -> float:
        return sum(s.km for s in self.segments if s.zone == zone)


@dataclass
class Week:
    index: int           # 1-based
    start: date
    block: str           # base | build | sharpen
    kind: str            # normal | recovery | taper
    target_km: float
    sessions: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    rules: list = field(default_factory=list)
    note: str = ""
    zones: object = None     # paces/HR in force this week (they change after a time trial, S40)

    @property
    def km(self) -> float:
        return sum(s.km for s in self.sessions)

    @property
    def run_minutes(self) -> float:
        return sum(s.minutes for s in self.sessions if s.kind not in ("xt", "strength", "rest"))

    def easy_share(self) -> float:
        """Share of training time that is easy (rec/E/XT); time trials excluded (S11)."""
        low = total = 0.0
        for s in self.sessions:
            if s.kind in ("strength", "rest"):
                continue
            for g in s.segments:
                if g.zone == "TT":
                    continue
                total += g.minutes
                if g.zone in ("rec", "walk", "E", "XT"):
                    low += g.minutes
        return low / total if total else 1.0

    def by_day(self, day: int) -> list:
        return [s for s in self.sessions if s.day == day]


@dataclass
class Plan:
    profile: Profile
    created: date
    vdot: float
    fitness_basis: str
    fitness_flags: list
    runner_type: tuple
    zones: object
    weeks: list
    goal_vdot: float | None = None
    target_time_s: float | None = None
    notes: list = field(default_factory=list)
    provisional: bool = False     # no result yet: paces are a guess until the test run
