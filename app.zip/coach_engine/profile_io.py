"""Load a runner profile from TOML (stdlib tomllib)."""
from __future__ import annotations

import tomllib
from datetime import date, timedelta

from .fitness import Performance, parse_distance, parse_time
from .models import DAYS, Athlete, Availability, Goal, Physiology, Profile, RecentTraining


def _day(x) -> int:
    return x if isinstance(x, int) else DAYS.index(str(x)[:3].title())


def _date(x, today: date) -> date:
    if isinstance(x, date):
        return x
    s = str(x)
    if len(s) == 7:                      # "2025-09" -> mid-month
        return date.fromisoformat(s + "-15")
    return date.fromisoformat(s)


def load_profile(path: str, today: date | None = None) -> Profile:
    with open(path, "rb") as f:
        return parse_profile(tomllib.load(f), today)


def profile_from_toml(text: str, today: date | None = None) -> Profile:
    return parse_profile(tomllib.loads(text), today)


def parse_profile(d: dict, today: date | None = None) -> Profile:
    today = today or date.today()
    a = d["athlete"]
    if "birth_date" in a:
        birth = _date(a["birth_date"], today)
    else:                                # only an age given: assume mid-year
        birth = today - timedelta(days=round((a["age"] + 0.5) * 365.25))
    athlete = Athlete(birth, a.get("sex", "M"), a.get("years_running", 2), a.get("injury_prone", False),
                      a.get("injuries", []), a.get("body_mass_kg"))
    av = d.get("availability", {})
    avail = Availability(
        run_days=av.get("run_days", 5),
        long_run_day=_day(av.get("long_run_day", "Sun")),
        unavailable={_day(x) for x in av.get("unavailable", [])},
        max_minutes={_day(k): v for k, v in av.get("max_minutes", {}).items()},
        cross_training=av.get("cross_training", ["bike"]),
        xt_sessions=av.get("xt_sessions", 1),
        strength=av.get("strength", True),
        max_weekly_km=av.get("max_weekly_km"),
    )
    ph = d.get("physiology", {})
    phys = Physiology(ph.get("hr_max"), ph.get("hr_rest"), ph.get("lthr"))
    r = d.get("recent", {})
    status = r.get("status", "regular")
    if status not in ("regular", "returning", "beginner"):
        raise ValueError(f"recent.status must be regular, returning or beginner, not {status!r}")
    if "weekly_km" not in r and status != "beginner":
        raise KeyError("recent.weekly_km")
    recent = RecentTraining(r.get("weekly_km", 0.0), r.get("max_sustained_km"), r.get("long_run_km"),
                            r.get("consistent_weeks", 0), status, r.get("weeks_off", 0.0),
                            r.get("cross_trained", False), r.get("continuous_min"),
                            parse_time(r["easy_pace"]) if "easy_pace" in r else None)
    perfs = [Performance(parse_distance(p["distance"]), parse_time(p["time"]), _date(p["date"], today),
                         p.get("kind", "race"), tuple(p.get("conditions", [])))
             for p in d.get("performance", [])]
    g = d.get("goal", {})
    if g.get("intensity", "pyramidal") not in ("pyramidal", "polarized"):
        raise ValueError(f"goal.intensity must be pyramidal or polarized, not {g['intensity']!r}")
    goal = Goal(g.get("type", "general"), parse_distance(g.get("distance", "10k")),
                _date(g["race_date"], today) if "race_date" in g else None,
                parse_time(g["target_time"]) if "target_time" in g else None, g.get("weeks", 12),
                g.get("intensity", "pyramidal"))
    return Profile(athlete, avail, phys, recent, perfs, goal)
