"""Fitness model: VDOT from results, ageing/recency, profile, goal realism.

Spec §1. VDOT equations from Daniels & Gilbert (Oxygen Power, 1979); they
reproduce Daniels' Running Formula Tables 5.1/5.2 (see tests).
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from datetime import date

MILE = 1609.344
HALF = 21097.5
MARATHON = 42195.0

DISTANCES = {
    "1500": 1500.0, "mile": MILE, "3k": 3000.0, "5k": 5000.0, "8k": 8000.0,
    "10k": 10000.0, "15k": 15000.0, "10mi": 10 * MILE, "half": HALF, "hm": HALF,
    "marathon": MARATHON, "m": MARATHON,
}


def parse_distance(d) -> float:
    if isinstance(d, (int, float)):
        return float(d)
    return DISTANCES[str(d).lower().replace(" ", "")]


def parse_time(t) -> float:
    """'19:30' -> 1170 s, '1:34:00' -> 5640 s; numbers are seconds."""
    if isinstance(t, (int, float)):
        return float(t)
    s = 0.0
    for p in str(t).split(":"):
        s = s * 60 + float(p)
    return s


def parse_time_text(text: str) -> float:
    """A time typed on a phone: '19:30', but also '19.30', '19,30', '19 30', "19'30", '1h34m'
    (phone number pads have no ':'). Raises ValueError if it isn't 1-3 numeric parts."""
    t = str(text).strip().lower().rstrip("s\"").strip()
    if ":" not in t:
        t = re.sub(r"\s*(?:h|m|min|[.,;'’\s])\s*", ":", t).strip(":")
    parts = t.split(":")
    if not 1 <= len(parts) <= 3 or not all(p.strip().replace(".", "", 1).isdigit() for p in parts):
        raise ValueError(f"not a time: {text!r}")
    if len(parts) == 1:
        raise ValueError(f"write minutes and seconds: {text!r}")
    return parse_time(":".join(p.strip() for p in parts))


# ---------------------------------------------------------------- equations
def vo2(v_m_per_min: float) -> float:
    return -4.60 + 0.182258 * v_m_per_min + 0.000104 * v_m_per_min ** 2


def pct_max(t_min: float) -> float:
    return (0.8 + 0.1894393 * math.exp(-0.012778 * t_min)
            + 0.2989558 * math.exp(-0.1932605 * t_min))


def vdot(distance_m: float, time_s: float) -> float:
    t = time_s / 60.0
    return vo2(distance_m / t) / pct_max(t)


def speed_at_vo2(target: float) -> float:
    """Inverse of vo2(): speed in m/min."""
    a, b, c = 0.000104, 0.182258, -4.60 - target
    return (-b + math.sqrt(b * b - 4 * a * c)) / (2 * a)


def pace_at_fraction(vd: float, frac: float) -> float:
    """Pace (s/km) whose oxygen cost is frac * VDOT."""
    return 60000.0 / speed_at_vo2(frac * vd)


def race_time(vd: float, distance_m: float) -> float:
    """Predicted race time (s) for a VDOT, by bisection."""
    lo, hi = 30.0, 60.0 * 900
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        if vdot(distance_m, mid) > vd:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def race_pace(vd: float, distance_m: float) -> float:
    return race_time(vd, distance_m) / (distance_m / 1000.0)


# ------------------------------------------------- detraining, weight (Ch. 9)
_T91 = [(5, 1.000, 1.000), (6, .997, .998), (7, .994, .997), (10, .985, .992),
        (14, .973, .986), (21, .952, .976), (28, .931, .965), (35, .910, .955),
        (42, .889, .944), (49, .868, .934), (56, .847, .923), (63, .826, .913),
        (70, .805, .902), (72, .800, .900)]


def detraining_factor(days_off: float, cross_trained: bool = False) -> float:
    """Daniels Table 9.1, linearly interpolated (FVDOT-1 / FVDOT-2)."""
    col = 2 if cross_trained else 1
    if days_off <= _T91[0][0]:
        return 1.0
    if days_off >= _T91[-1][0]:
        return _T91[-1][col]
    for a, b in zip(_T91, _T91[1:]):
        if a[0] <= days_off <= b[0]:
            f = (days_off - a[0]) / (b[0] - a[0])
            return a[col] + f * (b[col] - a[col])
    return 1.0


def weight_adjusted(vd: float, old_kg: float, new_kg: float) -> float:
    """Daniels Fig 9.2: VDOT scales with old/new body mass."""
    return vd * old_kg / new_kg


# ------------------------------------------------------------- age / recency
AGE_PEAK_END = 38          # Daniels Table 5.6: no adjustment 18-38
AGE_POINTS_PER_YEAR = 0.9  # ~0.88-0.9 VDOT/yr from 39, all levels, both sexes


def age_on(birth: date, d: date) -> float:
    return (d - birth).days / 365.25


def age_adjustment(age_then: float, age_now: float) -> float:
    """VDOT points lost to ageing between two ages (>= 0)."""
    return AGE_POINTS_PER_YEAR * max(0.0, age_now - max(AGE_PEAK_END, age_then))


def recency_weight(months: float) -> float:
    for limit, w in ((3, 1.0), (6, 0.8), (12, 0.6), (24, 0.4)):
        if months <= limit:
            return w
    return 0.2


def staleness(months: float) -> float:
    """Fraction lost by a trained-but-not-raced runner (open point, spec §1.2)."""
    return 0.0 if months <= 6 else min(0.05, 0.005 * (months - 6))


KIND_WEIGHT = {"race": 1.0, "time_trial": 0.95, "hard_effort": 0.85}


@dataclass
class Performance:
    distance_m: float
    time_s: float
    date: date
    kind: str = "race"                 # race | time_trial | hard_effort
    conditions: tuple = ()             # e.g. ("heat", "hilly")

    @property
    def vdot(self) -> float:
        return vdot(self.distance_m, self.time_s)


@dataclass
class Candidate:
    perf: Performance
    raw: float
    today: float
    weight: float


@dataclass
class FitnessEstimate:
    vdot: float
    basis: str
    candidates: list = field(default_factory=list)
    flags: list = field(default_factory=list)
    provisional: bool = False     # no result at all: a guess until the test run (spec §10.8)
    needs_test: bool = False      # no recent result: plan a test run early


COOPER_S = 720.0                  # the 12-minute test: distance covered in 12 minutes
FALLBACK_VDOT = {"beginner": 28.0, "returning": 35.0, "regular": 38.0}


def vdot_from_easy_pace(pace_s: float) -> float:
    """The VDOT whose easy-zone centre is this pace (bisection). Most people's 'easy' is a bit
    quick, so this errs high; it is only a first guess before a test run."""
    from .zones import E_FAST, E_SLOW
    lo, hi = 15.0, 85.0
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        centre = 0.5 * (pace_at_fraction(mid, E_FAST) + pace_at_fraction(mid, E_SLOW))
        if centre > pace_s:
            lo = mid
        else:
            hi = mid
    return round(0.5 * (lo + hi), 1)


def candidate(p: Performance, birth: date, today: date, off_days: float = 0,
              cross_trained: bool = False) -> Candidate:
    """off_days: a break that is still going on / just ended (returning runner). The result is then
    brought to today with Daniels' detraining factor (Table 9.1) for the break, plus the usual
    fade for the time it was already old when the break started."""
    months = (today - p.date).days / 30.44
    raw = p.vdot
    adj = age_adjustment(age_on(birth, p.date), age_on(birth, today))
    if off_days > 5:
        before = max(0.0, months - off_days / 30.44)
        v = (raw - adj) * (1 - staleness(before)) * detraining_factor(off_days, cross_trained)
    else:
        v = (raw - adj) * (1 - staleness(months))
    w = (KIND_WEIGHT.get(p.kind, 0.85) * max(0.6, 0.9 ** len(p.conditions))
         * recency_weight(months))
    return Candidate(p, raw, v, w)


def current_vdot(perfs: list, birth: date, today: date, off_days: float = 0, cross_trained: bool = False,
                 easy_pace_s: float | None = None, status: str = "regular") -> FitnessEstimate:
    """Spec §1.3: highest well-supported today-equivalent VDOT.

    No results (beginner, or a runner who never raced): a provisional value from the usual easy
    pace if given, else a cautious default; the plan then schedules a test run (spec §10.8)."""
    if not perfs:
        if easy_pace_s:
            v = vdot_from_easy_pace(easy_pace_s)
            basis = f"your usual easy pace {fmt_pace(easy_pace_s)}/km (a guess)"
        else:
            v = FALLBACK_VDOT.get(status, 38.0)
            basis = "no result yet (a cautious guess)"
        flags = ["no result yet: run by feel and heart rate until the test run sets your paces"]
        return FitnessEstimate(v, basis, [], flags, provisional=True, needs_test=True)
    cands = sorted((candidate(p, birth, today, off_days, cross_trained) for p in perfs),
                   key=lambda c: c.today, reverse=True)
    good = [c for c in cands if c.weight >= 0.5]
    flags = []
    if off_days > 5:
        flags.append(f"results are from before your break: lowered for {off_days / 7:.0f} weeks off "
                     f"(Daniels){'; a test run after the easy return weeks sets the real value' if off_days > 13 else ''}")
    if good:
        best = good[0]
        v = best.today
        # A slower result never pulls the value down: you can run slower than your fitness, not
        # faster (2026-10-10; the old "mean of the top two" turned a 10 km 42:55 plus an easy-ish
        # half on the same day into a 45:13 prediction). A slower result over a longer distance
        # is the speed/endurance profile, used by the race predictions (predict.py).
        slower = [c for c in good if c is not best and (today - c.perf.date).days <= 92
                  and best.today - c.today > 3]
        if slower:
            c = slower[0]
            flags.append(f"your {dist_name(c.perf.distance_m)} {fmt_time(c.perf.time_s)} is much slower than this: "
                         + ("if it was all-out, endurance lags speed - the predictions for longer races allow for it"
                            if c.perf.distance_m > best.perf.distance_m and c.perf.kind != "hard_effort"
                            else "not counted, as it probably wasn't all-out"))
        if best.perf.kind == "hard_effort":
            flags.append("based on a hard effort, not an all-out race: true value probably a bit higher")
        basis = f"{dist_name(best.perf.distance_m)} {fmt_time(best.perf.time_s)} ({best.perf.date})"
    else:
        best = max(cands, key=lambda c: c.weight * c.today)
        v = best.today
        if off_days <= 5:
            flags.append("only old results: a test run early in the plan sets your paces")
        basis = f"old result {dist_name(best.perf.distance_m)} {fmt_time(best.perf.time_s)} ({best.perf.date})"
    if abs(best.perf.time_s - COOPER_S) < 1 and best.perf.distance_m not in (1500.0, MILE, 3000.0, 5000.0):
        basis = f"12-minute test {best.perf.distance_m:.0f} m ({best.perf.date})"
    return FitnessEstimate(round(v, 1), basis, cands, flags, needs_test=not good or off_days > 13)


def profile(perfs: list, birth: date, today: date):
    """Spec §1.4: speed- vs endurance-type from two results (>= 2x distance apart).

    Returns (label, value, provisional)."""
    ad = lambda p: p.vdot - age_adjustment(age_on(birth, p.date), age_on(birth, today))
    # all-out results only (a hard training run is a lower bound, not your level), best per distance
    per_d = {}
    for p in perfs:
        if (today - p.date).days <= 730 and p.kind != "hard_effort":
            if p.distance_m not in per_d or ad(p) > ad(per_d[p.distance_m]):
                per_d[p.distance_m] = p
    pool = list(per_d.values())
    best = None
    for a in pool:
        for b in pool:
            if b.distance_m >= 2 * a.distance_m:
                val = ad(b) - ad(a)
                span = b.distance_m / a.distance_m
                if best is None or span > best[1]:
                    best = (val, span, a, b)
    if best is None:
        return "balanced (unknown)", 0.0, True
    val, _, a, b = best
    provisional = max((today - a.date).days, (today - b.date).days) > 365
    if val <= -2.0:
        label = "speed-type"
    elif val >= 1.0:
        label = "endurance-type"
    else:
        label = "balanced"
    return label, round(val, 1), provisional


def allowed_gain(years_running: float, age: float) -> float:
    """Spec §1.5: realistic VDOT gain per 12-week block."""
    if age >= 50:
        return 1.5
    if years_running < 2:
        return 3.0
    return 2.0


def dist_name(distance_m: float) -> str:
    if abs(distance_m - HALF) < 1:
        return "half marathon"
    if abs(distance_m - MARATHON) < 1:
        return "marathon"
    return f"{distance_m / 1000:g} km"


def fmt_time(s: float) -> str:
    s = int(round(s))
    if s >= 3600:
        return f"{s // 3600}:{s % 3600 // 60:02d}:{s % 60:02d}"
    return f"{s // 60}:{s % 60:02d}"


def fmt_pace(s_per_km: float) -> str:
    s = int(round(s_per_km))
    return f"{s // 60}:{s % 60:02d}"
