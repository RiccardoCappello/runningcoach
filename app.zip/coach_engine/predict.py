"""Race predictions and the goal check (spec §1.7, 2026-10-10).

Predictions
- Daniels' equivalent times assume a "balanced" runner: the same VDOT at every distance. Most
  people are better at one end. With all-out results at two or more distances (last 2 years)
  the runner's own trend is fitted: VDOT change per doubling of distance (least squares on
  log2 distance, weighted by recency). The prediction for a distance is the current VDOT moved
  along that trend from the distance it was measured at. Without that, it is Daniels as is.
- Half and marathon also need the miles: the marathon is slowed for low weekly volume
  (spec §1.5, provisional, after Vickers 2016), the half a third as much.

Goal check
- Fitness: the VDOT the target needs, against where the runner is now at that distance, at
  the realistic gain per week (allowed_gain / 12).
- Endurance: the weekly volume and long run the distance needs, built at the plan's own pace
  (8 % volume step every 3 weeks, the long run ~12 % a week in 2 weeks out of 3), plus the taper.
- Weeks needed = the longer of the two. Against the weeks available: "on track" (needed <=
  available), "ambitious" (<= 1.25x), else "not enough time" - with the earliest realistic date
  and the realistic time for the date that was asked.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import date, timedelta

from .fitness import (HALF, MARATHON, MILE, age_adjustment, age_on, allowed_gain, fmt_pace,
                      fmt_time, race_time, recency_weight, vdot)

DISTANCES = [(1500.0, "1500 m"), (MILE, "Mile"), (3000.0, "3 km"), (5000.0, "5 km"),
             (10000.0, "10 km"), (HALF, "Half marathon"), (MARATHON, "Marathon")]
NAMES = dict(DISTANCES)

# (weekly km, long run km): to race it well / at the very least to finish it in one piece
NEEDS = {5000.0: ((20, 8), (10, 5)), 10000.0: ((30, 12), (18, 8)),
         HALF: ((40, 18), (28, 14)), MARATHON: ((55, 30), (40, 26))}
SLOPE_RANGE = (-2.0, 1.0)      # VDOT per doubling of distance
MAX_SHIFT = 4.0                # never move a prediction more than this from the measured VDOT


def nearest(d: dict, m: float):
    return min(d, key=lambda k: abs(math.log(k / m)))


def personal_slope(perfs: list, birth: date, today: date) -> tuple:
    """(VDOT per doubling, n distances). All-out results only, best per distance, last 2 years."""
    best = {}
    for p in perfs:
        months = (today - p.date).days / 30.44
        if p.kind == "hard_effort" or months > 24:
            continue
        v = p.vdot - age_adjustment(age_on(birth, p.date), age_on(birth, today))
        w = recency_weight(months)
        if p.distance_m not in best or v > best[p.distance_m][0]:
            best[p.distance_m] = (v, w)
    if len(best) < 2 or max(best) / min(best) < 1.9:
        return 0.0, len(best)
    xs = [math.log2(d) for d in best]
    ys = [v for v, _ in best.values()]
    ws = [w for _, w in best.values()]
    W = sum(ws)
    mx = sum(w * x for w, x in zip(ws, xs)) / W
    my = sum(w * y for w, y in zip(ws, ys)) / W
    sxx = sum(w * (x - mx) ** 2 for w, x in zip(ws, xs))
    sxy = sum(w * (x - mx) * (y - my) for w, x, y in zip(ws, xs, ys))
    slope = sxy / sxx if sxx else 0.0
    return max(SLOPE_RANGE[0], min(SLOPE_RANGE[1], slope)), len(best)


def volume_factor(distance_m: float, weekly_km: float) -> float:
    """Time multiplier for long races run on little volume (spec §1.5, provisional)."""
    if distance_m >= MARATHON - 1:
        return 1 + 0.04 * max(0.0, 50 - weekly_km) / 30
    if distance_m >= HALF - 1:
        return 1 + 0.013 * max(0.0, 40 - weekly_km) / 30
    return 1.0


@dataclass
class Prediction:
    distance_m: float
    name: str
    vdot: float
    time_s: float
    pace_s: float
    note: str = ""


def predict(distance_m: float, vd: float, basis_m: float, slope: float, weekly_km: float) -> Prediction:
    shift = max(-MAX_SHIFT, min(MAX_SHIFT, slope * math.log2(distance_m / basis_m)))
    v = vd + shift
    t = race_time(v, distance_m) * volume_factor(distance_m, weekly_km)
    note = ""
    if volume_factor(distance_m, weekly_km) > 1.005:
        note = f"slowed for {weekly_km:.0f} km/week"
    return Prediction(distance_m, NAMES.get(distance_m, f"{distance_m/1000:g} km"), round(v, 1), t,
                      t / (distance_m / 1000), note)


def all_predictions(vd: float, basis_m: float, slope: float, weekly_km: float) -> list:
    return [predict(d, vd, basis_m, slope, weekly_km) for d, _ in DISTANCES]


# ------------------------------------------------------------------ goal check
@dataclass
class GoalCheck:
    distance_m: float
    verdict: str                     # on_track | ambitious | not_enough_time
    headline: str
    weeks_available: float | None
    weeks_needed: int
    weeks_fitness: int
    weeks_endurance: int
    target_s: float | None = None
    predicted_now_s: float = 0.0
    realistic_s: float | None = None        # by the date asked
    earliest: date | None = None            # earliest date for the target
    reasons: list = field(default_factory=list)
    tips: list = field(default_factory=list)


EXPERIENCED_YEARS = 3     # this long running and not cautious -> a recovery week every 5th week


def cadence(cautious: bool, years_running: float = 0.0, ramp: str = "standard") -> tuple:
    """(k, step): a recovery week every k-th week and the volume step after it, as a share of
    the level (spec §3.2, 2026-10-11). Injury history / masters / novice keep 3:1 with smaller
    steps - the risk is how fast load rises, not how rarely it drops; 2:1 gave too little time at
    a level to consolidate. Experienced runners: 4:1.
    ramp (§21): gentle = the cautious steps for everyone; assertive = +15 % every 4th week (3:1, so
    experienced runners step every 4 weeks instead of 5), +10 % for cautious runners (never more for
    them). Every step is still capped by Daniels' +1 mile per weekly run and by the spike guard
    (1.29 x the last 4 weeks, under Nielsen 2014's 30 %), and a new level is held 3 weeks (Daniels)."""
    if ramp == "gentle":
        return 4, 0.06
    if ramp == "assertive":
        return (4, 0.10) if cautious else (4, 0.15)
    if cautious:
        return 4, 0.06
    return (5 if years_running >= EXPERIENCED_YEARS else 4), 0.10


def build_weeks(weekly_km: float, long_km: float, need_week: float, need_long: float,
                cautious: bool = True, cap_km: float | None = None, years_running: float = 0.0,
                ramp: str = "standard") -> int:
    """Weeks to grow volume and long run to the need at the plan's pace (builder.next_level and
    the long-run rule), recovery weeks included. 99 = not reachable (e.g. a weekly cap)."""
    if cap_km and cap_km < need_week:
        return 99
    k, frac = cadence(cautious, years_running, ramp)
    level, lr = max(weekly_km, 0.0), max(long_km, 0.0)
    for wk in range(0, 99):
        if level >= need_week - 0.5 and lr >= need_long - 0.5:
            return wk
        if level < 3:
            return 99                     # not running: the start-from-scratch programme first
        pos = wk % k
        if pos == k - 1:
            continue                      # recovery week
        if pos == 0 and wk:
            level += min(max(1.5, frac * level), 15.0)
        # the long run may be 40 % of the week, or up to the need once the week is big enough
        cap = max(0.40 * level, need_long * min(1.0, level / need_week))
        lr = max(lr, min(lr + min(2.0, max(1.0, 0.12 * lr)), cap))
    return 99


def taper_weeks(distance_m: float) -> int:
    return 1 if distance_m <= 10000 + 1 else (2 if distance_m <= HALF + 1 else 3)


def plan_gain(years_running: float, age: float, weeks: float, distance_m: float) -> float:
    """VDOT a runner can realistically add in `weeks` of training before a race at distance_m:
    allowed_gain per 12 weeks, the taper adds nothing. The one rule for the plan's target, the
    goal check and the Progress page."""
    return allowed_gain(years_running, age) / 12 * max(0.0, weeks - taper_weeks(distance_m))


def end_of_plan(distance_m: float, vd: float, basis_m: float, slope: float, years_running: float,
                age: float, weeks: float, race_weekly_km: float) -> tuple:
    """(VDOT, time) at the end of a plan: today's VDOT plus the gain, on the runner's own curve,
    at the plan's peak volume."""
    v = vd + plan_gain(years_running, age, weeks, distance_m)
    return v, predict(distance_m, v, basis_m, slope, race_weekly_km).time_s


def goal_check(distance_m: float, today: date, vd: float, basis_m: float, slope: float,
               weekly_km: float, long_km: float, years_running: float, age: float,
               target_s: float | None = None, race_date: date | None = None,
               weeks: float | None = None, cautious: bool = True, cap_km: float | None = None,
               race_weekly_km: float | None = None, end_vdot: float | None = None,
               ramp: str = "standard") -> GoalCheck:
    """Is this goal right for this runner? weeks: plan length when there is no race date.
    race_weekly_km / end_vdot: a plan's own peak volume and end-of-plan VDOT (end_of_plan, worked
    out when it was built), so the check says what the plan says; else both are modelled from now."""
    name = NAMES.get(distance_m, f"{distance_m/1000:g} km").lower()
    if race_date is not None:
        weeks = (race_date - today).days / 7
    now = predict(distance_m, vd, basis_m, slope, weekly_km)
    gain_wk = allowed_gain(years_running, age) / 12
    # what the target needs, measured on the runner's own curve at that distance
    reasons, tips = [], []
    weeks_fit = 0
    if target_s:
        need_v = vdot(distance_m, target_s / volume_factor(distance_m, max(weekly_km, 1)))
        gap = need_v - now.vdot
        weeks_fit = 0 if gap <= 0 else math.ceil(gap / gain_wk)
        if gap > 0:
            reasons.append(f"{fmt_time(target_s)} needs about {gap:.1f} fitness points more than your "
                           f"{fmt_time(now.time_s)} now: about {weeks_fit} weeks of good training")
        else:
            reasons.append(f"you could run about {fmt_time(now.time_s)} now: {fmt_time(target_s)} is within reach")
        if weeks_fit > 36:
            tips.append("that is more than two training blocks away: aim for a stepping-stone time first")
    race_well, finish = NEEDS[nearest(NEEDS, distance_m)]
    need_w, need_l = race_well if target_s else finish
    weeks_end = build_weeks(weekly_km, long_km, need_w, need_l, cautious, cap_km, years_running, ramp)
    if weeks_end:
        if weeks_end >= 99:
            reasons.append(f"a {name} needs about {need_w} km a week" +
                           (" - above your weekly cap" if cap_km and cap_km < need_w else
                            " and you are not running yet: start with the run/walk programme"))
        else:
            reasons.append(f"a {name} needs about {need_w} km a week and a {need_l} km long run "
                           f"(you: {weekly_km:.0f} km, {long_km:.0f} km): about {weeks_end} weeks to build up safely")
    taper = taper_weeks(distance_m)
    needed = max(weeks_fit, weeks_end + taper if weeks_end else 0)
    gc = GoalCheck(distance_m, "on_track", "", weeks, needed, weeks_fit, weeks_end, target_s, now.time_s)
    gc.reasons, gc.tips = reasons, tips
    if weeks is not None:
        if race_weekly_km is None:
            usable = max(0.0, weeks - taper)
            race_weekly_km = max(weekly_km, min(need_w, cap_km or need_w, weekly_km * 1.026 ** usable))
        if end_vdot is not None:
            gc.realistic_s = predict(distance_m, end_vdot, basis_m, slope, race_weekly_km).time_s
        else:
            gc.realistic_s = end_of_plan(distance_m, vd, basis_m, slope, years_running, age, weeks,
                                         race_weekly_km)[1]
    if needed < 99:
        gc.earliest = today + timedelta(weeks=needed)
    endurance_ok = weeks_end == 0 or (weeks is not None and weeks_end + taper <= weeks)
    pct = None
    if target_s and gc.realistic_s:
        pct = gc.realistic_s / target_s - 1          # > 0: the realistic time is slower than the target
    if weeks is None:
        gc.verdict = "on_track" if needed < 99 else "not_enough_time"
    elif not endurance_ok:
        gc.verdict = "ambitious" if weeks_end + taper <= 1.25 * weeks + 1 else "not_enough_time"
    elif pct is None or pct <= 0.002:
        gc.verdict = "on_track"
    elif pct <= 0.02:
        gc.verdict = "ambitious"                     # within ~2 %: a stretch, not a fantasy
    else:
        gc.verdict = "not_enough_time"
    when = f" in {weeks:.0f} weeks" if weeks is not None else ""
    if gc.verdict == "on_track":
        gc.headline = (f"{fmt_time(target_s)} for the {name}{when} looks realistic" if target_s
                       else f"The {name}{when} fits where you are")
    elif gc.verdict == "ambitious":
        if not endurance_ok:
            gc.headline = f"Tight: about {weeks_end + taper} weeks to build up for a {name}, you have {weeks:.0f}"
        else:
            gc.headline = (f"Ambitious: about {fmt_time(gc.realistic_s)} is realistic by then, "
                           f"your target is {fmt_time(target_s)}")
        tips.append("doable if training goes well: keep it as a stretch goal and decide the race pace from "
                    "your last test run")
    else:
        capped = cap_km is not None and cap_km < need_w and weekly_km >= 3
        if needed >= 99 and capped:
            gc.headline = (f"Above your weekly cap: a {name} at this pace needs about {need_w} km a week, "
                           f"your cap is {cap_km:.0f}")
            fw, fl = finish
            if (fw, fl) != (need_w, need_l) and fw <= cap_km:
                wf = build_weeks(weekly_km, long_km, fw, fl, cautious, cap_km, years_running, ramp) + taper
                if weeks is None or wf <= weeks:
                    tips.append(f"finishing it comfortably is possible on {fw} km a week (no time target)")
            tips.append("raise the cap in Setup if you can train more")
        elif needed >= 99:
            gc.headline = "Not reachable from where you are now"
        elif not endurance_ok:
            gc.headline = f"Not enough time to build up: about {weeks_end + taper} weeks needed, you have {max(weeks, 0):.0f}"
        else:
            gc.headline = f"Too fast for this date: about {needed} weeks needed, you have {max(weeks, 0):.0f}"
        if gc.earliest and race_date:
            tips.append(f"earliest realistic date for this: around {gc.earliest:%d %b %Y}")
        if target_s and gc.realistic_s and endurance_ok:
            tips.append(f"realistic for your date: about {fmt_time(gc.realistic_s)}")
        if not endurance_ok:
            shorter = [n for d, n in DISTANCES if 5000 <= d < distance_m
                       and build_weeks(weekly_km, long_km, *NEEDS[nearest(NEEDS, d)][1], cautious, cap_km,
                                      years_running, ramp)
                       + taper_weeks(d) <= max(weeks or 0, 0)]
            if shorter:
                tips.append(f"a {shorter[-1].lower()} fits your date instead")
    if gc.realistic_s and weeks is not None and gc.verdict != "not_enough_time" and endurance_ok:
        tips.insert(0, f"by race day you could run about {fmt_time(gc.realistic_s)}")
    return gc


def describe_pace(p: Prediction) -> str:
    return f"{fmt_pace(p.pace_s)}/km"


def runner_curve(p, today: date) -> tuple:
    """(VDOT from the profile, distance it was measured at, slope per doubling, n distances)."""
    from .fitness import current_vdot
    r = p.recent
    off = r.weeks_off * 7 if r.status == "returning" else 0
    est = current_vdot(p.performances, p.athlete.birth_date, today, off, r.cross_trained, r.easy_pace_s, r.status)
    good = [c for c in est.candidates if c.weight >= 0.5] or est.candidates
    basis_m = max(good, key=lambda c: c.today).perf.distance_m if good else 5000.0
    slope, n = personal_slope(p.performances, p.athlete.birth_date, today)
    return est.vdot, basis_m, slope, n
