"""CLI:  python -m coach_engine plan PROFILE.toml [--today YYYY-MM-DD] [--start YYYY-MM-DD] [--summary]"""
from __future__ import annotations

import argparse
import sys
from datetime import date

from .builder import build_plan
from .profile_io import load_profile
from .render import render


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="coach_engine")
    sub = ap.add_subparsers(dest="cmd", required=True)
    pp = sub.add_parser("plan", help="build and print a plan")
    pp.add_argument("profile")
    pp.add_argument("--today", type=date.fromisoformat, default=date.today())
    pp.add_argument("--start", type=date.fromisoformat, default=None)
    pp.add_argument("--summary", action="store_true", help="week table only")
    a = ap.parse_args(argv)
    if a.cmd == "plan":
        prof = load_profile(a.profile, a.today)
        plan = build_plan(prof, a.today, a.start)
        sys.stdout.reconfigure(encoding="utf-8")
        print(render(plan, detail=not a.summary))
        return 0 if not any(w.warnings for w in plan.weeks) else 2
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
