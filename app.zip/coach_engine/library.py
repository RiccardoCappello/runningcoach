"""Workout library: each family is a ladder of levels (spec §4.3).

Builders return lists of Segment. Distance-based reps are converted to time
(and time to distance) with the zone centre paces, so every session has both.
"""
from __future__ import annotations

from .fitness import HALF, MARATHON, dist_name, fmt_time
from .models import Segment
from .zones import Zones

WU, CD = 15, 10   # warm-up / cool-down minutes (easy)

# (reps, minutes, jog minutes)
THRESHOLD = [(3, 5, 1), (4, 5, 1), (2, 10, 2), (3, 8, 2), (2, 12, 2),
             (3, 10, 2), (2, 15, 2), (4, 8, 1.5), (1, 30, 0)]
THRESHOLD_MAINT = {"recovery": (3, 6, 1), "sharpen": (2, 10, 2)}
INTERVALS = [(4, 3, 3), (5, 3, 3), (4, 4, 3), (5, 3, 2.5), (5, 4, 3), (6, 4, 3), (5, 5, 4)]
REPS = [(6, 0.2), (8, 0.2), (10, 0.2), (6, 0.4), (8, 0.4), (10, 0.4)]   # (reps, km), jog = same distance
LONG_FINISH = [10, 20, 25, 30, 40]                                      # minutes at M at the end
HILL_SPRINTS = (4, 10)                                                  # start, max

# Race-specific (Magness: bottom-up toward the goal), km per rep
RACE_SPECIFIC = {
    5000: [[0.4] * 8, [0.6] * 6, [0.8] * 5, [1.0] * 5],
    10000: [[1.0] * 5, [2.0, 2.0, 1.0], [2.0] * 3, [3.0, 2.0]],
    HALF: [[2.0] * 3, [3.0] * 2, [3.0] * 3, [5.0, 3.0]],
    MARATHON: [[6.0], [8.0], [5.0, 5.0], [12.0], [8.0, 6.0], [16.0]],
}
# per-session cap for race-pace work as a share of the week (Daniels caps, by distance)
RP_CAP = {5000: 0.08, 10000: 0.10, HALF: 0.15, MARATHON: 0.20}


def nearest_key(d: dict, distance_m: float):
    return min(d, key=lambda k: abs(k - distance_m))


def seg(z: Zones, zone: str, minutes: float, label: str = "") -> Segment:
    return Segment(zone, minutes, z.km(zone, minutes), label)


def seg_km(z: Zones, zone: str, km: float, label: str = "") -> Segment:
    return Segment(zone, z.minutes(zone, km), km, label)


STRIDE_S, STRIDE_BACK_S = 20, 40     # each stride: 20 s fast, then walk/jog back to the start (~40 s)
HILL_S, HILL_CYCLE_S = 10, 150       # each hill sprint: 10 s up, walk down + full rest = 2.5' per rep
UPHILL_SPEED = 0.8                   # a steep uphill sprint covers ~80 % of the flat sprint distance


def stride_set(z: Zones, n: int) -> list:
    """n strides with the walk/jog back. Time = n x (20 s + 40 s). Distance: you cover each
    stride twice (out fast, back slowly) - the way back is not extra running at a pace."""
    out_km = z.km("S", n * STRIDE_S / 60)
    return [Segment("S", n * STRIDE_S / 60, out_km, f"{n} x 20 s strides"),
            Segment("walk", n * STRIDE_BACK_S / 60, out_km, "walk/jog back to the start after each")]


def hill_sprints(z: Zones, n: int) -> list:
    """n x 10 s uphill sprints. Each rep takes ~2.5' with the walk down and the rest; the only
    distance is the way up and back down (~50-60 m each way), not 2.5' of running."""
    up_km = UPHILL_SPEED * z.km("S", n * HILL_S / 60)
    return [Segment("S", n * HILL_S / 60, up_km, f"{n} x 10 s hill sprints"),
            Segment("walk", n * (HILL_CYCLE_S - HILL_S) / 60, up_km, "walk down + rest, ~2-3' per rep")]


def easy(z: Zones, minutes: float, strides: int = 0, hills: int = 0) -> list:
    out = [seg(z, "E", minutes, f"{minutes:.0f}' easy")]
    if strides:
        out += stride_set(z, strides)
    if hills:
        out += hill_sprints(z, hills)
    return out


def reps_time(z: Zones, zone: str, n: int, minutes: float, jog: float, wu=WU, cd=CD) -> list:
    out = [seg(z, "E", wu, f"{wu}' warm-up")]
    out.append(seg(z, zone, n * minutes, f"{n} x {minutes:g}'"))
    if n > 1 and jog:
        out.append(seg(z, "rec", (n - 1) * jog, f"{jog:g}' jog between"))
    out.append(seg(z, "E", cd, f"{cd}' cool-down"))
    return out


def reps_dist(z: Zones, zone: str, kms: list, jog: float, wu=WU, cd=CD, jog_label: str = "") -> list:
    if len(set(kms)) == 1:
        label = f"{len(kms)} x {kms[0]*1000:g} m" if kms[0] < 1 else f"{len(kms)} x {kms[0]:g} km"
    else:
        label = " + ".join(f"{k:g} km" for k in kms)
    out = [seg(z, "E", wu, f"{wu}' warm-up"), seg_km(z, zone, sum(kms), label)]
    if len(kms) > 1 and jog:
        out.append(seg(z, "rec", (len(kms) - 1) * jog, jog_label or f"{jog:g}' jog between"))
    out.append(seg(z, "E", cd, f"{cd}' cool-down"))
    return out


def threshold(z: Zones, level: int, maint: str | None = None) -> list:
    n, m, j = THRESHOLD_MAINT[maint] if maint else THRESHOLD[level]
    return reps_time(z, "T", n, m, j)


def intervals(z: Zones, level: int) -> list:
    n, m, j = INTERVALS[level]
    return reps_time(z, "I", n, m, j)


def repetitions(z: Zones, level: int) -> list:
    n, km = REPS[level]
    jog = z.minutes("rec", km) * 0.75     # jog the same distance, slowly
    return reps_dist(z, "R", [km] * n, jog, jog_label=f"{km*1000:g} m slow jog between")


def race_specific(z: Zones, level: int, race_m: float) -> list:
    kms = RACE_SPECIFIC[nearest_key(RACE_SPECIFIC, race_m)][level]
    jog = 2 if max(kms) <= 1 else 3
    zone = "M" if race_m >= MARATHON - 1 else "RP"
    return reps_dist(z, zone, kms, jog)


def long_run(z: Zones, minutes: float, finish_min: float = 0) -> list:
    if finish_min:
        return [seg(z, "E", minutes - finish_min, f"{minutes - finish_min:.0f}' easy"),
                seg(z, "M", finish_min, f"last {finish_min:g}'")]
    return [seg(z, "E", minutes, f"{minutes:.0f}' easy")]


def dist_label(distance_m: float) -> str:
    """For session titles ("5 km TIME TRIAL", "HALF MARATHON TIME TRIAL")."""
    name = dist_name(distance_m)
    return name if name.endswith(" km") else name.upper()


# warm-up minutes, strides, cool-down minutes (jog; 0 = walk it off). The longer the race, the
# slower it starts: its first km are the warm-up, and 15'+10' of jogging on top of a half made
# a 21 km race a 26 km day, far beyond the longest run of the plan.
TT_EXTRAS = {5000: (15, 4, 10), 10000: (10, 4, 5), HALF: (10, 2, 0), MARATHON: (5, 0, 0)}


def time_trial(z: Zones, distance_m: float, predicted_s: float, show_prediction: bool = True,
               short: bool = False) -> list:
    wu, n_strides, cd = TT_EXTRAS[nearest_key(TT_EXTRAS, distance_m)]
    if short:
        wu, cd = min(wu, 10), min(cd, 5)
    km = distance_m / 1000
    what = (f"{dist_name(distance_m)} all-out (predicted {fmt_time(predicted_s)})"
            if show_prediction else f"{dist_name(distance_m)} hard but even - your time sets the paces")
    segs = [seg(z, "E", wu, f"{wu}' warm-up")]
    if n_strides:
        segs += stride_set(z, n_strides)
    segs.append(Segment("TT", predicted_s / 60, km, what))
    if cd:
        segs.append(seg(z, "E", cd, f"{cd}' cool-down"))
    else:
        segs.append(Segment("walk", 10, 0.0, "10' walk to cool down"))
    return segs


def cross_training(z: Zones, minutes: float, options: list) -> list:
    return [Segment("XT", minutes, 0.0, f"{minutes:.0f}' easy {'/'.join(options) or 'cross-training'}")]


def strength(minutes: float = 35) -> list:
    return [Segment("STR", minutes, 0.0, f"{minutes:.0f}' strength (your choice of exercises)")]


# ------------------------------------------------ start-from-scratch run/walk (spec §10.8)
# (reps, run minutes, walk minutes) per level; the last levels are continuous runs. One level a
# week, a consolidation week every 4th (Noakes: "don't speed up the plan"; C25K-like but slower).
RUN_WALK = [(8, 1, 2), (6, 2, 2), (5, 3, 2), (4, 5, 2), (3, 8, 2), (2, 12, 2),
            (1, 20, 0), (1, 25, 0), (1, 30, 0)]
WALK_KM_PER_MIN = 0.1     # brisk walking, ~6 km/h
WALK_WU = 5               # brisk-walk warm-up and cool-down, minutes


def walk(minutes: float, label: str) -> Segment:
    return Segment("walk", minutes, minutes * WALK_KM_PER_MIN, label)


def run_walk_level(continuous_min: float | None) -> int:
    """Starting level from 'I can run about N minutes without stopping'."""
    m = continuous_min or 0
    for lvl in range(len(RUN_WALK) - 1, -1, -1):
        n, run, w = RUN_WALK[lvl]
        if run <= max(1, m * 0.6):
            return lvl
    return 0


def run_walk(z: Zones, level: int, extra_run: float = 0) -> list:
    """One run/walk session: brisk-walk warm-up, the reps, brisk-walk cool-down.
    extra_run: minutes added to a continuous run (the weekly 'long' one at the top level)."""
    n, run, w = RUN_WALK[level]
    out = [walk(WALK_WU, f"{WALK_WU}' brisk walk warm-up")]
    if n == 1:
        m = run + extra_run
        out.append(seg(z, "E", m, f"{m:g}' easy running, without stopping"))
    else:
        out.append(seg(z, "E", n * run, f"{n} x {run:g}' easy running"))
        out.append(walk((n - 1) * w, f"{w:g}' walk between"))
    out.append(walk(WALK_WU, f"{WALK_WU}' walk cool-down"))
    return out


def fits(ladder_session, cap_km: float, zone: str) -> bool:
    return sum(s.km for s in ladder_session if s.zone == zone) <= cap_km


def pick_level(build, desired: int, cap_km: float, zone: str):
    """Highest level <= desired whose work in `zone` fits the cap (spec S18)."""
    for lvl in range(desired, -1, -1):
        segs = build(lvl)
        if fits(segs, cap_km, zone):
            return lvl, segs
    return None, None
