"""Week validation (spec §4.4). Returns human-readable problems; empty = OK."""
from __future__ import annotations

from .models import DAYS, Week

EASY_TARGET = {"base": 0.85, "build": 0.80, "sharpen": 0.80}   # base "about 90/10" (80/20)
KIND_TARGET = {"recovery": 0.85, "taper": 0.80, "return": 0.90, "lead-in": 0.85}


def caps(km: float) -> dict:
    return {"T": 0.10 * km, "I": min(0.08 * km, 10.0), "R": min(0.05 * km, 8.0), "M": min(0.20 * km, 29.0)}


def easy_target(wk: Week, ctx) -> float:
    target = KIND_TARGET.get(wk.kind, EASY_TARGET.get(wk.block, 0.80))
    if wk.block == "sharpen" and ctx.p.goal.distance_m > 42000:
        target = 0.75     # marathon-pace work is the specific work; pyramidal >= 75 % (Campos 2021)
    return target


def validate_week(wk: Week, ctx, level_km: float) -> list:
    out = []
    km = wk.km
    target = easy_target(wk, ctx)
    share = wk.easy_share()
    if share < target - 1e-9:
        out.append(f"easy share {share:.0%} < {target:.0%} (S11)")

    # per-session caps against the planned week (S18); 2 % tolerance for rounding
    from .builder import day_cap_frac, long_cap_km
    day_frac = day_cap_frac(ctx.runs)
    long_min = max((s.minutes for s in wk.sessions if s.kind == "long"), default=None)
    c = caps(wk.target_km)
    from .library import RP_CAP, nearest_key
    rp_cap = RP_CAP[nearest_key(RP_CAP, ctx.p.goal.distance_m)] * wk.target_km
    for s in wk.sessions:
        for zone, cap in list(c.items()) + [("RP", rp_cap)]:
            if s.zone_km(zone) > cap * 1.02 + 0.05:
                out.append(f"{DAYS[s.day]} {zone} {s.zone_km(zone):.1f} km > cap {cap:.1f} (S18)")
        if s.kind == "long":
            cap = long_cap_km(level_km, ctx.runs, ctx.p.goal.distance_m, ctx.zones.centre["E"])
            if s.km > cap * 1.03 + 0.1:
                out.append(f"long run {s.km:.1f} km > cap {cap:.1f} km for {level_km:.0f} km weeks (S18)")
        elif s.kind not in ("tt", "xt", "strength", "rest") and s.km > day_frac * level_km * 1.03 + 0.1:
            out.append(f"{DAYS[s.day]} {s.km:.1f} km > {day_frac:.0%} of the week")
        if s.kind == "easy" and long_min is not None and s.minutes > long_min + 0.5:
            out.append(f"{DAYS[s.day]} easy run longer than the long run")
        if s.kind not in ("strength", "rest", "tt") and s.minutes > ctx.p.availability.budget(s.day) + 1:
            out.append(f"{DAYS[s.day]} {s.minutes:.0f}' > available {ctx.p.availability.budget(s.day):.0f}'")

    hard = sorted({s.day for s in wk.sessions if s.hard})
    hard_max = 3 if (wk.block == "sharpen" and ctx.age < 40 and wk.kind == "normal") else 2
    if len(hard) > hard_max:
        out.append(f"{len(hard)} hard days > {hard_max} (S19)")
    for a, b in zip(hard, hard[1:] + ([hard[0] + 7] if len(hard) > 1 else [])):
        if b - a < ctx.gap_min:
            out.append(f"hard days {DAYS[a % 7]}/{DAYS[b % 7]} too close (S19/S22)")

    runs = [s for s in wk.sessions if s.kind in ("easy", "long", "quality", "tt")]
    if len(runs) < 3 and wk.kind not in ("taper", "lead-in"):
        out.append("fewer than 3 runs (S24)")
    return out


def spike_warnings(weeks: list) -> list:
    """Soft guard (S16): week > 1.3 x mean of the previous 4."""
    out = []
    for i in range(1, len(weeks)):
        prev = [w.km for w in weeks[max(0, i - 4):i]]
        ref = sum(prev) / len(prev)
        if weeks[i].km > 1.3 * ref:
            out.append((weeks[i].index, f"spike {weeks[i].km:.0f} km vs 4-week mean {ref:.0f}"))
    return out
