"""The coach's web app inside the phone's browser (Pyodide).

shell.js hands every link, form and fetch to handle(): it calls the same FastAPI app the server
runs, in-process, as one ASGI request. No network, no server; the database is a file in the
browser's storage (IndexedDB, synced by shell.js after each request).

Pyodide has no threads: FastAPI runs plain `def` routes in a thread pool, so that is replaced by
a direct call (one request at a time, which is all a phone needs).
"""
from __future__ import annotations

import os
import traceback

os.environ.setdefault("COACH_PHONE", "1")
os.environ.setdefault("COACH_DB", "/data/coach.db")

import anyio.to_thread  # noqa: E402


async def _run_sync(func, *args, abandon_on_cancel=False, cancellable=None, limiter=None):
    return func(*args)


anyio.to_thread.run_sync = _run_sync

from coach_app import main  # noqa: E402

app = main.app


def init(public_url: str):
    """public_url: the address of the app (share links point there)."""
    os.environ["COACH_PUBLIC_URL"] = public_url


async def handle(method: str, path: str, query: str = "", body: str | bytes = b"",
                 content_type: str = "") -> tuple:
    """One request -> (status, headers dict, body bytes). From JS the body is a string (forms
    are url-encoded text)."""
    if isinstance(body, str):
        body = body.encode()
    headers = [(b"host", b"phone"), (b"accept", b"text/html,application/json")]
    if content_type:
        headers.append((b"content-type", content_type.encode()))
    if body:
        headers.append((b"content-length", str(len(body)).encode()))
    scope = {"type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1", "method": method,
             "scheme": "https", "path": path, "raw_path": path.encode(), "query_string": query.encode(),
             "root_path": "", "headers": headers, "client": ("127.0.0.1", 0), "server": ("phone", 443)}
    sent = False

    async def receive():
        nonlocal sent
        if not sent:
            sent = True
            return {"type": "http.request", "body": body, "more_body": False}
        return {"type": "http.disconnect"}

    msgs = []

    async def send(m):
        msgs.append(m)

    try:
        await app(scope, receive, send)
    except Exception:                          # the app already answered 500; show why
        tb = traceback.format_exc()
        print(tb)
        if not any(m["type"] == "http.response.start" for m in msgs) or _status(msgs) == 500:
            return 500, {"content-type": "text/plain; charset=utf-8"}, tb.encode()
    start = next(m for m in msgs if m["type"] == "http.response.start")
    out = b"".join(m.get("body", b"") for m in msgs if m["type"] == "http.response.body")
    return start["status"], {k.decode().lower(): v.decode() for k, v in start["headers"]}, out


def _status(msgs) -> int:
    return next((m["status"] for m in msgs if m["type"] == "http.response.start"), 0)
